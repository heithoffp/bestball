import{s as p,g as he}from"./supabase-BW3i5Oe4.js";function ae({targetSelector:e,onMutation:t,onReconnect:n,pollInterval:r=500,maxRetries:o=20}){let i=null,l=null,a=null,s=!1;const c={childList:!0,subtree:!0};function d(y){i&&i.disconnect(),i=new MutationObserver(t),i.observe(y,c),l=y}function u(){a&&clearInterval(a);let y=0;a=setInterval(()=>{if(s){clearInterval(a);return}const O=document.querySelector(e);O?(clearInterval(a),a=null,d(O),n==null||n()):++y>=o&&(clearInterval(a),a=null)},r)}const N=new MutationObserver(()=>{if(s)return;const y=document.querySelector(e);!y&&i?(i.disconnect(),i=null,l=null,u()):y&&i&&y!==l&&(d(y),n==null||n())}),D=document.querySelector(e);return D?d(D):u(),N.observe(document.body,{childList:!0,subtree:!0}),{disconnect(){s=!0,a&&clearInterval(a),i&&i.disconnect(),N.disconnect()}}}async function ie(){if(!p)return null;const{data:{session:e}}=await p.auth.getSession();return e}async function xe(e,t){if(!p)throw new Error("[BBM] Supabase not configured");const{data:n,error:r}=await p.auth.signInWithPassword({email:e,password:t});if(r)throw r;return n.session}async function ve(){if(!p)throw new Error("[BBM] Supabase not configured");const e=await chrome.runtime.sendMessage({type:"GOOGLE_OAUTH"});if(e.error)throw new Error(e.error);const{data:t,error:n}=await p.auth.setSession({access_token:e.access_token,refresh_token:e.refresh_token});if(n)throw n;return t.session}async function we(){p&&await p.auth.signOut()}async function Ee(){var e,t,n;try{if(!p)return null;const{data:{session:r}}=await p.auth.getSession();if(!r)return null;const o=r.user.id,[i,l]=await Promise.all([p.from("subscriptions").select("status").eq("user_id",o).in("status",["active","trialing"]).limit(1).maybeSingle(),p.from("profiles").select("beta_expires_at").eq("id",o).maybeSingle()]),a=((e=i.data)==null?void 0:e.status)==="active"||((t=i.data)==null?void 0:t.status)==="trialing",s=(n=l.data)==null?void 0:n.beta_expires_at,c=s?new Date(s)>new Date:!1;return a||c?"pro":"free"}catch{return null}}async function Se(){if(!p)throw new Error("[BBM] Supabase not configured");const{data:{session:e}}=await p.auth.getSession();if(!e)throw new Error("[BBM] Not authenticated");const{data:t,error:n}=await p.from("extension_entries").select("entry_id, tournament, slate_title, draft_date, players").eq("user_id",e.user.id);if(n)throw n;return(t??[]).map(r=>({entryId:r.entry_id,tournamentTitle:r.tournament,slateTitle:r.slate_title??"",draftDate:r.draft_date,players:r.players??[]}))}async function ke(){if(!p)return null;const{data:{session:e}}=await p.auth.getSession();if(!e)return null;const{data:t,error:n}=await p.from("user_rankings").select("rankings").eq("user_id",e.user.id).maybeSingle();return n||!t?null:t.rankings??null}async function te(e,{platform:t}={}){if(!p)throw new Error("[BBM] Supabase not configured");const{data:{session:n}}=await p.auth.getSession();if(!n)throw new Error("[BBM] Not authenticated");const r=n.user.id;if(t){const s=`${t}_entry_ids`,d=(await new Promise(u=>chrome.storage.local.get([s],u)))[s]??[];if(d.length>0){const{error:u}=await p.from("extension_entries").delete().eq("user_id",r).in("entry_id",d);if(u)throw u}else if(t==="underdog"){const{error:u}=await p.from("extension_entries").delete().eq("user_id",r);if(u)throw u}}else{const{error:s}=await p.from("extension_entries").delete().eq("user_id",r);if(s)throw s}if(e.length===0){const s={lastSync:Date.now(),entryCount:0};return t&&(s[`${t}_lastSync`]=Date.now(),s[`${t}_entryCount`]=0),await chrome.storage.local.set(s),{count:0}}const o=e.map(s=>({user_id:r,entry_id:s.entryId,tournament:s.tournamentTitle??null,slate_title:s.slateTitle??null,draft_date:s.draftDate??null,players:s.players??[],synced_at:new Date().toISOString()})),{error:i,count:l}=await p.from("extension_entries").insert(o,{count:"exact"});if(i)throw i;const a={lastSync:Date.now(),entryCount:e.length};return t&&(a[`${t}_entry_ids`]=e.map(s=>s.entryId),a[`${t}_lastSync`]=Date.now(),a[`${t}_entryCount`]=e.length),await chrome.storage.local.set(a),{count:l??e.length}}const j="data-bbm-injected",le="data-bbm-player-id",I="data-bbm-headers-injected";let b=null,f=null,$=null,g=!0,T=null,Q=window.location.href,z=!1,h=new Map,w=new Map,k=new Map,M=new Map,q=0,C=[],L=null,_=null,Y=new Map,J=new Set,S=null,E="idle",V=null,X=null,x=[],P=[],m=new Set,H=new Set;const ne=["S","A+","A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"],Ce={S:"#ffd700","A+":"#ef4444",A:"#f87171","A-":"#fb923c","B+":"#f59e0b",B:"#eab308","B-":"#a3e635","C+":"#10b981",C:"#06b6d4","C-":"#3b82f6","D+":"#6366f1",D:"#8b5cf6","D-":"#a855f7",F:"#6b7280"};function ce(e){const t=Math.max(0,Math.min(e-1,ne.length-1));return ne[t]}function Be(e){return Ce[ce(e)]||"#555"}function Ae(e){const t=(e==null?void 0:e.message)??"";return t.includes("Not authenticated")||t.includes("JWT")?"Session expired — sign in again":t.includes("fetch")||t.includes("network")||t.includes("NetworkError")?"Connection lost — tap to retry":"Load failed — tap to retry"}function W(e){const t=Math.floor((Date.now()-e)/1e3);return t<60?"just now":t<3600?`${Math.floor(t/60)}m ago`:t<86400?`${Math.floor(t/3600)}h ago`:`${Math.floor(t/86400)}d ago`}async function U(){const e=document.querySelector(".bbm-status-dot"),t=document.querySelector(".bbm-status-label"),n=document.querySelector(".bbm-panel-sync-line");if(!e||!t||!n)return;const r=await ie();let o,i;r?E==="loading"?(o="#6B7280",i="Loading portfolio…"):E==="error"?(o="#EF4444",i=V??"Load failed — tap to retry"):(o="#10B981",i="Connected"):(o="#F59E0B",i="Not signed in"),e.style.background=o,t.textContent=i;const l=document.querySelector(".bbm-panel-status");if(l&&(l.style.cursor=E==="error"?"pointer":"default"),E==="loading"){n.textContent="Fetching entries…";return}if(!r){n.textContent="—";return}chrome.storage.local.get(["lastSync","entryCount","underdog_lastSync","underdog_entryCount","draftkings_lastSync","draftkings_entryCount"],a=>{const s=[];a.underdog_lastSync&&s.push(`UD: ${a.underdog_entryCount??0} · ${W(a.underdog_lastSync)}`),a.draftkings_lastSync&&s.push(`DK: ${a.draftkings_entryCount??0} · ${W(a.draftkings_lastSync)}`),s.length>0?n.textContent=s.join("  |  "):a.lastSync?n.textContent=`${a.entryCount??0} entries · synced ${W(a.lastSync)}`:n.textContent="Not yet synced"})}function Z(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Me(e){return String(e??"").replace(/\b\w/g,t=>t.toUpperCase())}function de(){const e=document.getElementById("bbm-tournament-filter");if(e){if(x.length===0){e.style.display="none";return}e.style.display="block",e.innerHTML=x.map((t,n)=>{const r=H.has(t.slate);return`
      <div class="bbm-filter-slate-group${r?" bbm-expanded":""}" data-si="${n}">
        <div class="bbm-filter-slate-row">
          <label class="bbm-filter-slate-label-wrap">
            <input type="checkbox" class="bbm-filter-check bbm-filter-slate-check" data-si="${n}" />
            <span class="bbm-filter-slate-label">${Z(t.slate)}</span>
          </label>
          <button type="button" class="bbm-filter-expand" data-si="${n}">${r?"▼":"▶"}</button>
        </div>
        <div class="bbm-filter-tournaments">
          ${t.tournaments.map((o,i)=>`
            <label class="bbm-filter-tournament-row">
              <input type="checkbox" class="bbm-filter-check bbm-filter-tournament-check"
                data-si="${n}" data-ti="${i}"
                ${m.has(o)?"checked":""} />
              <span class="bbm-filter-tournament-label">${Z(o)}</span>
            </label>
          `).join("")}
        </div>
      </div>
    `}).join(""),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{const{tournaments:n}=x[parseInt(t.dataset.si)],r=n.filter(o=>m.has(o)).length;t.checked=r===n.length,t.indeterminate=r>0&&r<n.length}),e.querySelectorAll(".bbm-filter-expand").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const r=x[parseInt(t.dataset.si)];H.has(r.slate)?H.delete(r.slate):H.add(r.slate),de()})}),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{t.addEventListener("change",()=>{const{tournaments:n}=x[parseInt(t.dataset.si)];n.every(o=>m.has(o))?n.forEach(o=>m.delete(o)):n.forEach(o=>m.add(o)),chrome.storage.local.set({tournamentFilter:[...m]}),ee()})}),e.querySelectorAll(".bbm-filter-tournament-check").forEach(t=>{t.addEventListener("change",()=>{const n=x[parseInt(t.dataset.si)].tournaments[parseInt(t.dataset.ti)];t.checked?m.add(n):m.delete(n),chrome.storage.local.set({tournamentFilter:[...m]}),ee()})})}}function ee(){var t,n,r,o;const e=m.size===0?P:P.filter(i=>m.has(i.tournamentTitle));q=e.length,h=new Map,w=new Map,k=new Map,M=new Map,e.forEach((i,l)=>{(i.players??[]).forEach(a=>{if(!a.name)return;const s=a.name.trim().toLowerCase();h.has(s)||h.set(s,new Set),h.get(s).add(l),a.team&&!w.has(s)&&w.set(s,a.team),a.position&&!k.has(s)&&k.set(s,a.position)})});for(const i of h.keys()){const l=i.split(/\s+/);if(l.length<2)continue;const a=l[0][0],s=l.slice(1).join(" "),c=`${a}. ${s}`;if(M.has(c)){const d=M.get(c),u={fullName:i,position:((t=k.get(i))==null?void 0:t.toUpperCase())??null,team:((n=w.get(i))==null?void 0:n.toUpperCase())??null};typeof d=="string"?M.set(c,[{fullName:d,position:((r=k.get(d))==null?void 0:r.toUpperCase())??null,team:((o=w.get(d))==null?void 0:o.toUpperCase())??null},u]):Array.isArray(d)&&d.push(u)}else M.set(c,i)}de(),v()}async function K(){const e=document.getElementById("bbm-auth-section");if(!e)return;const t=await ie();if(t){const n=await Ee(),r=n?`<span class="bbm-auth-tier ${n}">${n==="pro"?"Pro":"Free"}</span>`:"";e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <div class="bbm-auth-user">${Z(t.user.email)}</div>
        ${r}
        <button id="bbm-sign-out-btn" class="bbm-btn bbm-btn-secondary">Sign Out</button>
      </div>
      <button id="bbm-sync-btn" class="bbm-btn" style="margin-top:6px">Sync Now</button>
      <div id="bbm-sync-progress" class="bbm-sync-progress bbm-progress-indeterminate" style="display:none">
        <div class="bbm-progress-label">Discovering entries…</div>
        <div class="bbm-progress-bar-wrap"><div class="bbm-progress-bar-fill"></div></div>
      </div>
      <div id="bbm-sync-result" class="bbm-sync-result" style="display:none"></div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",re),e.querySelector("#bbm-sync-btn").addEventListener("click",_e),e.querySelector("#bbm-sign-out-btn").addEventListener("click",Le)}else{e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <button id="bbm-google-btn" class="bbm-btn bbm-btn-google">
          <svg width="16" height="16" viewBox="0 0 48 48" style="flex-shrink:0"><path fill="#4285F4" d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z"/><path fill="#34A853" d="M6.3 14.7l7 5.1C15 15.6 19.1 12 24 12c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 16.3 2 9.7 7.3 6.3 14.7z"/><path fill="#FBBC05" d="M24 46c5.4 0 10.3-1.8 14.1-5l-6.9-5.7C29.1 37 26.7 38 24 38c-6 0-10.6-3.9-12.3-9.2l-7 5.4C8.1 41 15.4 46 24 46z"/><path fill="#EA4335" d="M46 24c0-1.3-.2-2.7-.5-4H24v8.5h11.8c-1 3-3 5.4-5.8 7l6.9 5.7C41 37.5 46 31.5 46 24z"/></svg>
          Sign in with Google
        </button>
        <div class="bbm-auth-divider"><span>or</span></div>
        <input type="email" id="bbm-auth-email" class="bbm-auth-input" placeholder="Email" autocomplete="email" />
        <input type="password" id="bbm-auth-password" class="bbm-auth-input" placeholder="Password" autocomplete="current-password" />
        <button id="bbm-sign-in-btn" class="bbm-btn">Sign In</button>
        <div id="bbm-auth-error" class="bbm-auth-error" style="display:none"></div>
      </div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",re),e.querySelector("#bbm-google-btn").addEventListener("click",Te),e.querySelector("#bbm-sign-in-btn").addEventListener("click",oe);for(const n of e.querySelectorAll(".bbm-auth-input"))for(const r of["keydown","keypress","keyup"])n.addEventListener(r,o=>o.stopPropagation());e.querySelector("#bbm-auth-password").addEventListener("keydown",n=>{n.key==="Enter"&&oe()})}}function re(){const e=document.getElementById("bbm-account-body"),t=document.querySelector(".bbm-account-chevron");if(!e)return;const n=e.style.display!=="none";e.style.display=n?"none":"block",t&&(t.style.transform=n?"":"rotate(180deg)")}async function Te(){const e=document.getElementById("bbm-google-btn"),t=document.getElementById("bbm-auth-error");if(e){e.disabled=!0,t&&(t.style.display="none");try{await ve(),await K(),R()}catch(n){t&&(t.textContent=n.message??"Google sign-in failed",t.style.display="block"),e&&(e.disabled=!1)}}}async function oe(){var o,i;const e=(o=document.getElementById("bbm-auth-email"))==null?void 0:o.value.trim(),t=(i=document.getElementById("bbm-auth-password"))==null?void 0:i.value,n=document.getElementById("bbm-sign-in-btn"),r=document.getElementById("bbm-auth-error");if(!(!e||!t||!n)){n.disabled=!0,r&&(r.style.display="none");try{await xe(e,t),await K(),R()}catch(l){r&&(r.textContent=l.message??"Sign in failed",r.style.display="block"),n&&(n.disabled=!1)}}}async function Le(){await we(),h=new Map,w=new Map,k=new Map,q=0,P=[],x=[],v(),await K(),U()}async function _e(){const e=document.getElementById("bbm-sync-btn"),t=document.getElementById("bbm-sync-result"),n=document.getElementById("bbm-sync-progress");if(!e)return;if(e.disabled=!0,t&&(t.style.display="none",t.className="bbm-sync-result"),n&&(n.style.display="none"),!X){t&&(t.textContent=b.syncPageErrorMessage,t.classList.add("error"),t.style.display="block"),e.disabled=!1;return}const r=n==null?void 0:n.querySelector(".bbm-progress-label"),o=n==null?void 0:n.querySelector(".bbm-progress-bar-fill");function i(l){var d;if(l.source!==window||((d=l.data)==null?void 0:d.type)!=="BBM_SYNC_PROGRESS")return;const{phase:a,done:s,total:c}=l.data;if(n){if(n.style.display="block",a==="discovery")n.classList.add("bbm-progress-indeterminate"),r&&(r.textContent="Discovering entries…"),o&&(o.style.width="0%");else if(a==="fetching"){n.classList.remove("bbm-progress-indeterminate");const u=c>0?Math.round(s/c*100):0;r&&(r.textContent=`Processing ${s} / ${c} entries…`),o&&(o.style.width=u+"%")}}}window.addEventListener("message",i);try{const{count:l}=await X();t&&(t.textContent=`Synced ${l} entries`,t.style.display="block"),R()}catch(l){if(t){const a=l.message??"Sync failed";t.textContent=a.includes("Could not establish connection")?b.syncPageErrorMessage:a,t.classList.add("error"),t.style.display="block"}}finally{window.removeEventListener("message",i),n&&(n.style.display="none"),e&&(e.disabled=!1)}}async function R(){E="loading",U();try{P=await Se();const e=new Map;P.forEach(r=>{if(!r.tournamentTitle)return;const o=r.slateTitle||"Other";e.has(o)||e.set(o,new Set),e.get(o).add(r.tournamentTitle)}),x=[...e.entries()].sort(([r],[o])=>r.localeCompare(o)).map(([r,o])=>({slate:r,tournaments:[...o].sort()}));const t=new Set(x.flatMap(r=>r.tournaments)),n=m.size;m=new Set([...m].filter(r=>t.has(r))),m.size===0&&t.forEach(r=>m.add(r)),m.size!==n&&chrome.storage.local.set({tournamentFilter:[...m]}),ee(),E="ready",V=null}catch(e){E="error",V=Ae(e),console.warn("[BBM] Could not load portfolio data:",e.message)}finally{U()}}async function qe(){try{const e=await ke();if(!e)return;Y=new Map(e.map(t=>[t.name,{rank:t.rank,tierNum:t.tierNum}])),J=new Set;for(let t=1;t<e.length;t++)e[t].tierNum!==e[t-1].tierNum&&J.add(e[t].rank);v()}catch(e){console.warn("[BBM] Could not load rankings data:",e.message)}}function be(){let e;if(b.getCurrentPicks){const n=b.getCurrentPicks();if(!n)return;e=n.map(r=>({name:B(r.name,{position:r.position})??r.name,position:r.position,round:r.round}))}else e=[],document.querySelectorAll(b.selectors.myPicksSelector).forEach((r,o)=>{var c,d,u;const i=r.querySelector(b.selectors.playerNameInRowSelector),l=r.closest(b.selectors.positionSectionSelector),a=((d=(c=l==null?void 0:l.querySelector(b.selectors.positionHeaderSelector))==null?void 0:c.textContent)==null?void 0:d.trim())??"",s=(u=i==null?void 0:i.textContent)==null?void 0:u.trim();s&&e.push({name:s,position:a,round:o+1})});(e.length!==C.length||e.some((n,r)=>{var o;return n.name!==((o=C[r])==null?void 0:o.name)}))&&(C=e,v())}function Re(){_||(_=requestAnimationFrame(()=>{_=null,be()}))}function Ie(){L||(L=new MutationObserver(Re),L.observe(document.body,{childList:!0,subtree:!0}),be())}function $e(){_&&(cancelAnimationFrame(_),_=null),L&&(L.disconnect(),L=null),C=[]}function ue(e){var n;const t=e.querySelector(b.selectors.playerNameInRowSelector);return((n=t==null?void 0:t.textContent)==null?void 0:n.trim())??null}function B(e,t){if(!e)return null;const n=e.trim().toLowerCase();if(h.has(n))return n;const r=M.get(n);if(typeof r=="string")return r;if(Array.isArray(r)&&t){const o=t instanceof Element&&b.getPlayerContext?b.getPlayerContext(t):t;let i=r;if(o.position){const l=o.position.toUpperCase(),a=i.filter(s=>s.position===l);if(a.length===1)return a[0].fullName;a.length>1&&(i=a)}if(o.team){const l=o.team.toUpperCase(),a=i.filter(s=>s.team===l);if(a.length===1)return a[0].fullName}}return null}function pe(e){if(q===0)return 0;const t=B(e);if(!t)return 0;const n=h.get(t);return n?n.size/q*100:0}function me(e){const t=B(e),n=(t&&h.get(t))??new Set,r=[];let o=0,i=0;return C.forEach(l=>{const a=h.get(l.name.trim().toLowerCase())??new Set;if(a.size===0)return;let s=0;a.size<n.size?a.forEach(d=>{n.has(d)&&s++}):n.forEach(d=>{a.has(d)&&s++});const c=s/a.size;o+=c,i++,r.push({name:l.name,position:l.position,round:l.round,pct:Math.round(c*100)})}),{score:i>0?Math.round(o/i*100):0,breakdown:r}}function ze(e){const t=e.querySelector(".bbm-stat-cell:not(.bbm-corr-trigger)"),n=e.querySelector(".bbm-corr-trigger");if(!t||!n)return;const r=ue(e);if(!r||q===0)return;const o=B(r,e)??r,i=pe(o);t.textContent=`${Math.round(i)}%`;const l=n.querySelector(".bbm-corr-value"),a=n.querySelector(".bbm-corr-popup");if(!l||!a)return;const{score:s,breakdown:c}=me(o);l.textContent=`${s}%`,fe(a,c),ge(e,o),ye(e,o)}function fe(e,t){if(t.length===0){e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No picks yet</div>';return}e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div>'+t.map(n=>`<div class="bbm-corr-popup-row">
          <span class="bbm-corr-popup-pos">${n.position}</span>
          <span class="bbm-corr-popup-name">${Me(n.name)}</span>
          <div class="bbm-corr-popup-bar">
            <div class="bbm-corr-popup-bar-fill" style="width:${n.pct}%;background:#3b82f6"></div>
          </div>
          <span class="bbm-corr-popup-pct">${n.pct}%</span>
        </div>`).join("")}function ge(e,t){e.querySelectorAll(".bbm-stack-pill").forEach(i=>i.remove());const n=Pe(t);if(!n)return;const r=e.querySelector(b.selectors.stackPillTargetSelector);if(!r)return;const o=document.createElement("span");o.className="bbm-stack-pill bbm-inline-overlay",o.textContent=n.type,o.style.color=n.color,o.style.borderColor=n.color,o.style.background=`${n.color}1A`,r.appendChild(o)}function Pe(e){const t=B(e);if(!t)return null;const n=w.get(t),r=k.get(t);if(!n||!r||C.length===0)return null;const o=C.filter(c=>{const d=w.get(c.name.trim().toLowerCase());return d&&d===n});if(o.length===0)return null;const i=o.filter(c=>c.position==="QB"),l=o.filter(c=>c.position==="WR"),a=o.filter(c=>c.position==="TE"),s=o.filter(c=>c.position==="RB");return r==="QB"&&(l.length>0||a.length>0||s.length>0)?{type:l.length+a.length+s.length>=2?"QB MULTI":"QB STACK",color:"#BF44EF"}:(r==="WR"||r==="TE"||r==="RB")&&i.length>0?{type:l.length+a.length+s.length>=1?"QB MULTI":"QB STACK",color:"#BF44EF"}:r==="WR"&&l.length>=1?{type:`WR ×${l.length+1}`,color:"#F59E0B"}:r==="TE"&&a.length>=1?{type:`TE ×${a.length+1}`,color:"#3B82F6"}:r==="RB"&&s.length>=1?{type:`RB ×${s.length+1}`,color:"#10B981"}:r==="RB"&&(l.length>0||a.length>0)?{type:"TEAM",color:"#8A9BB5"}:(r==="WR"||r==="TE")&&s.length>0?{type:"TEAM",color:"#8A9BB5"}:null}function Fe(){const e=document.createElement("div");e.className="bbm-inline-overlay bbm-stat-cell",e.textContent="--%";const t=document.createElement("div");t.className="bbm-inline-overlay bbm-stat-cell bbm-corr-trigger";const n=document.createElement("span");n.className="bbm-corr-value",n.textContent="--";const r=document.createElement("div");return r.className="bbm-corr-popup",r.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No draft data yet</div>',t.appendChild(n),t.appendChild(r),t.addEventListener("mouseenter",()=>{Ne(),f.innerHTML=r.innerHTML;const o=t.getBoundingClientRect();f.style.left=`${Math.max(8,o.right-280)}px`,f.style.top=`${o.bottom+4}px`,f.style.display="block"}),t.addEventListener("mouseleave",()=>{f&&(f.style.display="none")}),[e,t]}function Ne(){f&&document.body.contains(f)||(f=document.createElement("div"),f.className="bbm-corr-popup",f.id="bbm-corr-popup-portal",f.style.cssText="display: none; position: fixed; z-index: 10001;",document.body.appendChild(f))}function De(e){var c,d;const t=((c=b.getRowId)==null?void 0:c.call(b,e))??e.getAttribute("data-id");if(!t)return;if(e.getAttribute(j)===t){ze(e);return}e.querySelectorAll(".bbm-inline-overlay").forEach(u=>u.remove()),e.querySelectorAll(".bbm-tier-badge").forEach(u=>u.remove()),e.removeAttribute("data-bbm-tier");const{parent:r,before:o}=((d=b.getInjectionPoint)==null?void 0:d.call(b,e))??{};if(!r)return;const[i,l]=Fe();o?(r.insertBefore(i,o),r.insertBefore(l,o)):r.append(i,l),b.postInjectRow&&b.postInjectRow(e,i,l),e.setAttribute(j,t),e.setAttribute(le,t);const a=ue(e),s=B(a,e)??a;if(q>0&&s){const u=pe(s);i.textContent=`${Math.round(u)}%`;const{score:N,breakdown:D}=me(s),y=l.querySelector(".bbm-corr-value"),O=l.querySelector(".bbm-corr-popup");y.textContent=`${N}%`,fe(O,D)}s&&ge(e,s),ye(e,s)}function ye(e,t){if(e.querySelectorAll(".bbm-tier-badge").forEach(c=>c.remove()),e.removeAttribute("data-bbm-tier"),!b.isMyRankSort()||Y.size===0||!t)return;const n=B(t),r=Y.get(n??t.trim().toLowerCase());if(!r)return;const{tierNum:o,rank:i}=r;if(e.setAttribute("data-bbm-tier",String(o)),!J.has(i))return;const l=Be(o),a=ce(o),s=document.createElement("div");s.className="bbm-tier-badge",s.style.color=l,s.innerHTML=`<span class="bbm-tier-pill">${a}</span>`,e.prepend(s)}function Oe(){const e=document.querySelector(b.selectors.sortButtonsSelector);if(!e||(S||(S=new MutationObserver(v),S.observe(e,{attributes:!0,subtree:!0})),e.hasAttribute(I)))return;if(b.injectHeaderCells){b.injectHeaderCells(e),e.setAttribute(I,"true");return}const t=document.querySelector(b.selectors.rowSelector);if(!t)return;const n=e.getBoundingClientRect(),r=t.querySelectorAll(".bbm-stat-cell");if(r.length<2)return;const o=r[0].getBoundingClientRect(),i=r[1].getBoundingClientRect(),l=n.right,a=l-o.right,s=l-i.right;e.style.position="relative";const c=document.createElement("span");c.className="bbm-header-label",c.textContent="Exp",c.style.right=`${a}px`,c.style.width=`${o.width}px`;const d=document.createElement("span");d.className="bbm-header-label",d.textContent="Corr",d.style.right=`${s}px`,d.style.width=`${i.width}px`,e.appendChild(c),e.appendChild(d),e.setAttribute(I,"true")}function He(){document.querySelectorAll(".bbm-header-label").forEach(e=>e.remove()),document.querySelectorAll(`[${I}]`).forEach(e=>{e.removeAttribute(I)})}function v(){T||(T=requestAnimationFrame(()=>{var t;if(T=null,!g)return;(((t=b.getPlayerRows)==null?void 0:t.call(b))??document.querySelectorAll(b.selectors.rowSelector)).forEach(De),Oe()}))}function je(){document.querySelectorAll(".bbm-inline-overlay").forEach(e=>e.remove()),document.querySelectorAll(".bbm-tier-badge").forEach(e=>e.remove()),document.querySelectorAll("[data-bbm-tier]").forEach(e=>e.removeAttribute("data-bbm-tier")),document.querySelectorAll(`[${j}]`).forEach(e=>{e.removeAttribute(j),e.removeAttribute(le)}),He(),f&&(f.remove(),f=null)}function Ue(){if(document.getElementById("bbm-overlay-styles"))return;const e=document.createElement("style");e.id="bbm-overlay-styles",e.textContent=`
    /* DK: allow overlay cells to overflow fixed-width rows (scoped to rows, not scroll container) */
    .BaseTable__row {
      overflow: visible !important;
    }

    .bbm-stat-cell {
      color: inherit;
      opacity: 0.6;
      font-family: inherit;
      font-size: 11px;
      white-space: nowrap;
      flex-shrink: 0;
      width: 40px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }
    .bbm-stat-cell + .bbm-stat-cell {
      margin-left: 12px;
    }

    /* Corr cell is hoverable */
    .bbm-corr-trigger {
      pointer-events: auto;
      cursor: default;
      position: relative;
    }
    .bbm-corr-trigger:hover {
      opacity: 1;
    }

    /* Correlation popup — hidden by default, shown via JS mouseenter/mouseleave */
    .bbm-corr-popup {
      display: none;
      background: var(--bg-primary, #1a1a2e);
      color: #E8E8E8;
      border: 1px solid var(--border-color, #333);
      border-radius: 8px;
      padding: 8px 0;
      z-index: 10001;
      min-width: 220px;
      max-width: 300px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      white-space: normal;
      text-align: left;
      opacity: 1;
    }
    .bbm-corr-popup-title {
      padding: 0 12px 6px;
      font-size: 10px;
      color: #E8E8E8;
      opacity: 0.5;
      text-transform: uppercase;
      font-weight: 700;
      letter-spacing: 0.05em;
    }
    .bbm-corr-popup-empty {
      padding: 4px 12px;
      font-size: 12px;
      color: #E8E8E8;
      opacity: 0.4;
      font-style: italic;
    }

    /* Rows for when real data is wired in */
    .bbm-corr-popup-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 12px;
    }
    .bbm-corr-popup-pos {
      font-size: 10px;
      font-weight: 900;
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 22px;
      text-align: center;
    }
    .bbm-corr-popup-name {
      font-size: 12px;
      font-weight: 600;
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-corr-popup-bar {
      width: 40px;
      height: 5px;
      background: rgba(128, 128, 128, 0.3);
      border-radius: 3px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .bbm-corr-popup-bar-fill {
      height: 100%;
      border-radius: 3px;
    }
    .bbm-corr-popup-pct {
      font-size: 11px;
      font-weight: 700;
      font-family: monospace;
      min-width: 28px;
      text-align: right;
    }

    /* Stack pill — inline after player name, only visible when stacking */
    .bbm-stack-pill {
      display: inline-block;
      vertical-align: middle;
      margin-left: 6px;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid;
      line-height: 1.5;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0.85;
    }

    /* Tier break — full-width divider with centered pill label */
    .bbm-tier-badge {
      position: absolute;
      left: 0;
      right: 0;
      top: -7px;
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: none;
      z-index: 0;
      padding: 0 10px;
    }
    .bbm-tier-badge::before,
    .bbm-tier-badge::after {
      content: '';
      flex: 1;
      height: 1px;
      background: currentColor;
      opacity: 0.35;
    }
    .bbm-tier-pill {
      font-size: 8px;
      font-weight: 800;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      padding: 2px 6px;
      border-radius: 3px;
      background: #0C1A30;
      border: 1px solid currentColor;
      color: inherit;
      white-space: nowrap;
      line-height: 1.5;
      flex-shrink: 0;
    }

    .bbm-header-label {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      color: inherit;
      opacity: 0.5;
      font-family: inherit;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }

    /* Auth section (TASK-129) */
    #bbm-auth-section { margin: 6px 0; }

    .bbm-account-toggle {
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 3px 0;
      user-select: none;
    }
    .bbm-account-toggle-label {
      font-size: 10px;
      color: #8A9BB5;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .bbm-account-chevron {
      font-size: 9px;
      color: #5a6a80;
      transition: transform 0.15s;
      line-height: 1;
    }
    .bbm-account-body { padding-top: 6px; }

    .bbm-auth-input {
      width: 100%;
      background: #0F2040;
      border: 1px solid #243A5C;
      border-radius: 4px;
      color: #E8E8E8;
      font-size: 11px;
      padding: 5px 7px;
      margin-bottom: 4px;
      box-sizing: border-box;
      outline: none;
    }
    .bbm-auth-input:focus { border-color: #E8BF4A; }

    .bbm-btn {
      width: 100%;
      background: #E8BF4A;
      color: #0C1A30;
      border: none;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      padding: 5px 0;
      cursor: pointer;
      margin-bottom: 4px;
    }
    .bbm-btn:hover { background: #F0CC5B; }
    .bbm-btn:disabled { opacity: 0.5; cursor: default; }

    .bbm-btn-secondary {
      background: transparent;
      color: #8A9BB5;
      border: 1px solid #243A5C;
    }
    .bbm-btn-secondary:hover { color: #E8E8E8; border-color: #8A9BB5; }

    .bbm-btn-google {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: #fff;
      color: #3c4043;
      font-weight: 600;
    }
    .bbm-btn-google:hover { background: #f1f3f4; }

    .bbm-auth-divider {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 6px 0;
      font-size: 9px;
      color: #5A6E8A;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .bbm-auth-divider::before,
    .bbm-auth-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #243A5C;
    }

    .bbm-auth-user {
      font-size: 11px;
      color: #C0CCE0;
      margin-bottom: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-auth-tier {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 6px;
      background: #1C3A5E;
      color: #8A9BB5;
    }
    .bbm-auth-tier.pro { background: #2A3A10; color: #A3C447; }

    .bbm-auth-error {
      font-size: 10px;
      color: #EF4444;
      margin-top: 2px;
    }
    .bbm-sync-result {
      font-size: 10px;
      color: #10B981;
      margin-bottom: 4px;
    }
    .bbm-sync-result.error { color: #EF4444; }

    .bbm-sync-progress { margin-bottom: 6px; }
    .bbm-progress-label {
      font-size: 10px;
      color: #8A9BB5;
      margin-bottom: 3px;
    }
    .bbm-progress-bar-wrap {
      width: 100%;
      height: 4px;
      background: #1a2d50;
      border-radius: 2px;
      overflow: hidden;
    }
    .bbm-progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #D4A843, #F0CC5B);
      border-radius: 2px;
      transition: width 0.2s ease;
    }
    @keyframes bbm-shimmer {
      0%   { transform: translateX(-100%); }
      100% { transform: translateX(400%); }
    }
    .bbm-progress-indeterminate .bbm-progress-bar-fill {
      width: 25%;
      animation: bbm-shimmer 1.4s ease-in-out infinite;
    }

    /* FAB — brand logo button, bottom-left. Whispers at rest, speaks on hover. */
    #bbm-fab {
      position: fixed;
      bottom: 14px;
      left: 14px;
      z-index: 10000;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      opacity: 0.3;
      transition: opacity 120ms ease, filter 120ms ease;
    }
    #bbm-fab:hover {
      opacity: 1;
      filter: drop-shadow(0 0 8px rgba(232, 191, 74, 0.5));
    }

    /* Configuration panel — compact, only visible on demand */
    #bbm-panel {
      display: none;
      position: fixed;
      bottom: 50px;
      left: 14px;
      z-index: 10000;
      background: #0C1A30;
      border: 1px solid #243A5C;
      border-radius: 8px;
      padding: 10px 14px;
      min-width: 210px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
      font-size: 12px;
      color: #E8E8E8;
    }
    #bbm-panel.open {
      display: block;
    }
    .bbm-panel-title {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8A9BB5;
      margin-bottom: 8px;
    }
    .bbm-panel-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .bbm-panel-label {
      font-size: 12px;
      font-weight: 600;
      color: #E8E8E8;
    }
    #bbm-overlay-toggle {
      cursor: pointer;
      width: 14px;
      height: 14px;
      accent-color: #E8BF4A;
    }

    /* Confidence panel — status and sync lines (TASK-106) */
    .bbm-panel-divider {
      border: none;
      border-top: 1px solid #243A5C;
      margin: 8px 0;
    }
    .bbm-panel-status {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
    }
    .bbm-status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #6B7280;
    }
    .bbm-status-label {
      font-size: 11px;
      color: #C0CCE0;
    }
    .bbm-panel-sync-line {
      font-size: 10px;
      color: #8A9BB5;
      margin-top: 3px;
      padding-left: 12px;
    }

    /* Tournament filter (TASK-107) — hierarchical: slate → tournament */
    .bbm-filter-title {
      margin-top: 6px;
      margin-bottom: 4px;
    }
    #bbm-tournament-filter {
      max-height: 140px;
      overflow-y: auto;
    }
    .bbm-filter-check {
      cursor: pointer;
      accent-color: #E8BF4A;
      flex-shrink: 0;
      width: 12px;
      height: 12px;
    }
    .bbm-filter-slate-group {
      border-bottom: 1px solid #1E3054;
    }
    .bbm-filter-slate-group:last-child {
      border-bottom: none;
    }
    .bbm-filter-slate-row {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 3px 0;
    }
    .bbm-filter-slate-label-wrap {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 1;
      cursor: pointer;
      min-width: 0;
    }
    .bbm-filter-slate-label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #8A9BB5;
    }
    .bbm-filter-expand {
      background: none;
      border: none;
      color: #8A9BB5;
      font-size: 7px;
      padding: 0 2px;
      cursor: pointer;
      flex-shrink: 0;
      line-height: 1;
    }
    .bbm-filter-tournaments {
      display: none;
    }
    .bbm-filter-slate-group.bbm-expanded .bbm-filter-tournaments {
      display: block;
    }
    .bbm-filter-tournament-row {
      display: flex;
      align-items: center;
      gap: 5px;
      padding: 2px 0 2px 14px;
      cursor: pointer;
    }
    .bbm-filter-tournament-label {
      font-size: 11px;
      color: #C0CCE0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `,document.head.appendChild(e)}function F(){if($)return;R(),qe(),Ie(),$=ae({targetSelector:b.selectors.gridSelector,onMutation:v,onReconnect:()=>{v()}});const e=document.querySelector(b.selectors.sortButtonsSelector);e&&(S=new MutationObserver(v),S.observe(e,{attributes:!0,subtree:!0})),v()}function G(){$&&($.disconnect(),$=null),S&&(S.disconnect(),S=null),T&&(cancelAnimationFrame(T),T=null),$e(),je()}function Ge(){if(document.getElementById("bbm-fab"))return;const e=document.createElement("button");e.id="bbm-fab",e.title="Best Ball Exposures",e.innerHTML=`<svg width="36" height="36" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Best Ball Exposures">
    <defs>
      <linearGradient id="bb-gold" x1="10" y1="10" x2="38" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%"   stop-color="#F0CC5B"/>
        <stop offset="50%"  stop-color="#D4A843"/>
        <stop offset="100%" stop-color="#E8BF4A"/>
      </linearGradient>
      <linearGradient id="bb-bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#0C1A30"/>
        <stop offset="100%" stop-color="#060E1F"/>
      </linearGradient>
    </defs>
    <circle cx="24" cy="24" r="24" fill="url(#bb-bg)"/>
    <circle cx="24" cy="24" r="22.5" fill="none" stroke="url(#bb-gold)" stroke-width="2"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="#E8BF4A" stroke-width="0.5" opacity="0.18"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="url(#bb-gold)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="18 7 10 7 23 7 8 7.96" transform="rotate(-90 24 24)"/>
    <circle cx="24" cy="24" r="2.5" fill="url(#bb-gold)"/>
  </svg>`;const t=document.createElement("div");t.id="bbm-panel",t.innerHTML=`
    <div class="bbm-panel-title">Best Ball Exposures</div>
    <div id="bbm-auth-section"></div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-row">
      <label class="bbm-panel-label" for="bbm-overlay-toggle">Overlay</label>
      <input type="checkbox" id="bbm-overlay-toggle" />
    </div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-status">
      <span class="bbm-status-dot"></span>
      <span class="bbm-status-label">—</span>
    </div>
    <div class="bbm-panel-sync-line">—</div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-title bbm-filter-title">Tournament Filter</div>
    <div id="bbm-tournament-filter" style="display:none"></div>
  `;const n=t.querySelector("#bbm-overlay-toggle");n.checked=g,t.querySelector(".bbm-panel-status").addEventListener("click",()=>{E==="error"&&R()}),t.addEventListener("click",o=>o.stopPropagation()),e.addEventListener("click",o=>{o.stopPropagation(),t.classList.toggle("open"),t.classList.contains("open")&&(K(),U())}),n.addEventListener("change",()=>{g=n.checked,chrome.storage.local.set({overlayEnabled:g}),g?F():G()}),document.body.appendChild(e),document.body.appendChild(t)}function se(){const e=window.location.href;if(e===Q)return;const t=z;Q=e,z=b.isDraftPage();const n=z;!t&&n?g&&F():t&&!n?G():t&&n&&(G(),g&&F())}function Ke(){setInterval(()=>{window.location.href!==Q&&se()},300),window.addEventListener("popstate",se)}function We(e,t=null){b=e,X=t,chrome.storage.local.get(["overlayEnabled","tournamentFilter"],n=>{g=n.overlayEnabled!==!1,m=new Set(n.tournamentFilter??[]),z=b.isDraftPage(),Ue(),Ge(),Ke(),z&&g?F():R(),document.addEventListener("click",()=>{var r;(r=document.getElementById("bbm-panel"))==null||r.classList.remove("open")}),document.addEventListener("keydown",r=>{var o;r.key==="Escape"&&((o=document.getElementById("bbm-panel"))==null||o.classList.remove("open"))})}),chrome.runtime.onMessage.addListener(n=>{if(n.type!=="TOGGLE_OVERLAY")return;g=n.enabled;const r=document.getElementById("bbm-overlay-toggle");r&&(r.checked=g),g?b.isDraftPage()&&F():G()})}const A=he(window.location.href);A&&(document.querySelector("#root, #app, [data-reactroot]")&&ae({targetSelector:"#root, #app, [data-reactroot]",onMutation:()=>{},onReconnect:()=>{}}),We(A,()=>A.getEntries().then(t=>te(t,{platform:A.platform}))),chrome.runtime.onMessage.addListener((t,n,r)=>t.type!=="SYNC_ENTRIES"?!1:(A.getEntries().then(o=>te(o,{platform:A.platform})).then(({count:o})=>r({ok:!0,count:o})).catch(o=>r({ok:!1,error:o.message})),!0)));
