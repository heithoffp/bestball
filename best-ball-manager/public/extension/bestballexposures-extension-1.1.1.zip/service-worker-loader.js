import './assets/background.js-CwOtuKer.js';
