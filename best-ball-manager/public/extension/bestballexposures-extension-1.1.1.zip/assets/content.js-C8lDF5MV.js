import{s as b,g as Pe}from"./supabase-B-WBL3ue.js";function fe({targetSelector:e,onMutation:t,onReconnect:n,pollInterval:r=500,maxRetries:o=20}){let i=null,l=null,s=null,a=!1;const d={childList:!0,subtree:!0};function c(h){i&&i.disconnect(),i=new MutationObserver(t),i.observe(h,d),l=h}function u(){s&&clearInterval(s);let h=0;s=setInterval(()=>{if(a){clearInterval(s);return}const S=document.querySelector(e);S?(clearInterval(s),s=null,c(S),n==null||n()):++h>=o&&(clearInterval(s),s=null)},r)}const m=new MutationObserver(()=>{if(a)return;const h=document.querySelector(e);!h&&i?(i.disconnect(),i=null,l=null,u()):h&&i&&h!==l&&(c(h),n==null||n())}),f=document.querySelector(e);return f?c(f):u(),m.observe(document.body,{childList:!0,subtree:!0}),{disconnect(){a=!0,s&&clearInterval(s),i&&i.disconnect(),m.disconnect()}}}async function ge(){if(!b)return null;const{data:{session:e}}=await b.auth.getSession();return e}async function Ne(e,t){if(!b)throw new Error("[BBM] Supabase not configured");const{data:n,error:r}=await b.auth.signInWithPassword({email:e,password:t});if(r)throw r;return n.session}async function De(){if(!b)throw new Error("[BBM] Supabase not configured");const e=await new Promise(r=>{chrome.runtime.sendMessage({type:"GOOGLE_OAUTH"},r)});if(e.error)throw new Error(e.error);const{data:t,error:n}=await b.auth.setSession({access_token:e.access_token,refresh_token:e.refresh_token});if(n)throw n;return t.session}async function $e(){b&&await b.auth.signOut()}async function ye(){var e,t,n,r;try{if(!b)return null;const{data:{session:o}}=await b.auth.getSession();if(!o)return null;const i=o.user.id,[l,s]=await Promise.all([b.from("subscriptions").select("status").eq("user_id",i).in("status",["active","trialing"]).limit(1).maybeSingle(),b.from("profiles").select("beta_expires_at, comp_expires_at").eq("id",i).maybeSingle()]),a=((e=l.data)==null?void 0:e.status)==="active"||((t=l.data)==null?void 0:t.status)==="trialing",d=new Date,c=(n=s.data)==null?void 0:n.beta_expires_at,u=(r=s.data)==null?void 0:r.comp_expires_at,m=c?new Date(c)>d:!1,f=u?new Date(u)>d:!1;return a||m||f?"pro":"free"}catch{return null}}async function Fe(){if(!b)return[];const{data:{session:e}}=await b.auth.getSession();if(!e)return[];const{data:t,error:n}=await b.from("extension_entries").select("entry_id").eq("user_id",e.user.id);return n?[]:(t??[]).map(r=>r.entry_id)}async function qe(){if(!b)throw new Error("[BBM] Supabase not configured");const{data:{session:e}}=await b.auth.getSession();if(!e)throw new Error("[BBM] Not authenticated");const{data:t,error:n}=await b.from("extension_entries").select("entry_id, tournament, slate_title, draft_date, players").eq("user_id",e.user.id);if(n)throw n;return(t??[]).map(r=>({entryId:r.entry_id,tournamentTitle:r.tournament,slateTitle:ze(r.slate_title??"",r.tournament),draftDate:r.draft_date,players:r.players??[]}))}function ze(e,t){return!e||!e.startsWith("DK")?e:(t||"").toLowerCase().includes("early bird")?"DK Pre-Draft":"DK Post-Draft"}async function Oe(){if(!b)return null;const{data:{session:e}}=await b.auth.getSession();if(!e)return null;const{data:t,error:n}=await b.from("user_rankings").select("rankings").eq("user_id",e.user.id).maybeSingle();return n||!t?null:t.rankings??null}function ce(e,t){return{user_id:e,entry_id:t.entryId,tournament:t.tournamentTitle??null,slate_title:t.slateTitle??null,draft_date:t.draftDate??null,players:t.players??[],synced_at:new Date().toISOString()}}async function He(e,{platform:t}={}){if(!b)throw new Error("[BBM] Supabase not configured");const{data:{session:n}}=await b.auth.getSession();if(!n)throw new Error("[BBM] Not authenticated");const r=n.user.id;if(!Array.isArray(e)){if(!t)throw new Error("[BBM] Incremental writeEntries requires platform");const{newEntries:c=[],currentDraftIds:u=[]}=e,m=`${t}_entry_ids`,h=(await new Promise(v=>chrome.storage.local.get([m],v)))[m]??[],S=new Set(u.map(String)),H=h.filter(v=>!S.has(String(v)));if(H.length>0){const{error:v}=await b.from("extension_entries").delete().eq("user_id",r).in("entry_id",H);if(v)throw v}if(c.length>0){const v=c.map(Re=>ce(r,Re)),{error:le}=await b.from("extension_entries").upsert(v,{onConflict:"user_id,entry_id"});if(le)throw le}const Z=u.length;return await new Promise(v=>chrome.storage.local.set({lastSync:Date.now(),entryCount:Z,[`${t}_entry_ids`]:u.map(String),[`${t}_lastSync`]:Date.now(),[`${t}_entryCount`]:Z},()=>v())),{count:Z}}const i=e;if(t){const c=`${t}_entry_ids`,m=(await new Promise(f=>chrome.storage.local.get([c],f)))[c]??[];if(m.length>0){const{error:f}=await b.from("extension_entries").delete().eq("user_id",r).in("entry_id",m);if(f)throw f}else if(t==="underdog"){const{error:f}=await b.from("extension_entries").delete().eq("user_id",r);if(f)throw f}}else{const{error:c}=await b.from("extension_entries").delete().eq("user_id",r);if(c)throw c}if(i.length===0){const c={lastSync:Date.now(),entryCount:0};return t&&(c[`${t}_lastSync`]=Date.now(),c[`${t}_entryCount`]=0),await new Promise(u=>chrome.storage.local.set(c,()=>u())),{count:0}}const l=i.map(c=>ce(r,c)),{error:s,count:a}=await b.from("extension_entries").upsert(l,{onConflict:"user_id,entry_id",count:"exact"});if(s)throw s;const d={lastSync:Date.now(),entryCount:i.length};return t&&(d[`${t}_entry_ids`]=i.map(c=>c.entryId),d[`${t}_lastSync`]=Date.now(),d[`${t}_entryCount`]=i.length),await new Promise(c=>chrome.storage.local.set(d,()=>c())),{count:a??i.length}}const Ue=/\s+(jr\.?|sr\.?|ii|iii|iv|v)\s*$/i;function R(e=""){return String(e).trim().replace(/^"|"$/g,"").replace(Ue,"").replace(/\./g,"").replace(/\s+/g," ").trim().toLowerCase()}const We="Real NFL 2026 W15/16/17 schedule (released 2026-05-14). Source: 2026 SCHEDULE RELEASE GRID (@OzzyNFL).",Ge={15:"NYJ",16:"NO",17:"LV"},je={15:"WAS",16:"TB",17:"NO"},Ke={15:"PIT",16:"CLE",17:"CIN"},Qe={15:"CHI",16:"DEN",17:"MIA"},Ye={15:"CIN",16:"PIT",17:"SEA"},Je={15:"BUF",16:"GB",17:"DET"},Ve={15:"CAR",16:"IND",17:"BAL"},Xe={15:"NYG",16:"BAL",17:"IND"},Ze={15:"LAR",16:"JAX",17:"NYG"},et={15:"LV",16:"BUF",17:"NE"},tt={15:"MIN",16:"NYG",17:"CHI"},nt={15:"MIA",16:"CHI",17:"HOU"},rt={15:"JAX",16:"PHI",17:"GB"},ot={15:"TEN",16:"CIN",17:"CLE"},st={15:"HOU",16:"DAL",17:"WAS"},it={15:"NE",16:"SF",17:"LAC"},at={15:"DEN",16:"TEN",17:"ARI"},lt={15:"SF",16:"MIA",17:"KC"},ct={15:"DAL",16:"SEA",17:"TB"},dt={15:"GB",16:"LAC",17:"BUF"},pt={15:"DET",16:"WAS",17:"NYJ"},ut={15:"KC",16:"NYJ",17:"DEN"},bt={15:"TB",16:"ARI",17:"ATL"},mt={15:"CLE",16:"DET",17:"DAL"},ft={15:"ARI",16:"NE",17:"MIN"},gt={15:"SEA",16:"HOU",17:"SF"},yt={15:"BAL",16:"CAR",17:"TEN"},ht={15:"LAC",16:"KC",17:"PHI"},xt={15:"PHI",16:"LAR",17:"CAR"},wt={15:"NO",16:"ATL",17:"LAR"},vt={15:"IND",16:"LV",17:"PIT"},Et={15:"ATL",16:"MIN",17:"JAX"},de={_README:We,ARI:Ge,ATL:je,BAL:Ke,BUF:Qe,CAR:Ye,CHI:Je,CIN:Ve,CLE:Xe,DAL:Ze,DEN:et,DET:tt,GB:nt,HOU:rt,IND:ot,JAX:st,KC:it,LV:at,LAC:lt,LAR:ct,MIA:dt,MIN:pt,NE:ut,NO:bt,NYG:mt,NYJ:ft,PHI:gt,PIT:yt,SF:ht,SEA:xt,TB:wt,TEN:vt,WAS:Et},kt=["15","16","17"],St=Object.freeze({QB:new Set(["QB","WR","TE"]),WR:new Set(["QB","WR","TE"]),TE:new Set(["QB","WR"])}),At=Object.freeze({QB:new Set(["QB","WR","TE","RB"]),WR:new Set(["QB","WR","TE","RB"]),TE:new Set(["QB","WR","RB"]),RB:new Set(["QB","WR","TE","RB"])});function Ct(e){return e==="17"?At:St}const J="data-bbm-injected",he="data-bbm-player-id",U="data-bbm-headers-injected";let p=null,g=null,_=null,x=!0,D=null,te=window.location.href,W=!1,E=new Map,k=new Map,C=new Map,N=new Map,F=0,P=[],Y=new Map,M=null,$=null,ne=new Map,re=new Set,B=null,I="idle",oe=null,se=null,w=null;const Bt="https://bestballexposures.com/?upgrade=1";let A=[],G=[],y=new Set,K=new Set;const pe=["S","A+","A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"],It={S:"#ffd700","A+":"#ef4444",A:"#f87171","A-":"#fb923c","B+":"#f59e0b",B:"#eab308","B-":"#a3e635","C+":"#10b981",C:"#06b6d4","C-":"#3b82f6","D+":"#6366f1",D:"#8b5cf6","D-":"#a855f7",F:"#6b7280"};function xe(e){const t=Math.max(0,Math.min(e-1,pe.length-1));return pe[t]}function Lt(e){return It[xe(e)]||"#555"}function Tt(e){const t=(e==null?void 0:e.message)??"";return t.includes("Not authenticated")||t.includes("JWT")?"Session expired — sign in again":t.includes("fetch")||t.includes("network")||t.includes("NetworkError")?"Connection lost — tap to retry":"Load failed — tap to retry"}function ee(e){const t=Math.floor((Date.now()-e)/1e3);return t<60?"just now":t<3600?`${Math.floor(t/60)}m ago`:t<86400?`${Math.floor(t/3600)}h ago`:`${Math.floor(t/86400)}d ago`}async function V(){const e=document.querySelector(".bbm-status-dot"),t=document.querySelector(".bbm-status-label"),n=document.querySelector(".bbm-panel-sync-line");if(!e||!t||!n)return;const r=await ge();let o,i;r?I==="loading"?(o="#6B7280",i="Loading portfolio…"):I==="error"?(o="#EF4444",i=oe??"Load failed — tap to retry"):(o="#10B981",i="Connected"):(o="#F59E0B",i="Not signed in"),e.style.background=o,t.textContent=i;const l=document.querySelector(".bbm-panel-status");if(l&&(l.style.cursor=I==="error"?"pointer":"default"),I==="loading"){n.textContent="Fetching entries…";return}if(!r){n.textContent="—";return}chrome.storage.local.get(["lastSync","entryCount","underdog_lastSync","underdog_entryCount","draftkings_lastSync","draftkings_entryCount"],s=>{const a=[];s.underdog_lastSync&&a.push(`UD: ${s.underdog_entryCount??0} · ${ee(s.underdog_lastSync)}`),s.draftkings_lastSync&&a.push(`DK: ${s.draftkings_entryCount??0} · ${ee(s.draftkings_lastSync)}`),a.length>0?n.textContent=a.join("  |  "):s.lastSync?n.textContent=`${s.entryCount??0} entries · synced ${ee(s.lastSync)}`:n.textContent="Not yet synced"})}function ie(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function we(e){return String(e??"").replace(/\b\w/g,t=>t.toUpperCase())}function ve(){const e=document.getElementById("bbm-tournament-filter");if(e){if(A.length===0){e.style.display="none";return}e.style.display="block",e.innerHTML=A.map((t,n)=>{const r=K.has(t.slate);return`
      <div class="bbm-filter-slate-group${r?" bbm-expanded":""}" data-si="${n}">
        <div class="bbm-filter-slate-row">
          <label class="bbm-filter-slate-label-wrap">
            <input type="checkbox" class="bbm-filter-check bbm-filter-slate-check" data-si="${n}" />
            <span class="bbm-filter-slate-label">${ie(t.slate)}</span>
          </label>
          <button type="button" class="bbm-filter-expand" data-si="${n}">${r?"▼":"▶"}</button>
        </div>
        <div class="bbm-filter-tournaments">
          ${t.tournaments.map((o,i)=>`
            <label class="bbm-filter-tournament-row">
              <input type="checkbox" class="bbm-filter-check bbm-filter-tournament-check"
                data-si="${n}" data-ti="${i}"
                ${y.has(o)?"checked":""} />
              <span class="bbm-filter-tournament-label">${ie(o)}</span>
            </label>
          `).join("")}
        </div>
      </div>
    `}).join(""),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{const{tournaments:n}=A[parseInt(t.dataset.si)],r=n.filter(o=>y.has(o)).length;t.checked=r===n.length,t.indeterminate=r>0&&r<n.length}),e.querySelectorAll(".bbm-filter-expand").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const r=A[parseInt(t.dataset.si)];K.has(r.slate)?K.delete(r.slate):K.add(r.slate),ve()})}),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{t.addEventListener("change",()=>{const{tournaments:n}=A[parseInt(t.dataset.si)];n.every(o=>y.has(o))?n.forEach(o=>y.delete(o)):n.forEach(o=>y.add(o)),chrome.storage.local.set({tournamentFilter:[...y]}),ae()})}),e.querySelectorAll(".bbm-filter-tournament-check").forEach(t=>{t.addEventListener("change",()=>{const n=A[parseInt(t.dataset.si)].tournaments[parseInt(t.dataset.ti)];t.checked?y.add(n):y.delete(n),chrome.storage.local.set({tournamentFilter:[...y]}),ae()})})}}function ae(){var r,o,i,l;const e=y.size===0?G:G.filter(s=>y.has(s.tournamentTitle));F=e.length,E=new Map,k=new Map,C=new Map,N=new Map;const t=new Map;e.forEach((s,a)=>{(s.players??[]).forEach(d=>{if(!d.name)return;const c=R(d.name);if(!c)return;E.has(c)||E.set(c,new Set),E.get(c).add(a),d.team&&!k.has(c)&&k.set(c,d.team),d.position&&!C.has(c)&&C.set(c,d.position);const u=Number(d.pick);Number.isFinite(u)&&u>0&&(t.has(c)||t.set(c,[]),t.get(c).push(u))})});function n(s){const a=t.get(s);if(!a||a.length===0)return null;const d=[...a].sort((u,m)=>u-m),c=Math.floor(d.length/2);return d.length%2?d[c]:(d[c-1]+d[c])/2}for(const s of E.keys()){const a=s.split(/\s+/);if(a.length<2)continue;const d=a[0][0],c=a.slice(1).join(" "),u=`${d} ${c}`;if(N.has(u)){const m=N.get(u),f={fullName:s,position:((r=C.get(s))==null?void 0:r.toUpperCase())??null,team:((o=k.get(s))==null?void 0:o.toUpperCase())??null,medianPick:n(s)};typeof m=="string"?N.set(u,[{fullName:m,position:((i=C.get(m))==null?void 0:i.toUpperCase())??null,team:((l=k.get(m))==null?void 0:l.toUpperCase())??null,medianPick:n(m)},f]):Array.isArray(m)&&m.push(f)}else N.set(u,s)}ve(),L()}async function q(){w=await ye(),Ee()}function Ee(){var o;const e=w==="pro",t=document.getElementById("bbm-overlay-row"),n=document.getElementById("bbm-overlay-toggle");t&&n&&(e?(t.classList.remove("bbm-locked"),t.removeAttribute("title"),n.disabled=!1,n.checked=x):(t.classList.add("bbm-locked"),t.setAttribute("title","Pro feature — upgrade to use the overlay"),n.disabled=!0,n.checked=!1));const r=document.getElementById("bbm-filter-wrap");r&&(r.style.display=e?"":"none"),_t(),e?(o=p==null?void 0:p.isDraftPage)!=null&&o.call(p)&&x&&!_&&z():_||B||M?j():Me()}function _t(){const e=document.getElementById("bbm-upgrade-cta");if(e){if(w==="pro"){e.innerHTML="",e.style.display="none";return}e.style.display="block",e.innerHTML=`
    <a href="${Bt}" target="_blank" rel="noopener noreferrer" class="bbm-upgrade-btn">
      <span class="bbm-upgrade-icon" aria-hidden="true">★</span>
      Upgrade to Pro
    </a>
    <div class="bbm-upgrade-sub">Unlock the in-draft overlay</div>
  `}}async function X(){const e=document.getElementById("bbm-auth-section");if(!e)return;const t=await ge();if(t){const n=await ye(),r=n?`<span class="bbm-auth-tier ${n}">${n==="pro"?"Pro":"Free"}</span>`:"";e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <div class="bbm-auth-user">${ie(t.user.email)}</div>
        ${r}
        <button id="bbm-sign-out-btn" class="bbm-btn bbm-btn-secondary">Sign Out</button>
      </div>
      <button id="bbm-sync-btn" class="bbm-btn" style="margin-top:6px">Sync Now</button>
      <div id="bbm-sync-progress" class="bbm-sync-progress bbm-progress-indeterminate" style="display:none">
        <div class="bbm-progress-label">Discovering entries…</div>
        <div class="bbm-progress-bar-wrap"><div class="bbm-progress-bar-fill"></div></div>
      </div>
      <div id="bbm-sync-result" class="bbm-sync-result" style="display:none"></div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",ue),e.querySelector("#bbm-sync-btn").addEventListener("click",Pt),e.querySelector("#bbm-sign-out-btn").addEventListener("click",Rt)}else{e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron" style="transform:rotate(180deg)">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:block">
        <button id="bbm-google-btn" class="bbm-btn bbm-btn-google">
          <svg width="16" height="16" viewBox="0 0 48 48" style="flex-shrink:0"><path fill="#4285F4" d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z"/><path fill="#34A853" d="M6.3 14.7l7 5.1C15 15.6 19.1 12 24 12c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 16.3 2 9.7 7.3 6.3 14.7z"/><path fill="#FBBC05" d="M24 46c5.4 0 10.3-1.8 14.1-5l-6.9-5.7C29.1 37 26.7 38 24 38c-6 0-10.6-3.9-12.3-9.2l-7 5.4C8.1 41 15.4 46 24 46z"/><path fill="#EA4335" d="M46 24c0-1.3-.2-2.7-.5-4H24v8.5h11.8c-1 3-3 5.4-5.8 7l6.9 5.7C41 37.5 46 31.5 46 24z"/></svg>
          Sign in with Google
        </button>
        <div class="bbm-auth-divider"><span>or</span></div>
        <input type="email" id="bbm-auth-email" class="bbm-auth-input" placeholder="Email" autocomplete="email" />
        <input type="password" id="bbm-auth-password" class="bbm-auth-input" placeholder="Password" autocomplete="current-password" />
        <button id="bbm-sign-in-btn" class="bbm-btn">Sign In</button>
        <div id="bbm-auth-error" class="bbm-auth-error" style="display:none"></div>
      </div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",ue),e.querySelector("#bbm-google-btn").addEventListener("click",Mt),e.querySelector("#bbm-sign-in-btn").addEventListener("click",be);for(const n of e.querySelectorAll(".bbm-auth-input"))for(const r of["keydown","keypress","keyup"])n.addEventListener(r,o=>o.stopPropagation());e.querySelector("#bbm-auth-password").addEventListener("keydown",n=>{n.key==="Enter"&&be()})}}function ue(){const e=document.getElementById("bbm-account-body"),t=document.querySelector(".bbm-account-chevron");if(!e)return;const n=e.style.display!=="none";e.style.display=n?"none":"block",t&&(t.style.transform=n?"":"rotate(180deg)")}async function Mt(){const e=document.getElementById("bbm-google-btn"),t=document.getElementById("bbm-auth-error");if(e){e.disabled=!0,t&&(t.style.display="none");try{await De(),await q(),await X(),O()}catch(n){t&&(t.textContent=n.message??"Google sign-in failed",t.style.display="block"),e&&(e.disabled=!1)}}}async function be(){var o,i;const e=(o=document.getElementById("bbm-auth-email"))==null?void 0:o.value.trim(),t=(i=document.getElementById("bbm-auth-password"))==null?void 0:i.value,n=document.getElementById("bbm-sign-in-btn"),r=document.getElementById("bbm-auth-error");if(!(!e||!t||!n)){n.disabled=!0,r&&(r.style.display="none");try{await Ne(e,t),await q(),await X(),O()}catch(l){r&&(r.textContent=l.message??"Sign in failed",r.style.display="block"),n&&(n.disabled=!1)}}}async function Rt(){await $e(),E=new Map,k=new Map,C=new Map,F=0,G=[],A=[],w=null,await X(),Ee(),V()}async function Pt(){const e=document.getElementById("bbm-sync-btn"),t=document.getElementById("bbm-sync-result"),n=document.getElementById("bbm-sync-progress");if(!e)return;if(e.disabled=!0,t&&(t.style.display="none",t.className="bbm-sync-result"),n&&(n.style.display="none"),!se){t&&(t.textContent=p.syncPageErrorMessage,t.classList.add("error"),t.style.display="block"),e.disabled=!1;return}const r=n==null?void 0:n.querySelector(".bbm-progress-label"),o=n==null?void 0:n.querySelector(".bbm-progress-bar-fill");function i(l){var c;if(l.source!==window||((c=l.data)==null?void 0:c.type)!=="BBM_SYNC_PROGRESS")return;const{phase:s,done:a,total:d}=l.data;if(n){if(n.style.display="block",s==="discovery")n.classList.add("bbm-progress-indeterminate"),r&&(r.textContent="Discovering entries…"),o&&(o.style.width="0%");else if(s==="fetching"){n.classList.remove("bbm-progress-indeterminate");const u=d>0?Math.round(a/d*100):0;r&&(r.textContent=`Processing ${a} / ${d} entries…`),o&&(o.style.width=u+"%")}}}window.addEventListener("message",i);try{const{count:l}=await se();t&&(t.textContent=`Synced ${l} entries`,t.style.display="block"),O()}catch(l){if(t){const s=l.message??"Sync failed";t.textContent=s.includes("Could not establish connection")?p.syncPageErrorMessage:s,t.classList.add("error"),t.style.display="block"}}finally{window.removeEventListener("message",i),n&&(n.style.display="none"),e&&(e.disabled=!1)}}async function O(){I="loading",V();try{G=await qe();const e=new Map;G.forEach(r=>{if(!r.tournamentTitle)return;const o=r.slateTitle||"Other";e.has(o)||e.set(o,new Set),e.get(o).add(r.tournamentTitle)}),A=[...e.entries()].sort(([r],[o])=>r.localeCompare(o)).map(([r,o])=>({slate:r,tournaments:[...o].sort()}));const t=new Set(A.flatMap(r=>r.tournaments)),n=y.size;y=new Set([...y].filter(r=>t.has(r))),y.size===0&&t.forEach(r=>y.add(r)),y.size!==n&&chrome.storage.local.set({tournamentFilter:[...y]}),ae(),I="ready",oe=null}catch(e){I="error",oe=Tt(e),console.warn("[BBM] Could not load portfolio data:",e.message)}finally{V()}}async function Nt(){try{const e=await Oe();if(!e)return;ne=new Map(e.map(t=>[t.name,{rank:t.rank,tierNum:t.tierNum}])),re=new Set;for(let t=1;t<e.length;t++)e[t].tierNum!==e[t-1].tierNum&&re.add(e[t].rank);L()}catch(e){console.warn("[BBM] Could not load rankings data:",e.message)}}function ke(){let e;if(p.getCurrentPicks){const n=p.getCurrentPicks();if(!n)return;e=n.map(r=>({name:T(r.name,{position:r.position,team:r.team})??r.name,position:r.position,round:r.round}))}else e=[],document.querySelectorAll(p.selectors.myPicksSelector).forEach((r,o)=>{var d,c,u;const i=r.querySelector(p.selectors.playerNameInRowSelector),l=r.closest(p.selectors.positionSectionSelector),s=((c=(d=l==null?void 0:l.querySelector(p.selectors.positionHeaderSelector))==null?void 0:d.textContent)==null?void 0:c.trim())??"",a=(u=i==null?void 0:i.textContent)==null?void 0:u.trim();a&&e.push({name:a,position:s,round:o+1})});let t=!1;e.forEach(n=>{const r=R(n.name);if(!r)return;const o=Y.get(r);if(!o){Y.set(r,{name:n.name,position:n.position,round:n.round??null}),t=!0;return}(o.round==null||o.round===0)&&n.round!=null&&n.round>0&&(o.round=n.round,t=!0)}),t&&(P=[...Y.values()],L())}function Dt(){$||($=requestAnimationFrame(()=>{$=null,ke()}))}function $t(){M||(M=new MutationObserver(Dt),M.observe(document.body,{childList:!0,subtree:!0}),ke())}function Ft(){$&&(cancelAnimationFrame($),$=null),M&&(M.disconnect(),M=null),P=[],Y.clear()}function Se(e){var n;const t=e.querySelector(p.selectors.playerNameInRowSelector);return((n=t==null?void 0:t.textContent)==null?void 0:n.trim())??null}function T(e,t){if(!e)return null;const n=R(e);if(E.has(n))return n;const r=R(e),o=N.get(r);if(typeof o=="string")return o;if(Array.isArray(o)&&t){const i=t instanceof Element&&p.getPlayerContext?p.getPlayerContext(t):t;let l=o;if(i.position){const s=i.position.toUpperCase(),a=l.filter(d=>d.position===s);if(a.length===1)return a[0].fullName;a.length>1&&(l=a)}if(i.team){const s=i.team.toUpperCase(),a=l.filter(d=>d.team===s);if(a.length===1)return a[0].fullName;a.length>1&&(l=a)}if(l.length>1&&Number.isFinite(i.adp)){const s=l.filter(a=>Number.isFinite(a.medianPick));if(s.length>=1){let a=s[0],d=Math.abs(a.medianPick-i.adp);for(let c=1;c<s.length;c++){const u=Math.abs(s[c].medianPick-i.adp);u<d&&(a=s[c],d=u)}return console.debug(`[BBM] ambig "${e}" rowADP=${i.adp} → ${a.fullName} (medianPick=${a.medianPick})`),a.fullName}}l.length>1&&console.debug(`[BBM] ambig "${e}" unresolved`,{ctx:i,candidates:l.map(s=>({full:s.fullName,pos:s.position,team:s.team,med:s.medianPick}))})}return null}function Ae(e){if(F===0)return 0;const t=T(e);if(!t)return 0;const n=E.get(t);return n?n.size/F*100:0}function Ce(e){const t=T(e),n=(t&&E.get(t))??new Set,r=[];let o=0,i=0;return P.forEach(l=>{const s=E.get(R(l.name))??new Set;if(s.size===0)return;let a=0;s.size<n.size?s.forEach(c=>{n.has(c)&&a++}):n.forEach(c=>{s.has(c)&&a++});const d=a/s.size;o+=d,i++,r.push({name:l.name,position:l.position,round:l.round,pct:Math.round(d*100)})}),{score:i>0?Math.round(o/i*100):0,breakdown:r}}function qt(e){const t=e.querySelector(".bbm-stat-cell:not(.bbm-corr-trigger)"),n=e.querySelector(".bbm-corr-trigger");if(!t||!n)return;const r=Se(e);if(!r||F===0)return;const o=T(r,e)??r,i=Ae(o);t.textContent=`${Math.round(i)}%`;const l=n.querySelector(".bbm-corr-value"),s=n.querySelector(".bbm-corr-popup");if(!l||!s)return;const{score:a,breakdown:d}=Ce(o);l.textContent=`${a}%`,Be(s,d),Ie(e,o),Le(e,o),_e(e,o)}function Be(e,t){if(t.length===0){e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No picks yet</div>';return}e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div>'+t.map(n=>`<div class="bbm-corr-popup-row">
          <span class="bbm-corr-popup-pos">${n.position}</span>
          <span class="bbm-corr-popup-name">${we(n.name)}</span>
          <div class="bbm-corr-popup-bar">
            <div class="bbm-corr-popup-bar-fill" style="width:${n.pct}%;background:#3b82f6"></div>
          </div>
          <span class="bbm-corr-popup-pct">${n.pct}%</span>
        </div>`).join("")}function Ie(e,t){e.querySelectorAll(".bbm-stack-pill").forEach(i=>i.remove());const n=zt(t);if(!n)return;const r=e.querySelector(p.selectors.stackPillTargetSelector);if(!r)return;const o=document.createElement("span");o.className="bbm-stack-pill bbm-inline-overlay",o.textContent=n.type,o.style.color=n.color,o.style.borderColor=n.color,o.style.background=`${n.color}1A`,r.appendChild(o)}function zt(e){const t=T(e);if(!t)return null;const n=k.get(t),r=C.get(t);if(!n||!r||P.length===0)return null;const o=P.filter(d=>{const c=k.get(R(d.name));return c&&c===n});if(o.length===0)return null;const i=o.filter(d=>d.position==="QB"),l=o.filter(d=>d.position==="WR"),s=o.filter(d=>d.position==="TE"),a=o.filter(d=>d.position==="RB");return r==="QB"&&(l.length>0||s.length>0||a.length>0)?{type:l.length+s.length+a.length>=2?"QB MULTI":"QB STACK",color:"#BF44EF"}:(r==="WR"||r==="TE"||r==="RB")&&i.length>0?{type:l.length+s.length+a.length>=1?"QB MULTI":"QB STACK",color:"#BF44EF"}:r==="WR"&&l.length>=1?{type:`WR ×${l.length+1}`,color:"#F59E0B"}:r==="TE"&&s.length>=1?{type:`TE ×${s.length+1}`,color:"#3B82F6"}:r==="RB"&&a.length>=1?{type:`RB ×${a.length+1}`,color:"#10B981"}:r==="RB"&&(l.length>0||s.length>0)?{type:"TEAM",color:"#8A9BB5"}:(r==="WR"||r==="TE")&&a.length>0?{type:"TEAM",color:"#8A9BB5"}:null}function Ot(e){const t=T(e);if(!t)return null;const n=k.get(t),r=C.get(t);if(!n||!r||P.length===0)return null;const o=[];let i=0;return kt.forEach(l=>{var c;const s=Ct(l)[r];if(!s)return;const a=(c=de[n])==null?void 0:c[l];if(!a)return;const d=[];P.forEach(u=>{var H;const m=R(u.name),f=k.get(m),h=C.get(m);if(!f||!h||f===n||f!==a)return;const S=(H=de[f])==null?void 0:H[l];S&&S!==n||s.has(h)&&d.push({name:u.name,position:h,team:f,opp:n})}),d.length>0&&(o.push({week:l,entries:d}),i+=d.length)}),i===0?null:{count:i,weeks:o}}function Le(e,t){const n=w==="pro"?Ot(t):null,r=n?JSON.stringify(n):"",o=e.querySelector(".bbm-playoff-pill");if(o&&o._playoffSig===r||(o&&(g&&o._ownsPortal&&(g.style.display="none"),o.remove()),!n))return;const i=e.querySelector(p.selectors.stackPillTargetSelector);if(!i)return;const l=document.createElement("span");if(l.className="bbm-playoff-pill bbm-inline-overlay",n.weeks.length===1){const s=n.weeks[0];l.innerHTML=`<span class="bbm-playoff-chip bbm-playoff-w${s.week}">W${s.week}<span class="bbm-playoff-chip-count">${s.entries.length}</span></span>`}else{const s=n.weeks.map(a=>a.week).join("/");l.innerHTML=`<span class="bbm-playoff-chip bbm-playoff-multi">W${s}<span class="bbm-playoff-chip-count">${n.count}</span></span>`}l._playoffPayload=n,l._playoffSig=r,i.appendChild(l),Ut(l)}function Ht(e){return`<div class="bbm-corr-popup-title">Playoff Game Stacks</div>${e.weeks.map(n=>{const r=n.entries.map(o=>`
      <div class="bbm-corr-popup-row">
        <span class="bbm-corr-popup-pos">${o.position}</span>
        <span class="bbm-corr-popup-name">${we(o.name)}</span>
        <span class="bbm-playoff-popup-matchup">${o.team} @ ${o.opp}</span>
      </div>`).join("");return`<div class="bbm-playoff-popup-week bbm-playoff-w${n.week}">Week ${n.week}</div>${r}`}).join("")}`}function Ut(e){e.addEventListener("mouseenter",()=>{if(!e._playoffPayload)return;Te(),g.innerHTML=Ht(e._playoffPayload);const t=e.getBoundingClientRect();g.style.left=`${Math.max(8,t.right-280)}px`,g.style.top=`${t.bottom+4}px`,g.style.display="block",e._ownsPortal=!0}),e.addEventListener("mouseleave",()=>{e._ownsPortal=!1,g&&(g.style.display="none")})}function Wt(){const e=document.createElement("div");e.className="bbm-inline-overlay bbm-stat-cell",e.textContent="--%";const t=document.createElement("div");t.className="bbm-inline-overlay bbm-stat-cell bbm-corr-trigger";const n=document.createElement("span");n.className="bbm-corr-value",n.textContent="--";const r=document.createElement("div");return r.className="bbm-corr-popup",r.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No draft data yet</div>',t.appendChild(n),t.appendChild(r),t.addEventListener("mouseenter",()=>{Te(),g.innerHTML=r.innerHTML;const o=t.getBoundingClientRect();g.style.left=`${Math.max(8,o.right-280)}px`,g.style.top=`${o.bottom+4}px`,g.style.display="block"}),t.addEventListener("mouseleave",()=>{g&&(g.style.display="none")}),[e,t]}function Te(){g&&document.body.contains(g)||(g=document.createElement("div"),g.className="bbm-corr-popup",g.id="bbm-corr-popup-portal",g.style.cssText="display: none; position: fixed; z-index: 10001;",document.body.appendChild(g))}function Gt(e){var d,c;const t=((d=p.getRowId)==null?void 0:d.call(p,e))??e.getAttribute("data-id");if(!t)return;if(e.getAttribute(J)===t){qt(e);return}e.querySelectorAll(".bbm-inline-overlay").forEach(u=>u.remove()),e.querySelectorAll(".bbm-tier-badge").forEach(u=>u.remove()),e.removeAttribute("data-bbm-tier");const{parent:r,before:o}=((c=p.getInjectionPoint)==null?void 0:c.call(p,e))??{};if(!r)return;const[i,l]=Wt();o?(r.insertBefore(i,o),r.insertBefore(l,o)):r.append(i,l),p.postInjectRow&&p.postInjectRow(e,i,l),e.setAttribute(J,t),e.setAttribute(he,t);const s=Se(e),a=T(s,e)??s;if(F>0&&a){const u=Ae(a);i.textContent=`${Math.round(u)}%`;const{score:m,breakdown:f}=Ce(a),h=l.querySelector(".bbm-corr-value"),S=l.querySelector(".bbm-corr-popup");h.textContent=`${m}%`,Be(S,f)}a&&(Ie(e,a),Le(e,a)),_e(e,a)}function _e(e,t){if(e.querySelectorAll(".bbm-tier-badge").forEach(d=>d.remove()),e.removeAttribute("data-bbm-tier"),!p.isMyRankSort()||ne.size===0||!t)return;const n=T(t),r=ne.get(n??t.trim().toLowerCase());if(!r)return;const{tierNum:o,rank:i}=r;if(e.setAttribute("data-bbm-tier",String(o)),!re.has(i))return;const l=Lt(o),s=xe(o),a=document.createElement("div");a.className="bbm-tier-badge",a.style.color=l,a.innerHTML=`<span class="bbm-tier-pill">${s}</span>`,e.prepend(a)}function jt(){const e=document.querySelector(p.selectors.sortButtonsSelector);if(!e||(B||(B=new MutationObserver(L),B.observe(e,{attributes:!0,subtree:!0})),e.hasAttribute(U)))return;if(p.injectHeaderCells){p.injectHeaderCells(e),e.setAttribute(U,"true");return}const t=document.querySelector(p.selectors.rowSelector);if(!t)return;const n=e.getBoundingClientRect(),r=t.querySelectorAll(".bbm-stat-cell");if(r.length<2)return;const o=r[0].getBoundingClientRect(),i=r[1].getBoundingClientRect(),l=n.right,s=l-o.right,a=l-i.right;e.style.position="relative";const d=document.createElement("span");d.className="bbm-header-label",d.textContent="Exp",d.style.right=`${s}px`,d.style.width=`${o.width}px`;const c=document.createElement("span");c.className="bbm-header-label",c.textContent="Corr",c.style.right=`${a}px`,c.style.width=`${i.width}px`,e.appendChild(d),e.appendChild(c),e.setAttribute(U,"true")}function Kt(){document.querySelectorAll(".bbm-header-label").forEach(e=>e.remove()),document.querySelectorAll(`[${U}]`).forEach(e=>{e.removeAttribute(U)})}function L(){D||(D=requestAnimationFrame(()=>{var t;if(D=null,!x||w!=="pro")return;(((t=p.getPlayerRows)==null?void 0:t.call(p))??document.querySelectorAll(p.selectors.rowSelector)).forEach(Gt),jt()}))}function Me(){document.querySelectorAll(".bbm-inline-overlay").forEach(e=>e.remove()),document.querySelectorAll(".bbm-tier-badge").forEach(e=>e.remove()),document.querySelectorAll("[data-bbm-tier]").forEach(e=>e.removeAttribute("data-bbm-tier")),document.querySelectorAll(`[${J}]`).forEach(e=>{e.removeAttribute(J),e.removeAttribute(he)}),Kt(),g&&(g.remove(),g=null)}function Qt(){if(document.getElementById("bbm-overlay-styles"))return;const e=document.createElement("style");e.id="bbm-overlay-styles",e.textContent=`
    /* DK: allow overlay cells to overflow fixed-width rows (scoped to rows, not scroll container) */
    .BaseTable__row {
      overflow: visible !important;
    }

    .bbm-stat-cell {
      color: inherit;
      opacity: 0.6;
      font-family: inherit;
      font-size: 11px;
      white-space: nowrap;
      flex-shrink: 0;
      width: 40px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }
    .bbm-stat-cell + .bbm-stat-cell {
      margin-left: 12px;
    }

    /* Corr cell is hoverable */
    .bbm-corr-trigger {
      pointer-events: auto;
      cursor: default;
      position: relative;
    }
    .bbm-corr-trigger:hover {
      opacity: 1;
    }

    /* Correlation popup — hidden by default, shown via JS mouseenter/mouseleave */
    .bbm-corr-popup {
      display: none;
      background: var(--bg-primary, #1a1a2e);
      color: #E8E8E8;
      border: 1px solid var(--border-color, #333);
      border-radius: 8px;
      padding: 8px 0;
      z-index: 10001;
      min-width: 220px;
      max-width: 300px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      white-space: normal;
      text-align: left;
      opacity: 1;
    }
    .bbm-corr-popup-title {
      padding: 0 12px 6px;
      font-size: 10px;
      color: #E8E8E8;
      opacity: 0.5;
      text-transform: uppercase;
      font-weight: 700;
      letter-spacing: 0.05em;
    }
    .bbm-corr-popup-empty {
      padding: 4px 12px;
      font-size: 12px;
      color: #E8E8E8;
      opacity: 0.4;
      font-style: italic;
    }

    /* Rows for when real data is wired in */
    .bbm-corr-popup-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 12px;
    }
    .bbm-corr-popup-pos {
      font-size: 10px;
      font-weight: 900;
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 22px;
      text-align: center;
    }
    .bbm-corr-popup-name {
      font-size: 12px;
      font-weight: 600;
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-corr-popup-bar {
      width: 40px;
      height: 5px;
      background: rgba(128, 128, 128, 0.3);
      border-radius: 3px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .bbm-corr-popup-bar-fill {
      height: 100%;
      border-radius: 3px;
    }
    .bbm-corr-popup-pct {
      font-size: 11px;
      font-weight: 700;
      font-family: monospace;
      min-width: 28px;
      text-align: right;
    }

    /* Stack pill — inline after player name, only visible when stacking */
    .bbm-stack-pill {
      display: inline-block;
      vertical-align: middle;
      margin-left: 6px;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid;
      line-height: 1.5;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0.85;
    }

    /* Playoff game-stack pill (TASK-232) — container for per-week chips colored
       bronze/silver/gold (W15/W16/W17) to differentiate weeks at a glance.
       Interactive (hover opens the shared correlation popup with playoff-grouped
       contents). */
    .bbm-playoff-pill {
      display: inline-flex;
      vertical-align: middle;
      align-items: center;
      gap: 3px;
      margin-left: 4px;
      line-height: 1.5;
      white-space: nowrap;
      cursor: default;
    }
    .bbm-playoff-chip {
      display: inline-flex;
      align-items: center;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid currentColor;
      background: rgba(255, 255, 255, 0.04);
      opacity: 0.95;
    }
    .bbm-playoff-chip-count {
      display: inline-block;
      margin-left: 4px;
      color: currentColor;
      font-weight: 800;
      text-align: center;
    }
    /* W15 bronze, W16 silver, W17 gold for single-week chips and popup
       section headers. Multi-week collapses to a single red pill (so the
       red signals "spans multiple playoff weeks" at a glance). */
    .bbm-playoff-w15 { color: #CD7F32; }
    .bbm-playoff-w16 { color: #C9CED6; }
    .bbm-playoff-w17 { color: #FFD700; }
    .bbm-playoff-multi { color: #EF4444; }

    .bbm-playoff-popup-week {
      margin-top: 8px;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      opacity: 0.95;
    }
    .bbm-playoff-popup-week:first-child {
      margin-top: 4px;
    }
    .bbm-playoff-popup-matchup {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.04em;
      color: inherit;
      opacity: 0.65;
      margin-left: auto;
      white-space: nowrap;
    }

    /* Tier break — full-width divider with centered pill label */
    .bbm-tier-badge {
      position: absolute;
      left: 0;
      right: 0;
      top: -7px;
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: none;
      z-index: 0;
      padding: 0 10px;
    }
    .bbm-tier-badge::before,
    .bbm-tier-badge::after {
      content: '';
      flex: 1;
      height: 1px;
      background: currentColor;
      opacity: 0.35;
    }
    .bbm-tier-pill {
      font-size: 8px;
      font-weight: 800;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      padding: 2px 6px;
      border-radius: 3px;
      background: #0C1A30;
      border: 1px solid currentColor;
      color: inherit;
      white-space: nowrap;
      line-height: 1.5;
      flex-shrink: 0;
    }

    .bbm-header-label {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      color: inherit;
      opacity: 0.5;
      font-family: inherit;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }

    /* Auth section (TASK-129) */
    #bbm-auth-section { margin: 6px 0; }

    .bbm-account-toggle {
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 3px 0;
      user-select: none;
    }
    .bbm-account-toggle-label {
      font-size: 10px;
      color: #8A9BB5;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .bbm-account-chevron {
      font-size: 9px;
      color: #5a6a80;
      transition: transform 0.15s;
      line-height: 1;
    }
    .bbm-account-body { padding-top: 6px; }

    .bbm-auth-input {
      width: 100%;
      background: #0F2040;
      border: 1px solid #243A5C;
      border-radius: 4px;
      color: #E8E8E8;
      font-size: 11px;
      padding: 5px 7px;
      margin-bottom: 4px;
      box-sizing: border-box;
      outline: none;
    }
    .bbm-auth-input:focus { border-color: #E8BF4A; }

    .bbm-btn {
      width: 100%;
      background: #E8BF4A;
      color: #0C1A30;
      border: none;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      padding: 5px 0;
      cursor: pointer;
      margin-bottom: 4px;
    }
    .bbm-btn:hover { background: #F0CC5B; }
    .bbm-btn:disabled { opacity: 0.5; cursor: default; }

    .bbm-btn-secondary {
      background: transparent;
      color: #8A9BB5;
      border: 1px solid #243A5C;
    }
    .bbm-btn-secondary:hover { color: #E8E8E8; border-color: #8A9BB5; }

    .bbm-btn-google {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: #fff;
      color: #3c4043;
      font-weight: 600;
    }
    .bbm-btn-google:hover { background: #f1f3f4; }

    .bbm-auth-divider {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 6px 0;
      font-size: 9px;
      color: #5A6E8A;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .bbm-auth-divider::before,
    .bbm-auth-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #243A5C;
    }

    .bbm-auth-user {
      font-size: 11px;
      color: #C0CCE0;
      margin-bottom: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-auth-tier {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 6px;
      background: #1C3A5E;
      color: #8A9BB5;
    }
    .bbm-auth-tier.pro { background: #2A3A10; color: #A3C447; }

    .bbm-auth-error {
      font-size: 10px;
      color: #EF4444;
      margin-top: 2px;
    }
    .bbm-sync-result {
      font-size: 10px;
      color: #10B981;
      margin-bottom: 4px;
    }
    .bbm-sync-result.error { color: #EF4444; }

    .bbm-sync-progress { margin-bottom: 6px; }
    .bbm-progress-label {
      font-size: 10px;
      color: #8A9BB5;
      margin-bottom: 3px;
    }
    .bbm-progress-bar-wrap {
      width: 100%;
      height: 4px;
      background: #1a2d50;
      border-radius: 2px;
      overflow: hidden;
    }
    .bbm-progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #D4A843, #F0CC5B);
      border-radius: 2px;
      transition: width 0.2s ease;
    }
    @keyframes bbm-shimmer {
      0%   { transform: translateX(-100%); }
      100% { transform: translateX(400%); }
    }
    .bbm-progress-indeterminate .bbm-progress-bar-fill {
      width: 25%;
      animation: bbm-shimmer 1.4s ease-in-out infinite;
    }

    /* FAB — brand logo button, bottom-left. Whispers at rest, speaks on hover. */
    #bbm-fab {
      position: fixed;
      bottom: 14px;
      left: 14px;
      z-index: 10000;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      opacity: 0.3;
      transition: opacity 120ms ease, filter 120ms ease;
    }
    #bbm-fab:hover {
      opacity: 1;
      filter: drop-shadow(0 0 8px rgba(232, 191, 74, 0.5));
    }

    /* Configuration panel — compact, only visible on demand */
    #bbm-panel {
      display: none;
      position: fixed;
      bottom: 50px;
      left: 14px;
      z-index: 10000;
      background: #0C1A30;
      border: 1px solid #243A5C;
      border-radius: 8px;
      padding: 10px 14px;
      min-width: 210px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
      font-size: 12px;
      color: #E8E8E8;
    }
    #bbm-panel.open {
      display: block;
    }
    .bbm-panel-title {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8A9BB5;
      margin-bottom: 8px;
    }
    .bbm-panel-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .bbm-panel-label {
      font-size: 12px;
      font-weight: 600;
      color: #E8E8E8;
    }
    #bbm-overlay-toggle {
      cursor: pointer;
      width: 14px;
      height: 14px;
      accent-color: #E8BF4A;
    }

    /* TASK-231: locked overlay row (non-Pro) */
    .bbm-lock-icon {
      display: none;
      margin-left: 5px;
      font-size: 11px;
      vertical-align: -1px;
      filter: grayscale(1) brightness(1.3);
      opacity: 0.7;
    }
    #bbm-overlay-row.bbm-locked {
      opacity: 0.5;
      cursor: not-allowed;
    }
    #bbm-overlay-row.bbm-locked .bbm-panel-label {
      pointer-events: none;
    }
    #bbm-overlay-row.bbm-locked .bbm-lock-icon {
      display: inline;
    }
    #bbm-overlay-row.bbm-locked #bbm-overlay-toggle {
      pointer-events: none;
      cursor: not-allowed;
    }

    /* TASK-231: Upgrade-to-Pro CTA */
    #bbm-upgrade-cta {
      margin: 8px 0 4px;
    }
    .bbm-upgrade-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      padding: 7px 10px;
      border-radius: 6px;
      background: linear-gradient(135deg, #D4A843 0%, #F0CC5B 50%, #E8BF4A 100%);
      color: #0C1A30;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      text-decoration: none;
      border: 1px solid #B8911E;
      box-shadow: 0 1px 4px rgba(232, 191, 74, 0.25);
      box-sizing: border-box;
      transition: filter 120ms ease, transform 120ms ease;
    }
    .bbm-upgrade-btn:hover {
      filter: brightness(1.08);
      transform: translateY(-1px);
    }
    .bbm-upgrade-icon {
      font-size: 13px;
      line-height: 1;
    }
    .bbm-upgrade-sub {
      font-size: 10px;
      color: #8A9BB5;
      text-align: center;
      margin-top: 4px;
    }

    /* Confidence panel — status and sync lines (TASK-106) */
    .bbm-panel-divider {
      border: none;
      border-top: 1px solid #243A5C;
      margin: 8px 0;
    }
    .bbm-panel-status {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
    }
    .bbm-status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #6B7280;
    }
    .bbm-status-label {
      font-size: 11px;
      color: #C0CCE0;
    }
    .bbm-panel-sync-line {
      font-size: 10px;
      color: #8A9BB5;
      margin-top: 3px;
      padding-left: 12px;
    }

    /* Tournament filter (TASK-107) — hierarchical: slate → tournament */
    .bbm-filter-title {
      margin-top: 6px;
      margin-bottom: 4px;
    }
    #bbm-tournament-filter {
      max-height: 140px;
      overflow-y: auto;
    }
    .bbm-filter-check {
      cursor: pointer;
      accent-color: #E8BF4A;
      flex-shrink: 0;
      width: 12px;
      height: 12px;
    }
    .bbm-filter-slate-group {
      border-bottom: 1px solid #1E3054;
    }
    .bbm-filter-slate-group:last-child {
      border-bottom: none;
    }
    .bbm-filter-slate-row {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 3px 0;
    }
    .bbm-filter-slate-label-wrap {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 1;
      cursor: pointer;
      min-width: 0;
    }
    .bbm-filter-slate-label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #8A9BB5;
    }
    .bbm-filter-expand {
      background: none;
      border: none;
      color: #8A9BB5;
      font-size: 7px;
      padding: 0 2px;
      cursor: pointer;
      flex-shrink: 0;
      line-height: 1;
    }
    .bbm-filter-tournaments {
      display: none;
    }
    .bbm-filter-slate-group.bbm-expanded .bbm-filter-tournaments {
      display: block;
    }
    .bbm-filter-tournament-row {
      display: flex;
      align-items: center;
      gap: 5px;
      padding: 2px 0 2px 14px;
      cursor: pointer;
    }
    .bbm-filter-tournament-label {
      font-size: 11px;
      color: #C0CCE0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `,document.head.appendChild(e)}function z(){if(_||w!=="pro")return;O(),Nt(),$t(),_=fe({targetSelector:p.selectors.gridSelector,onMutation:L,onReconnect:()=>{L()}});const e=document.querySelector(p.selectors.sortButtonsSelector);e&&(B=new MutationObserver(L),B.observe(e,{attributes:!0,subtree:!0})),L()}function j(){_&&(_.disconnect(),_=null),B&&(B.disconnect(),B=null),D&&(cancelAnimationFrame(D),D=null),Ft(),Me()}function Yt(){if(document.getElementById("bbm-fab"))return;const e=document.createElement("button");e.id="bbm-fab",e.title="Best Ball Exposures",e.innerHTML=`<svg width="36" height="36" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Best Ball Exposures">
    <defs>
      <linearGradient id="bb-gold" x1="10" y1="10" x2="38" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%"   stop-color="#F0CC5B"/>
        <stop offset="50%"  stop-color="#D4A843"/>
        <stop offset="100%" stop-color="#E8BF4A"/>
      </linearGradient>
      <linearGradient id="bb-bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#0C1A30"/>
        <stop offset="100%" stop-color="#060E1F"/>
      </linearGradient>
    </defs>
    <circle cx="24" cy="24" r="24" fill="url(#bb-bg)"/>
    <circle cx="24" cy="24" r="22.5" fill="none" stroke="url(#bb-gold)" stroke-width="2"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="#E8BF4A" stroke-width="0.5" opacity="0.18"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="url(#bb-gold)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="18 7 10 7 23 7 8 7.96" transform="rotate(-90 24 24)"/>
    <circle cx="24" cy="24" r="2.5" fill="url(#bb-gold)"/>
  </svg>`;const t=document.createElement("div");t.id="bbm-panel",t.innerHTML=`
    <div class="bbm-panel-title">Best Ball Exposures</div>
    <div id="bbm-auth-section"></div>
    <div id="bbm-upgrade-cta" style="display:none"></div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-row" id="bbm-overlay-row">
      <label class="bbm-panel-label" for="bbm-overlay-toggle">
        Overlay
        <span class="bbm-lock-icon" aria-hidden="true">🔒</span>
      </label>
      <input type="checkbox" id="bbm-overlay-toggle" />
    </div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-status">
      <span class="bbm-status-dot"></span>
      <span class="bbm-status-label">—</span>
    </div>
    <div class="bbm-panel-sync-line">—</div>
    <div id="bbm-filter-wrap">
      <hr class="bbm-panel-divider" />
      <div class="bbm-panel-title bbm-filter-title">Tournament Filter</div>
      <div id="bbm-tournament-filter" style="display:none"></div>
    </div>
  `;const n=t.querySelector("#bbm-overlay-toggle");n.checked=x,t.querySelector(".bbm-panel-status").addEventListener("click",()=>{I==="error"&&O()}),t.addEventListener("click",o=>o.stopPropagation()),e.addEventListener("click",o=>{o.stopPropagation(),t.classList.toggle("open"),t.classList.contains("open")&&(X(),V(),q())}),n.addEventListener("change",()=>{if(w!=="pro"){n.checked=!1;return}x=n.checked,chrome.storage.local.set({overlayEnabled:x}),x?z():j()}),document.body.appendChild(e),document.body.appendChild(t)}function me(){const e=window.location.href;if(e===te)return;const t=W;te=e,W=p.isDraftPage();const n=W;!t&&n?q().then(()=>{x&&w==="pro"&&z()}):t&&!n?j():t&&n&&(j(),q().then(()=>{x&&w==="pro"&&z()}))}function Jt(){setInterval(()=>{window.location.href!==te&&me()},300),window.addEventListener("popstate",me)}function Vt(e,t=null){p=e,se=t,chrome.storage.local.get(["overlayEnabled","tournamentFilter"],n=>{x=n.overlayEnabled!==!1,y=new Set(n.tournamentFilter??[]),W=p.isDraftPage(),Qt(),Yt(),Jt(),q().then(()=>{W&&x&&w==="pro"?z():O()}),document.addEventListener("click",()=>{var r;(r=document.getElementById("bbm-panel"))==null||r.classList.remove("open")}),document.addEventListener("keydown",r=>{var o;r.key==="Escape"&&((o=document.getElementById("bbm-panel"))==null||o.classList.remove("open"))})}),chrome.runtime.onMessage.addListener(n=>{if(n.type!=="TOGGLE_OVERLAY"||w!=="pro"&&n.enabled)return;x=n.enabled;const r=document.getElementById("bbm-overlay-toggle");r&&(r.checked=x),x?p.isDraftPage()&&z():j()})}const Q=Pe(window.location.href);if(Q){document.querySelector("#root, #app, [data-reactroot]")&&fe({targetSelector:"#root, #app, [data-reactroot]",onMutation:()=>{},onReconnect:()=>{}});async function t(){const n=await Fe(),r=await Q.getEntries(n);return He(r,{platform:Q.platform})}Vt(Q,t),chrome.runtime.onMessage.addListener((n,r,o)=>n.type!=="SYNC_ENTRIES"?!1:(t().then(({count:i})=>o({ok:!0,count:i})).catch(i=>o({ok:!1,error:i.message})),!0))}
