import{s as u,g as Ve}from"./supabase-CdozFymc.js";function Ae({targetSelector:e,onMutation:t,onReconnect:n,pollInterval:o=500,maxRetries:r=20}){let l=null,c=null,a=null,i=!1;const s={childList:!0,subtree:!0};function d(h){l&&l.disconnect(),l=new MutationObserver(t),l.observe(h,s),c=h}function p(){a&&clearInterval(a);let h=0;a=setInterval(()=>{if(i){clearInterval(a);return}const T=document.querySelector(e);T?(clearInterval(a),a=null,d(T),n==null||n()):++h>=r&&(clearInterval(a),a=null)},o)}const g=new MutationObserver(()=>{if(i)return;const h=document.querySelector(e);!h&&l?(l.disconnect(),l=null,c=null,p()):h&&l&&h!==c&&(d(h),n==null||n())}),m=document.querySelector(e);return m?d(m):p(),g.observe(document.body,{childList:!0,subtree:!0}),{disconnect(){i=!0,a&&clearInterval(a),l&&l.disconnect(),g.disconnect()}}}async function Ce(){if(!u)return null;const{data:{session:e}}=await u.auth.getSession();return e}async function Ze(e,t){if(!u)throw new Error("[BBM] Supabase not configured");const{data:n,error:o}=await u.auth.signInWithPassword({email:e,password:t});if(o)throw o;return n.session}async function et(){if(!u)throw new Error("[BBM] Supabase not configured");const e=await new Promise(o=>{chrome.runtime.sendMessage({type:"GOOGLE_OAUTH"},o)});if(e.error)throw new Error(e.error);const{data:t,error:n}=await u.auth.setSession({access_token:e.access_token,refresh_token:e.refresh_token});if(n)throw n;return t.session}async function tt(){if(!u)throw new Error("[BBM] Supabase not configured");const e=await new Promise(o=>{chrome.runtime.sendMessage({type:"APPLE_OAUTH"},o)});if(e.error)throw new Error(e.error);const{data:t,error:n}=await u.auth.setSession({access_token:e.access_token,refresh_token:e.refresh_token});if(n)throw n;return t.session}async function nt(){u&&await u.auth.signOut()}async function Te(){var e,t,n,o;try{if(!u)return null;const{data:{session:r}}=await u.auth.getSession();if(!r)return null;const l=r.user.id,[c,a]=await Promise.all([u.from("subscriptions").select("status").eq("user_id",l).in("status",["active","trialing"]).limit(1).maybeSingle(),u.from("profiles").select("beta_expires_at, comp_expires_at").eq("id",l).maybeSingle()]),i=((e=c.data)==null?void 0:e.status)==="active"||((t=c.data)==null?void 0:t.status)==="trialing",s=new Date,d=(n=a.data)==null?void 0:n.beta_expires_at,p=(o=a.data)==null?void 0:o.comp_expires_at,g=d?new Date(d)>s:!1,m=p?new Date(p)>s:!1;return i||g||m?"pro":"free"}catch{return null}}async function ot(){if(!u)return[];const{data:{session:e}}=await u.auth.getSession();if(!e)return[];const{data:t,error:n}=await u.from("extension_entries").select("entry_id").eq("user_id",e.user.id);return n?[]:(t??[]).map(o=>o.entry_id)}async function rt(e){if(!u||!Array.isArray(e)||e.length===0)return new Set;const{data:{session:t}}=await u.auth.getSession();if(!t)return new Set;const{data:n,error:o}=await u.from("draft_boards_admin").select("draft_id, first_pick_name:picks->0->>name").in("draft_id",e.map(String));return o?new Set:new Set((n??[]).filter(r=>r.first_pick_name!=null).map(r=>String(r.draft_id)))}async function it(){if(!u)throw new Error("[BBM] Supabase not configured");const{data:{session:e}}=await u.auth.getSession();if(!e)throw new Error("[BBM] Not authenticated");const{data:t,error:n}=await u.from("extension_entries").select("entry_id, tournament, slate_title, draft_date, players").eq("user_id",e.user.id);if(n)throw n;return(t??[]).map(o=>({entryId:o.entry_id,tournamentTitle:o.tournament,slateTitle:at(o.slate_title??"",o.tournament),draftDate:o.draft_date,players:o.players??[]}))}function at(e,t){return!e||!e.startsWith("DK")?e:(t||"").toLowerCase().includes("early bird")?"DK Pre-Draft":"DK Post-Draft"}async function st(){if(!u)return null;const{data:{session:e}}=await u.auth.getSession();if(!e)return null;const{data:t,error:n}=await u.from("user_rankings").select("rankings").eq("user_id",e.user.id).maybeSingle();return n||!t?null:t.rankings??null}function we(e,t){return{user_id:e,entry_id:t.entryId,tournament:t.tournamentTitle??null,slate_title:t.slateTitle??null,draft_date:t.draftDate??null,players:t.players??[],synced_at:new Date().toISOString()}}async function lt(e,{platform:t}={}){if(!u)throw new Error("[BBM] Supabase not configured");const{data:{session:n}}=await u.auth.getSession();if(!n)throw new Error("[BBM] Not authenticated");const o=n.user.id;if(!Array.isArray(e)){if(!t)throw new Error("[BBM] Incremental writeEntries requires platform");const{newEntries:d=[],currentDraftIds:p=[]}=e,g=`${t}_entry_ids`,h=(await new Promise(S=>chrome.storage.local.get([g],S)))[g]??[],T=new Set(p.map(String)),Y=h.filter(S=>!T.has(String(S)));if(Y.length>0){const{error:S}=await u.from("extension_entries").delete().eq("user_id",o).in("entry_id",Y);if(S)throw S}if(d.length>0){const S=d.map(Xe=>we(o,Xe)),{error:he}=await u.from("extension_entries").upsert(S,{onConflict:"user_id,entry_id"});if(he)throw he}const ie=p.length;return await new Promise(S=>chrome.storage.local.set({lastSync:Date.now(),entryCount:ie,[`${t}_entry_ids`]:p.map(String),[`${t}_lastSync`]:Date.now(),[`${t}_entryCount`]:ie},()=>S())),{count:ie}}const l=e;if(t){const d=`${t}_entry_ids`,g=(await new Promise(m=>chrome.storage.local.get([d],m)))[d]??[];if(g.length>0){const{error:m}=await u.from("extension_entries").delete().eq("user_id",o).in("entry_id",g);if(m)throw m}else if(t==="underdog"){const{error:m}=await u.from("extension_entries").delete().eq("user_id",o);if(m)throw m}}else{const{error:d}=await u.from("extension_entries").delete().eq("user_id",o);if(d)throw d}if(l.length===0){const d={lastSync:Date.now(),entryCount:0};return t&&(d[`${t}_lastSync`]=Date.now(),d[`${t}_entryCount`]=0),await new Promise(p=>chrome.storage.local.set(d,()=>p())),{count:0}}const c=l.map(d=>we(o,d)),{error:a,count:i}=await u.from("extension_entries").upsert(c,{onConflict:"user_id,entry_id",count:"exact"});if(a)throw a;const s={lastSync:Date.now(),entryCount:l.length};return t&&(s[`${t}_entry_ids`]=l.map(d=>d.entryId),s[`${t}_lastSync`]=Date.now(),s[`${t}_entryCount`]=l.length),await new Promise(d=>chrome.storage.local.set(s,()=>d())),{count:i??l.length}}async function xe(e){if(!u||!Array.isArray(e)||e.length===0)return{count:0};const{data:{session:t}}=await u.auth.getSession();if(!t)return{count:0};const n=e.map(r=>({draft_id:String(r.draftId),slate_title:r.slateTitle??null,entry_count:r.entryCount??null,rounds:r.rounds??null,picks:r.picks??[],fetched_at:new Date().toISOString(),source:"extension"})),{error:o}=await u.from("draft_boards_admin").upsert(n,{onConflict:"draft_id"});if(o)throw o;return{count:n.length}}const ct=/\s+(jr\.?|sr\.?|ii|iii|iv|v)\s*$/i,dt={"kenny gainwell":"kenneth gainwell"};function k(e=""){const t=String(e).trim().replace(/^"|"$/g,"").replace(ct,"").replace(/\./g,"").replace(/\s+/g," ").trim().toLowerCase();return dt[t]||t}const pt="Real NFL 2026 W15/16/17 schedule (released 2026-05-14). Source: 2026 SCHEDULE RELEASE GRID (@OzzyNFL).",bt={15:"NYJ",16:"NO",17:"LV"},ut={15:"WAS",16:"TB",17:"NO"},mt={15:"PIT",16:"CLE",17:"CIN"},ft={15:"CHI",16:"DEN",17:"MIA"},gt={15:"CIN",16:"PIT",17:"SEA"},yt={15:"BUF",16:"GB",17:"DET"},ht={15:"CAR",16:"IND",17:"BAL"},wt={15:"NYG",16:"BAL",17:"IND"},xt={15:"LAR",16:"JAX",17:"NYG"},vt={15:"LV",16:"BUF",17:"NE"},Et={15:"MIN",16:"NYG",17:"CHI"},kt={15:"MIA",16:"CHI",17:"HOU"},St={15:"JAX",16:"PHI",17:"GB"},Bt={15:"TEN",16:"CIN",17:"CLE"},At={15:"HOU",16:"DAL",17:"WAS"},Ct={15:"NE",16:"SF",17:"LAC"},Tt={15:"DEN",16:"TEN",17:"ARI"},Lt={15:"SF",16:"MIA",17:"KC"},Mt={15:"DAL",16:"SEA",17:"TB"},It={15:"GB",16:"LAC",17:"BUF"},_t={15:"DET",16:"WAS",17:"NYJ"},Rt={15:"KC",16:"NYJ",17:"DEN"},Pt={15:"TB",16:"ARI",17:"ATL"},Nt={15:"CLE",16:"DET",17:"DAL"},$t={15:"ARI",16:"NE",17:"MIN"},Dt={15:"SEA",16:"HOU",17:"SF"},Ft={15:"BAL",16:"CAR",17:"TEN"},qt={15:"LAC",16:"KC",17:"PHI"},zt={15:"PHI",16:"LAR",17:"CAR"},Ot={15:"NO",16:"ATL",17:"LAR"},Wt={15:"IND",16:"LV",17:"PIT"},Ht={15:"ATL",16:"MIN",17:"JAX"},ve={_README:pt,ARI:bt,ATL:ut,BAL:mt,BUF:ft,CAR:gt,CHI:yt,CIN:ht,CLE:wt,DAL:xt,DEN:vt,DET:Et,GB:kt,HOU:St,IND:Bt,JAX:At,KC:Ct,LV:Tt,LAC:Lt,LAR:Mt,MIA:It,MIN:_t,NE:Rt,NO:Pt,NYG:Nt,NYJ:$t,PHI:Dt,PIT:Ft,SF:qt,SEA:zt,TB:Ot,TEN:Wt,WAS:Ht},Ut={ARI:14,DAL:14,BAL:13,IND:13,LV:13,NYJ:13,ATL:11,CLE:11,GB:11,LAR:11,NE:11,SEA:11,TB:10,CHI:10,DEN:10,PHI:10,PIT:9,TEN:9,HOU:8,NO:8,NYG:8,SF:8,BUF:7,JAX:7,JAC:7,LAC:7,WAS:7,CIN:6,DET:6,MIA:6,MIN:6,CAR:5,KC:5},jt={premium:[14],strong:[13],shared:[11],early:[5,6,7,8]},Kt={positions:{QB:{min:3,max:3,ideal:3,note:"Insurance, not upside — 3 startable arms with staggered byes."},RB:{min:5,max:5,ideal:5,note:"Most projectable Week-1 volume — anchor your floor here."},WR:{min:6,max:7,ideal:7,note:"Where your variance lives; trim to fund the 3rd QB / 4th TE."},TE:{min:3,max:4,ideal:3,note:"Same onesie logic as QB; go to 4 only if late TEs out-floor your fringe WR/RB."}}},Gt=[{name:"Omarion Hampton",reason:"rookie",note:"value lands after the elimination weeks"},{name:"Jeremiyah Love",reason:"rookie",note:"rookie/contingent — late value"},{name:"Jonathon Brooks",reason:"contingent",note:"injury-return / conditional volume"},{name:"Jordyn Tyson",reason:"rookie",note:"late-developing rookie"},{name:"Rico Dowdle",reason:"contingent",note:"conditional Week-1 role"},{name:"Kenneth Gainwell",reason:"contingent",note:"committee / conditional volume"},{name:"J.K. Dobbins",reason:"contingent",note:"conditional Week-1 role"}],M={byeWeeks:Ut,byeTiers:jt,rosterShape:Kt,fades:Gt},Yt=M.rosterShape,Jt=["QB","RB","WR","TE"],Qt=new Set([...M.byeTiers.premium||[],...M.byeTiers.strong||[]]),Le=new Set(M.byeTiers.early||[]),Me=e=>String(e||"").toLowerCase().replace(/[.'`-]/g,"").replace(/\b(jr|sr|ii|iii|iv|v)\b/g,"").replace(/\s+/g," ").trim(),Xt=new Map((M.fades||[]).map(e=>[Me(e.name),e]));function se(e){const t=String(e||"").trim().toUpperCase();if(!t)return null;const n=M.byeWeeks[t];return Number.isFinite(n)?n:null}function Ie(e){return Number.isFinite(e)?(M.byeTiers.premium||[]).includes(e)?"premium":(M.byeTiers.strong||[]).includes(e)?"strong":(M.byeTiers.shared||[]).includes(e)?"shared":Le.has(e)?"early":"neutral":null}function _e(e){return Number.isFinite(e)&&Qt.has(e)}function Vt(e){return Xt.get(Me(e))||null}function Zt(e=[]){const t={},n=new Map;let o=0,r=0;e.forEach(i=>{const s=se(i.team);if(!Number.isFinite(s)){r+=1;return}_e(s)&&(o+=1),t[i.position]||(t[i.position]=new Map);const d=t[i.position];d.has(s)||d.set(s,[]),d.get(s).push(i.name),n.has(s)||n.set(s,[]),n.get(s).push({name:i.name,position:i.position})});const l=[];Object.entries(t).forEach(([i,s])=>{s.forEach((d,p)=>{d.length>=2&&l.push({position:i,week:p,players:d})})});const c=[];n.forEach((i,s)=>{Le.has(s)&&i.length>=2&&c.push({week:s,players:i})});const a=Jt.filter(i=>t[i]).map(i=>{const s=[...t[i].entries()].sort((d,p)=>d[0]-p[0]).map(([d,p])=>({week:d,tier:Ie(d),players:p}));return{position:i,weeks:s}});return{byPosition:t,summary:a,collisions:l,earlyStacks:c,lateByeCount:o,unknownByeCount:r}}function en(e,t=[]){if(!e)return null;const n=se(e.team),o=Ie(n),r=Vt(e.name);let l=null;if(Number.isFinite(n)){const a=t.filter(i=>i.position===e.position&&se(i.team)===n);a.length>0&&(l={week:n,players:a.map(i=>i.name)})}let c=!1;if(e.position==="QB"||e.position==="TE"){const a=Yt.positions[e.position];c=t.filter(s=>s.position===e.position).length<a.min}return{byeWeek:n,byeTier:o,isLateBye:_e(n),fade:r,byeClash:l,fillsOnesieNeed:c}}const tn=["15","16","17"],nn=Object.freeze({QB:new Set(["QB","WR","TE"]),WR:new Set(["QB","WR","TE"]),TE:new Set(["QB","WR"])}),on=Object.freeze({QB:new Set(["QB","WR","TE","RB"]),WR:new Set(["QB","WR","TE","RB"]),TE:new Set(["QB","WR","RB"]),RB:new Set(["QB","WR","TE","RB"])});function rn(e){return e==="17"?on:nn}const te="data-bbm-injected",Re="data-bbm-player-id",J="data-bbm-headers-injected";let b=null,f=null,$=null,w=!0,E=!1,H=null,le=window.location.href,Q=!1,B=new Map,v=new Map,A=new Map,oe=new Map,ce=!1,W=new Map,K=0,N=[],ee=new Map,D=null,U=null,de=new Map,pe=new Set,I=null,R="idle",be=null,ue=null,x=null;const an="https://bestballexposures.com/?upgrade=1";let L=[],j=[],y=new Set,Z=new Set;const Ee=["S","A+","A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"],sn={S:"#ffd700","A+":"#ef4444",A:"#f87171","A-":"#fb923c","B+":"#f59e0b",B:"#eab308","B-":"#a3e635","C+":"#10b981",C:"#06b6d4","C-":"#3b82f6","D+":"#6366f1",D:"#8b5cf6","D-":"#a855f7",F:"#6b7280"};function Pe(e){const t=Math.max(0,Math.min(e-1,Ee.length-1));return Ee[t]}function ln(e){return sn[Pe(e)]||"#555"}function cn(e){const t=(e==null?void 0:e.message)??"";return t.includes("Not authenticated")||t.includes("JWT")?"Session expired — sign in again":t.includes("fetch")||t.includes("network")||t.includes("NetworkError")?"Connection lost — tap to retry":"Load failed — tap to retry"}function ae(e){const t=Math.floor((Date.now()-e)/1e3);return t<60?"just now":t<3600?`${Math.floor(t/60)}m ago`:t<86400?`${Math.floor(t/3600)}h ago`:`${Math.floor(t/86400)}d ago`}async function ne(){const e=document.querySelector(".bbm-status-dot"),t=document.querySelector(".bbm-status-label"),n=document.querySelector(".bbm-panel-sync-line");if(!e||!t||!n)return;const o=await Ce();let r,l;o?R==="loading"?(r="#6B7280",l="Loading portfolio…"):R==="error"?(r="#EF4444",l=be??"Load failed — tap to retry"):(r="#10B981",l="Connected"):(r="#F59E0B",l="Not signed in"),e.style.background=r,t.textContent=l;const c=document.querySelector(".bbm-panel-status");if(c&&(c.style.cursor=R==="error"?"pointer":"default"),R==="loading"){n.textContent="Fetching entries…";return}if(!o){n.textContent="—";return}chrome.storage.local.get(["lastSync","entryCount","underdog_lastSync","underdog_entryCount","draftkings_lastSync","draftkings_entryCount"],a=>{const i=[];a.underdog_lastSync&&i.push(`UD: ${a.underdog_entryCount??0} · ${ae(a.underdog_lastSync)}`),a.draftkings_lastSync&&i.push(`DK: ${a.draftkings_entryCount??0} · ${ae(a.draftkings_lastSync)}`),i.length>0?n.textContent=i.join("  |  "):a.lastSync?n.textContent=`${a.entryCount??0} entries · synced ${ae(a.lastSync)}`:n.textContent="Not yet synced"})}function P(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function fe(e){return String(e??"").replace(/\b\w/g,t=>t.toUpperCase())}function Ne(){const e=document.getElementById("bbm-tournament-filter");if(e){if(L.length===0){e.style.display="none";return}e.style.display="block",e.innerHTML=L.map((t,n)=>{const o=Z.has(t.slate);return`
      <div class="bbm-filter-slate-group${o?" bbm-expanded":""}" data-si="${n}">
        <div class="bbm-filter-slate-row">
          <label class="bbm-filter-slate-label-wrap">
            <input type="checkbox" class="bbm-filter-check bbm-filter-slate-check" data-si="${n}" />
            <span class="bbm-filter-slate-label">${P(t.slate)}</span>
          </label>
          <button type="button" class="bbm-filter-expand" data-si="${n}">${o?"▼":"▶"}</button>
        </div>
        <div class="bbm-filter-tournaments">
          ${t.tournaments.map((r,l)=>`
            <label class="bbm-filter-tournament-row">
              <input type="checkbox" class="bbm-filter-check bbm-filter-tournament-check"
                data-si="${n}" data-ti="${l}"
                ${y.has(r)?"checked":""} />
              <span class="bbm-filter-tournament-label">${P(r)}</span>
            </label>
          `).join("")}
        </div>
      </div>
    `}).join(""),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{const{tournaments:n}=L[parseInt(t.dataset.si)],o=n.filter(r=>y.has(r)).length;t.checked=o===n.length,t.indeterminate=o>0&&o<n.length}),e.querySelectorAll(".bbm-filter-expand").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const o=L[parseInt(t.dataset.si)];Z.has(o.slate)?Z.delete(o.slate):Z.add(o.slate),Ne()})}),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{t.addEventListener("change",()=>{const{tournaments:n}=L[parseInt(t.dataset.si)];n.every(r=>y.has(r))?n.forEach(r=>y.delete(r)):n.forEach(r=>y.add(r)),chrome.storage.local.set({tournamentFilter:[...y]}),me()})}),e.querySelectorAll(".bbm-filter-tournament-check").forEach(t=>{t.addEventListener("change",()=>{const n=L[parseInt(t.dataset.si)].tournaments[parseInt(t.dataset.ti)];t.checked?y.add(n):y.delete(n),chrome.storage.local.set({tournamentFilter:[...y]}),me()})})}}function me(){var o,r,l,c;const e=y.size===0?j:j.filter(a=>y.has(a.tournamentTitle));v=new Map,A=new Map,j.forEach(a=>{(a.players??[]).forEach(i=>{if(!i.name)return;const s=k(i.name);s&&(i.team&&!v.has(s)&&v.set(s,i.team),i.position&&!A.has(s)&&A.set(s,i.position))})}),K=e.length,B=new Map,W=new Map;const t=new Map;e.forEach((a,i)=>{(a.players??[]).forEach(s=>{if(!s.name)return;const d=k(s.name);if(!d)return;B.has(d)||B.set(d,new Set),B.get(d).add(i);const p=Number(s.pick);Number.isFinite(p)&&p>0&&(t.has(d)||t.set(d,[]),t.get(d).push(p))})});function n(a){const i=t.get(a);if(!i||i.length===0)return null;const s=[...i].sort((p,g)=>p-g),d=Math.floor(s.length/2);return s.length%2?s[d]:(s[d-1]+s[d])/2}for(const a of B.keys()){const i=a.split(/\s+/);if(i.length<2)continue;const s=i[0][0],d=i.slice(1).join(" "),p=`${s} ${d}`;if(W.has(p)){const g=W.get(p),m={fullName:a,position:((o=A.get(a))==null?void 0:o.toUpperCase())??null,team:((r=v.get(a))==null?void 0:r.toUpperCase())??null,medianPick:n(a)};typeof g=="string"?W.set(p,[{fullName:g,position:((l=A.get(g))==null?void 0:l.toUpperCase())??null,team:((c=v.get(g))==null?void 0:c.toUpperCase())??null,medianPick:n(g)},m]):Array.isArray(g)&&g.push(m)}else W.set(p,a)}Ne(),C()}async function F(){x=await Te(),$e()}function $e(){var c;const e=x==="pro",t=document.getElementById("bbm-overlay-row"),n=document.getElementById("bbm-overlay-toggle");t&&n&&(e?(t.classList.remove("bbm-locked"),t.removeAttribute("title"),n.disabled=!1,n.checked=w):(t.classList.add("bbm-locked"),t.setAttribute("title","Pro feature — upgrade to use the overlay"),n.disabled=!0,n.checked=!1));const o=document.getElementById("bbm-eliminator-row"),r=document.getElementById("bbm-eliminator-toggle");o&&r&&(e?(o.classList.remove("bbm-locked"),o.removeAttribute("title"),r.disabled=!1,r.checked=E):(o.classList.add("bbm-locked"),o.setAttribute("title","Pro feature — upgrade to use Eliminator Mode"),r.disabled=!0,r.checked=!1));const l=document.getElementById("bbm-filter-wrap");l&&(l.style.display=e?"":"none"),dn(),e?(c=b==null?void 0:b.isDraftPage)!=null&&c.call(b)&&w&&!$?G():q():($||I||D?X():Ge(),ye(),document.querySelectorAll(".bbm-eliminator-badge").forEach(a=>a.remove()))}function dn(){const e=document.getElementById("bbm-upgrade-cta");if(e){if(x==="pro"){e.innerHTML="",e.style.display="none";return}e.style.display="block",e.innerHTML=`
    <a href="${an}" target="_blank" rel="noopener noreferrer" class="bbm-upgrade-btn">
      <span class="bbm-upgrade-icon" aria-hidden="true">★</span>
      Upgrade to Pro
    </a>
    <div class="bbm-upgrade-sub">Unlock the in-draft overlay</div>
  `}}async function V(){const e=document.getElementById("bbm-auth-section");if(!e)return;const t=await Ce();if(t){const n=await Te(),o=n?`<span class="bbm-auth-tier ${n}">${n==="pro"?"Pro":"Free"}</span>`:"";e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <div class="bbm-auth-user">${P(t.user.email)}</div>
        ${o}
        <button id="bbm-sign-out-btn" class="bbm-btn bbm-btn-secondary">Sign Out</button>
      </div>
      <button id="bbm-sync-btn" class="bbm-btn" style="margin-top:6px">Sync Now</button>
      <div id="bbm-sync-progress" class="bbm-sync-progress bbm-progress-indeterminate" style="display:none">
        <div class="bbm-progress-label">Discovering entries…</div>
        <div class="bbm-progress-bar-wrap"><div class="bbm-progress-bar-fill"></div></div>
      </div>
      <div id="bbm-sync-result" class="bbm-sync-result" style="display:none"></div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",ke),e.querySelector("#bbm-sync-btn").addEventListener("click",mn),e.querySelector("#bbm-sign-out-btn").addEventListener("click",un)}else{e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron" style="transform:rotate(180deg)">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:block">
        <button id="bbm-google-btn" class="bbm-btn bbm-btn-google">
          <svg width="16" height="16" viewBox="0 0 48 48" style="flex-shrink:0"><path fill="#4285F4" d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z"/><path fill="#34A853" d="M6.3 14.7l7 5.1C15 15.6 19.1 12 24 12c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 16.3 2 9.7 7.3 6.3 14.7z"/><path fill="#FBBC05" d="M24 46c5.4 0 10.3-1.8 14.1-5l-6.9-5.7C29.1 37 26.7 38 24 38c-6 0-10.6-3.9-12.3-9.2l-7 5.4C8.1 41 15.4 46 24 46z"/><path fill="#EA4335" d="M46 24c0-1.3-.2-2.7-.5-4H24v8.5h11.8c-1 3-3 5.4-5.8 7l6.9 5.7C41 37.5 46 31.5 46 24z"/></svg>
          Sign in with Google
        </button>
        <button id="bbm-apple-btn" class="bbm-btn bbm-btn-apple">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0"><path d="M16.365 1.43c0 1.14-.417 2.2-1.114 2.98-.75.84-1.99 1.49-3.02 1.41-.13-1.09.41-2.24 1.06-2.96.73-.82 2.02-1.44 3.01-1.49.06.02.06.04.06.06zM20.5 17.02c-.55 1.27-.81 1.83-1.52 2.95-.99 1.56-2.39 3.5-4.12 3.51-1.54.02-1.94-1-4.03-.99-2.09.01-2.53 1.01-4.07.99-1.73-.02-3.05-1.77-4.04-3.33C.9 16.5.6 11.05 2.79 8.42c1.06-1.31 2.73-2.14 4.31-2.14 1.61 0 2.62 1 3.95 1 1.29 0 2.08-1 3.94-1 1.41 0 2.9.77 3.96 2.1-3.48 1.91-2.92 6.88.55 8.64z"/></svg>
          Sign in with Apple
        </button>
        <div class="bbm-auth-divider"><span>or</span></div>
        <input type="email" id="bbm-auth-email" class="bbm-auth-input" placeholder="Email" autocomplete="email" />
        <input type="password" id="bbm-auth-password" class="bbm-auth-input" placeholder="Password" autocomplete="current-password" />
        <button id="bbm-sign-in-btn" class="bbm-btn">Sign In</button>
        <div id="bbm-auth-error" class="bbm-auth-error" style="display:none"></div>
      </div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",ke),e.querySelector("#bbm-google-btn").addEventListener("click",pn),e.querySelector("#bbm-apple-btn").addEventListener("click",bn),e.querySelector("#bbm-sign-in-btn").addEventListener("click",Se);for(const n of e.querySelectorAll(".bbm-auth-input"))for(const o of["keydown","keypress","keyup"])n.addEventListener(o,r=>r.stopPropagation());e.querySelector("#bbm-auth-password").addEventListener("keydown",n=>{n.key==="Enter"&&Se()})}}function ke(){const e=document.getElementById("bbm-account-body"),t=document.querySelector(".bbm-account-chevron");if(!e)return;const n=e.style.display!=="none";e.style.display=n?"none":"block",t&&(t.style.transform=n?"":"rotate(180deg)")}async function pn(){const e=document.getElementById("bbm-google-btn"),t=document.getElementById("bbm-auth-error");if(e){e.disabled=!0,t&&(t.style.display="none");try{await et(),await F(),await V(),z()}catch(n){t&&(t.textContent=n.message??"Google sign-in failed",t.style.display="block"),e&&(e.disabled=!1)}}}async function bn(){const e=document.getElementById("bbm-apple-btn"),t=document.getElementById("bbm-auth-error");if(e){e.disabled=!0,t&&(t.style.display="none");try{await tt(),await F(),await V(),z()}catch(n){t&&(t.textContent=n.message??"Apple sign-in failed",t.style.display="block"),e&&(e.disabled=!1)}}}async function Se(){var r,l;const e=(r=document.getElementById("bbm-auth-email"))==null?void 0:r.value.trim(),t=(l=document.getElementById("bbm-auth-password"))==null?void 0:l.value,n=document.getElementById("bbm-sign-in-btn"),o=document.getElementById("bbm-auth-error");if(!(!e||!t||!n)){n.disabled=!0,o&&(o.style.display="none");try{await Ze(e,t),await F(),await V(),z()}catch(c){o&&(o.textContent=c.message??"Sign in failed",o.style.display="block"),n&&(n.disabled=!1)}}}async function un(){await nt(),B=new Map,v=new Map,A=new Map,K=0,j=[],L=[],x=null,await V(),$e(),ne()}async function mn(){const e=document.getElementById("bbm-sync-btn"),t=document.getElementById("bbm-sync-result"),n=document.getElementById("bbm-sync-progress");if(!e)return;if(e.disabled=!0,t&&(t.style.display="none",t.className="bbm-sync-result"),n&&(n.style.display="none"),!ue){t&&(t.textContent=b.syncPageErrorMessage,t.classList.add("error"),t.style.display="block"),e.disabled=!1;return}const o=n==null?void 0:n.querySelector(".bbm-progress-label"),r=n==null?void 0:n.querySelector(".bbm-progress-bar-fill");function l(c){var d;if(c.source!==window||((d=c.data)==null?void 0:d.type)!=="BBM_SYNC_PROGRESS")return;const{phase:a,done:i,total:s}=c.data;if(n){if(n.style.display="block",a==="discovery")n.classList.add("bbm-progress-indeterminate"),o&&(o.textContent="Discovering entries…"),r&&(r.style.width="0%");else if(a==="fetching"){n.classList.remove("bbm-progress-indeterminate");const p=s>0?Math.round(i/s*100):0;o&&(o.textContent=`Processing ${i} / ${s} entries…`),r&&(r.style.width=p+"%")}else if(a==="boards"){n.classList.remove("bbm-progress-indeterminate");const p=s>0?Math.round(i/s*100):0;o&&(o.textContent=`Backfilling boards ${i} / ${s}…`),r&&(r.style.width=p+"%")}}}window.addEventListener("message",l);try{const{count:c,boardsRemaining:a=0}=await ue();if(t){let i=`Synced ${c} entries`;a>0&&(i+=` — ${a} draft board${a===1?"":"s"} left to fill. Reload the page and press Sync again to continue.`),t.textContent=i,t.style.display="block"}z()}catch(c){if(t){const a=c.message??"Sync failed";t.textContent=a.includes("Could not establish connection")?b.syncPageErrorMessage:a,t.classList.add("error"),t.style.display="block"}}finally{window.removeEventListener("message",l),n&&(n.style.display="none"),e&&(e.disabled=!1)}}async function z(){R="loading",ne();try{j=await it();const e=new Map;j.forEach(o=>{if(!o.tournamentTitle)return;const r=o.slateTitle||"Other";e.has(r)||e.set(r,new Set),e.get(r).add(o.tournamentTitle)}),L=[...e.entries()].sort(([o],[r])=>o.localeCompare(r)).map(([o,r])=>({slate:o,tournaments:[...r].sort()}));const t=new Set(L.flatMap(o=>o.tournaments)),n=y.size;y=new Set([...y].filter(o=>t.has(o))),y.size===0&&t.forEach(o=>y.add(o)),y.size!==n&&chrome.storage.local.set({tournamentFilter:[...y]}),me(),R="ready",be=null}catch(e){R="error",be=cn(e),console.warn("[BBM] Could not load portfolio data:",e.message)}finally{ne()}}async function fn(){try{const e=await st();if(!e)return;de=new Map(e.map(t=>[t.name,{rank:t.rank,tierNum:t.tierNum}])),pe=new Set;for(let t=1;t<e.length;t++)e[t].tierNum!==e[t-1].tierNum&&pe.add(e[t].rank);C()}catch(e){console.warn("[BBM] Could not load rankings data:",e.message)}}function De(){let e;if(b.getCurrentPicks){const n=b.getCurrentPicks();if(!n)return;e=n.map(o=>({name:_(o.name,{position:o.position,team:o.team})??o.name,position:o.position,round:o.round}))}else e=[],document.querySelectorAll(b.selectors.myPicksSelector).forEach((o,r)=>{var s,d,p;const l=o.querySelector(b.selectors.playerNameInRowSelector),c=o.closest(b.selectors.positionSectionSelector),a=((d=(s=c==null?void 0:c.querySelector(b.selectors.positionHeaderSelector))==null?void 0:s.textContent)==null?void 0:d.trim())??"",i=(p=l==null?void 0:l.textContent)==null?void 0:p.trim();i&&e.push({name:i,position:a,round:r+1})});let t=!1;e.forEach(n=>{const o=k(n.name);if(!o)return;const r=ee.get(o);if(!r){ee.set(o,{name:n.name,position:n.position,round:n.round??null}),t=!0;return}(r.round==null||r.round===0)&&n.round!=null&&n.round>0&&(r.round=n.round,t=!0)}),t&&(N=[...ee.values()],C(),E&&re())}function gn(){U||(U=requestAnimationFrame(()=>{U=null,De()}))}function Fe(){D||(D=new MutationObserver(gn),D.observe(document.body,{childList:!0,subtree:!0}),De())}function qe(){U&&(cancelAnimationFrame(U),U=null),D&&(D.disconnect(),D=null),N=[],ee.clear(),oe=new Map,ce=!1}function ze(e){var n;const t=e.querySelector(b.selectors.playerNameInRowSelector);return((n=t==null?void 0:t.textContent)==null?void 0:n.trim())??null}function _(e,t){if(!e)return null;const n=k(e);if(B.has(n))return n;const o=k(e),r=W.get(o);if(typeof r=="string")return r;if(Array.isArray(r)&&t){const l=t instanceof Element&&b.getPlayerContext?b.getPlayerContext(t):t;let c=r;if(l.position){const a=l.position.toUpperCase(),i=c.filter(s=>s.position===a);if(i.length===1)return i[0].fullName;i.length>1&&(c=i)}if(l.team){const a=l.team.toUpperCase(),i=c.filter(s=>s.team===a);if(i.length===1)return i[0].fullName;i.length>1&&(c=i)}if(c.length>1&&Number.isFinite(l.adp)){const a=c.filter(i=>Number.isFinite(i.medianPick));if(a.length>=1){let i=a[0],s=Math.abs(i.medianPick-l.adp);for(let d=1;d<a.length;d++){const p=Math.abs(a[d].medianPick-l.adp);p<s&&(i=a[d],s=p)}return console.debug(`[BBM] ambig "${e}" rowADP=${l.adp} → ${i.fullName} (medianPick=${i.medianPick})`),i.fullName}}c.length>1&&console.debug(`[BBM] ambig "${e}" unresolved`,{ctx:l,candidates:c.map(a=>({full:a.fullName,pos:a.position,team:a.team,med:a.medianPick}))})}return null}function Oe(e){if(K===0)return 0;const t=_(e);if(!t)return 0;const n=B.get(t);return n?n.size/K*100:0}function We(e){const t=_(e),n=(t&&B.get(t))??new Set,o=[];let r=0,l=0;return N.forEach(c=>{const a=B.get(k(c.name))??new Set;if(a.size===0)return;let i=0;a.size<n.size?a.forEach(d=>{n.has(d)&&i++}):n.forEach(d=>{a.has(d)&&i++});const s=i/a.size;r+=s,l++,o.push({name:c.name,position:c.position,round:c.round,pct:Math.round(s*100)})}),{score:l>0?Math.round(r/l*100):0,breakdown:o}}function yn(e){const t=e.querySelector(".bbm-stat-cell:not(.bbm-corr-trigger)"),n=e.querySelector(".bbm-corr-trigger");if(!t||!n)return;const o=ze(e);if(!o||K===0)return;const r=_(o,e)??o,l=Oe(r);t.textContent=`${Math.round(l)}%`;const c=n.querySelector(".bbm-corr-value"),a=n.querySelector(".bbm-corr-popup");if(!c||!a)return;const{score:i,breakdown:s}=We(r);c.textContent=`${i}%`,He(a,s),Ue(e,r),je(e,r),Qe(e,r),Ke(e,r)}function He(e,t){if(t.length===0){e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No picks yet</div>';return}e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div>'+t.map(n=>`<div class="bbm-corr-popup-row">
          <span class="bbm-corr-popup-pos">${n.position}</span>
          <span class="bbm-corr-popup-name">${fe(n.name)}</span>
          <div class="bbm-corr-popup-bar">
            <div class="bbm-corr-popup-bar-fill" style="width:${n.pct}%;background:#3b82f6"></div>
          </div>
          <span class="bbm-corr-popup-pct">${n.pct}%</span>
        </div>`).join("")}function Ue(e,t){e.querySelectorAll(".bbm-stack-pill").forEach(l=>l.remove());const n=hn(t);if(!n)return;const o=e.querySelector(b.selectors.stackPillTargetSelector);if(!o)return;const r=document.createElement("span");r.className="bbm-stack-pill bbm-inline-overlay",r.textContent=n.type,r.style.color=n.color,r.style.borderColor=n.color,r.style.background=`${n.color}1A`,o.appendChild(r)}function hn(e){const t=_(e);if(!t)return null;const n=v.get(t),o=A.get(t);if(!n||!o||N.length===0)return null;const r=N.filter(s=>{const d=v.get(k(s.name));return d&&d===n});if(r.length===0)return null;const l=r.filter(s=>s.position==="QB"),c=r.filter(s=>s.position==="WR"),a=r.filter(s=>s.position==="TE"),i=r.filter(s=>s.position==="RB");return o==="QB"&&(c.length>0||a.length>0||i.length>0)?{type:c.length+a.length+i.length>=2?"QB MULTI":"QB STACK",color:"#BF44EF"}:(o==="WR"||o==="TE"||o==="RB")&&l.length>0?{type:c.length+a.length+i.length>=1?"QB MULTI":"QB STACK",color:"#BF44EF"}:o==="WR"&&c.length>=1?{type:`WR ×${c.length+1}`,color:"#F59E0B"}:o==="TE"&&a.length>=1?{type:`TE ×${a.length+1}`,color:"#3B82F6"}:o==="RB"&&i.length>=1?{type:`RB ×${i.length+1}`,color:"#10B981"}:o==="RB"&&(c.length>0||a.length>0)?{type:"TEAM",color:"#8A9BB5"}:(o==="WR"||o==="TE")&&i.length>0?{type:"TEAM",color:"#8A9BB5"}:null}function wn(e){const t=_(e);if(!t)return null;const n=v.get(t),o=A.get(t);if(!n||!o||N.length===0)return null;const r=[];let l=0;return tn.forEach(c=>{var d;const a=rn(c)[o];if(!a)return;const i=(d=ve[n])==null?void 0:d[c];if(!i)return;const s=[];N.forEach(p=>{var Y;const g=k(p.name),m=v.get(g),h=A.get(g);if(!m||!h||m===n||m!==i)return;const T=(Y=ve[m])==null?void 0:Y[c];T&&T!==n||a.has(h)&&s.push({name:p.name,position:h,team:m,opp:n})}),s.length>0&&(r.push({week:c,entries:s}),l+=s.length)}),l===0?null:{count:l,weeks:r}}function je(e,t){const n=x==="pro"&&!E?wn(t):null,o=n?JSON.stringify(n):"",r=e.querySelector(".bbm-playoff-pill");if(r&&r._playoffSig===o||(r&&(f&&r._ownsPortal&&(f.style.display="none"),r.remove()),!n))return;const l=e.querySelector(b.selectors.stackPillTargetSelector);if(!l)return;const c=document.createElement("span");if(c.className="bbm-playoff-pill bbm-inline-overlay",n.weeks.length===1){const a=n.weeks[0];c.innerHTML=`<span class="bbm-playoff-chip bbm-playoff-w${a.week}">W${a.week}<span class="bbm-playoff-chip-count">${a.entries.length}</span></span>`}else{const a=n.weeks.map(i=>i.week).join("/");c.innerHTML=`<span class="bbm-playoff-chip bbm-playoff-multi">W${a}<span class="bbm-playoff-chip-count">${n.count}</span></span>`}c._playoffPayload=n,c._playoffSig=o,l.appendChild(c),vn(c)}function xn(e){return`<div class="bbm-corr-popup-title">Playoff Game Stacks</div>${e.weeks.map(n=>{const o=n.entries.map(r=>`
      <div class="bbm-corr-popup-row">
        <span class="bbm-corr-popup-pos">${r.position}</span>
        <span class="bbm-corr-popup-name">${fe(r.name)}</span>
        <span class="bbm-playoff-popup-matchup">${r.team} @ ${r.opp}</span>
      </div>`).join("");return`<div class="bbm-playoff-popup-week bbm-playoff-w${n.week}">Week ${n.week}</div>${o}`}).join("")}`}function vn(e){e.addEventListener("mouseenter",()=>{if(!e._playoffPayload)return;ge(),f.innerHTML=xn(e._playoffPayload);const t=e.getBoundingClientRect();f.style.left=`${Math.max(8,t.right-280)}px`,f.style.top=`${t.bottom+4}px`,f.style.display="block",e._ownsPortal=!0}),e.addEventListener("mouseleave",()=>{e._ownsPortal=!1,f&&(f.style.display="none")})}function En(){const e=document.createElement("div");e.className="bbm-inline-overlay bbm-stat-cell",e.textContent="--%";const t=document.createElement("div");t.className="bbm-inline-overlay bbm-stat-cell bbm-corr-trigger";const n=document.createElement("span");n.className="bbm-corr-value",n.textContent="--";const o=document.createElement("div");return o.className="bbm-corr-popup",o.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No draft data yet</div>',t.appendChild(n),t.appendChild(o),t.addEventListener("mouseenter",()=>{ge(),f.innerHTML=o.innerHTML;const r=t.getBoundingClientRect();f.style.left=`${Math.max(8,r.right-280)}px`,f.style.top=`${r.bottom+4}px`,f.style.display="block"}),t.addEventListener("mouseleave",()=>{f&&(f.style.display="none")}),[e,t]}function ge(){f&&document.body.contains(f)||(f=document.createElement("div"),f.className="bbm-corr-popup",f.id="bbm-corr-popup-portal",f.style.cssText="display: none; position: fixed; z-index: 10001;",document.body.appendChild(f))}function kn(e){var s,d;const t=((s=b.getRowId)==null?void 0:s.call(b,e))??e.getAttribute("data-id");if(!t)return;if(e.getAttribute(te)===t){yn(e);return}e.querySelectorAll(".bbm-inline-overlay").forEach(p=>p.remove()),e.querySelectorAll(".bbm-tier-badge").forEach(p=>p.remove()),e.removeAttribute("data-bbm-tier");const{parent:o,before:r}=((d=b.getInjectionPoint)==null?void 0:d.call(b,e))??{};if(!o)return;const[l,c]=En();r?(o.insertBefore(l,r),o.insertBefore(c,r)):o.append(l,c),b.postInjectRow&&b.postInjectRow(e,l,c),e.setAttribute(te,t),e.setAttribute(Re,t);const a=ze(e),i=_(a,e)??a;if(K>0&&i){const p=Oe(i);l.textContent=`${Math.round(p)}%`;const{score:g,breakdown:m}=We(i),h=c.querySelector(".bbm-corr-value"),T=c.querySelector(".bbm-corr-popup");h.textContent=`${g}%`,He(T,m)}i&&(Ue(e,i),je(e,i)),Qe(e,i),Ke(e,i)}function Ke(e,t){if(e.querySelectorAll(".bbm-tier-badge").forEach(s=>s.remove()),e.removeAttribute("data-bbm-tier"),!b.isMyRankSort()||de.size===0||!t)return;const n=_(t),o=de.get(n??t.trim().toLowerCase());if(!o)return;const{tierNum:r,rank:l}=o;if(e.setAttribute("data-bbm-tier",String(r)),!pe.has(l))return;const c=ln(r),a=Pe(r),i=document.createElement("div");i.className="bbm-tier-badge",i.style.color=c,i.innerHTML=`<span class="bbm-tier-pill">${a}</span>`,e.prepend(i)}function Sn(){const e=document.querySelector(b.selectors.sortButtonsSelector);if(!e||(I||(I=new MutationObserver(C),I.observe(e,{attributes:!0,subtree:!0})),e.hasAttribute(J)))return;if(b.injectHeaderCells){b.injectHeaderCells(e),e.setAttribute(J,"true");return}const t=document.querySelector(b.selectors.rowSelector);if(!t)return;const n=e.getBoundingClientRect(),o=t.querySelectorAll(".bbm-stat-cell");if(o.length<2)return;const r=o[0].getBoundingClientRect(),l=o[1].getBoundingClientRect(),c=n.right,a=c-r.right,i=c-l.right;e.style.position="relative";const s=document.createElement("span");s.className="bbm-header-label",s.textContent="Exp",s.style.right=`${a}px`,s.style.width=`${r.width}px`;const d=document.createElement("span");d.className="bbm-header-label",d.textContent="Corr",d.style.right=`${i}px`,d.style.width=`${l.width}px`,e.appendChild(s),e.appendChild(d),e.setAttribute(J,"true")}function Bn(){document.querySelectorAll(".bbm-header-label").forEach(e=>e.remove()),document.querySelectorAll(`[${J}]`).forEach(e=>{e.removeAttribute(J)})}function C(){H||(H=requestAnimationFrame(()=>{var t;if(H=null,!w||x!=="pro")return;(((t=b.getPlayerRows)==null?void 0:t.call(b))??document.querySelectorAll(b.selectors.rowSelector)).forEach(kn),Sn()}))}function Ge(){document.querySelectorAll(".bbm-inline-overlay").forEach(e=>e.remove()),document.querySelectorAll(".bbm-tier-badge").forEach(e=>e.remove()),document.querySelectorAll("[data-bbm-tier]").forEach(e=>e.removeAttribute("data-bbm-tier")),document.querySelectorAll(`[${te}]`).forEach(e=>{e.removeAttribute(te),e.removeAttribute(Re)}),Bn(),f&&(f.remove(),f=null)}function An(){if(document.getElementById("bbm-overlay-styles"))return;const e=document.createElement("style");e.id="bbm-overlay-styles",e.textContent=`
    /* DK: allow overlay cells to overflow fixed-width rows (scoped to rows, not scroll container) */
    .BaseTable__row {
      overflow: visible !important;
    }

    .bbm-stat-cell {
      color: inherit;
      opacity: 0.6;
      font-family: inherit;
      font-size: 11px;
      white-space: nowrap;
      flex-shrink: 0;
      width: 40px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }
    .bbm-stat-cell + .bbm-stat-cell {
      margin-left: 12px;
    }

    /* Corr cell is hoverable */
    .bbm-corr-trigger {
      pointer-events: auto;
      cursor: default;
      position: relative;
    }
    .bbm-corr-trigger:hover {
      opacity: 1;
    }

    /* Correlation popup — hidden by default, shown via JS mouseenter/mouseleave */
    .bbm-corr-popup {
      display: none;
      background: var(--bg-primary, #1a1a2e);
      color: #E8E8E8;
      border: 1px solid var(--border-color, #333);
      border-radius: 8px;
      padding: 8px 0;
      z-index: 10001;
      min-width: 220px;
      max-width: 300px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      white-space: normal;
      text-align: left;
      opacity: 1;
    }
    .bbm-corr-popup-title {
      padding: 0 12px 6px;
      font-size: 10px;
      color: #E8E8E8;
      opacity: 0.5;
      text-transform: uppercase;
      font-weight: 700;
      letter-spacing: 0.05em;
    }
    .bbm-corr-popup-empty {
      padding: 4px 12px;
      font-size: 12px;
      color: #E8E8E8;
      opacity: 0.4;
      font-style: italic;
    }

    /* Rows for when real data is wired in */
    .bbm-corr-popup-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 12px;
    }
    .bbm-corr-popup-pos {
      font-size: 10px;
      font-weight: 900;
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 22px;
      text-align: center;
    }
    .bbm-corr-popup-name {
      font-size: 12px;
      font-weight: 600;
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-corr-popup-bar {
      width: 40px;
      height: 5px;
      background: rgba(128, 128, 128, 0.3);
      border-radius: 3px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .bbm-corr-popup-bar-fill {
      height: 100%;
      border-radius: 3px;
    }
    .bbm-corr-popup-pct {
      font-size: 11px;
      font-weight: 700;
      font-family: monospace;
      min-width: 28px;
      text-align: right;
    }

    /* Stack pill — inline after player name, only visible when stacking */
    .bbm-stack-pill {
      display: inline-block;
      vertical-align: middle;
      margin-left: 6px;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid;
      line-height: 1.5;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0.85;
    }

    /* Playoff game-stack pill (TASK-232) — container for per-week chips colored
       bronze/silver/gold (W15/W16/W17) to differentiate weeks at a glance.
       Interactive (hover opens the shared correlation popup with playoff-grouped
       contents). */
    .bbm-playoff-pill {
      display: inline-flex;
      vertical-align: middle;
      align-items: center;
      gap: 3px;
      margin-left: 4px;
      line-height: 1.5;
      white-space: nowrap;
      cursor: default;
    }
    .bbm-playoff-chip {
      display: inline-flex;
      align-items: center;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid currentColor;
      background: rgba(255, 255, 255, 0.04);
      opacity: 0.95;
    }
    .bbm-playoff-chip-count {
      display: inline-block;
      margin-left: 4px;
      color: currentColor;
      font-weight: 800;
      text-align: center;
    }
    /* W15 bronze, W16 silver, W17 gold for single-week chips and popup
       section headers. Multi-week collapses to a single red pill (so the
       red signals "spans multiple playoff weeks" at a glance). */
    .bbm-playoff-w15 { color: #CD7F32; }
    .bbm-playoff-w16 { color: #C9CED6; }
    .bbm-playoff-w17 { color: #FFD700; }
    .bbm-playoff-multi { color: #EF4444; }

    .bbm-playoff-popup-week {
      margin-top: 8px;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      opacity: 0.95;
    }
    .bbm-playoff-popup-week:first-child {
      margin-top: 4px;
    }
    .bbm-playoff-popup-matchup {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.04em;
      color: inherit;
      opacity: 0.65;
      margin-left: auto;
      white-space: nowrap;
    }

    /* Tier break — full-width divider with centered pill label */
    .bbm-tier-badge {
      position: absolute;
      left: 0;
      right: 0;
      top: -7px;
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: none;
      z-index: 0;
      padding: 0 10px;
    }
    .bbm-tier-badge::before,
    .bbm-tier-badge::after {
      content: '';
      flex: 1;
      height: 1px;
      background: currentColor;
      opacity: 0.35;
    }
    .bbm-tier-pill {
      font-size: 8px;
      font-weight: 800;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      padding: 2px 6px;
      border-radius: 3px;
      background: #0C1A30;
      border: 1px solid currentColor;
      color: inherit;
      white-space: nowrap;
      line-height: 1.5;
      flex-shrink: 0;
    }

    .bbm-header-label {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      color: inherit;
      opacity: 0.5;
      font-family: inherit;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }

    /* Auth section (TASK-129) */
    #bbm-auth-section { margin: 6px 0; }

    .bbm-account-toggle {
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 3px 0;
      user-select: none;
    }
    .bbm-account-toggle-label {
      font-size: 10px;
      color: #8A9BB5;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .bbm-account-chevron {
      font-size: 9px;
      color: #5a6a80;
      transition: transform 0.15s;
      line-height: 1;
    }
    .bbm-account-body { padding-top: 6px; }

    .bbm-auth-input {
      width: 100%;
      background: #0F2040;
      border: 1px solid #243A5C;
      border-radius: 4px;
      color: #E8E8E8;
      font-size: 11px;
      padding: 5px 7px;
      margin-bottom: 4px;
      box-sizing: border-box;
      outline: none;
    }
    .bbm-auth-input:focus { border-color: #E8BF4A; }

    .bbm-btn {
      width: 100%;
      background: #E8BF4A;
      color: #0C1A30;
      border: none;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      padding: 5px 0;
      cursor: pointer;
      margin-bottom: 4px;
    }
    .bbm-btn:hover { background: #F0CC5B; }
    .bbm-btn:disabled { opacity: 0.5; cursor: default; }

    .bbm-btn-secondary {
      background: transparent;
      color: #8A9BB5;
      border: 1px solid #243A5C;
    }
    .bbm-btn-secondary:hover { color: #E8E8E8; border-color: #8A9BB5; }

    .bbm-btn-google {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: #fff;
      color: #3c4043;
      font-weight: 600;
    }
    .bbm-btn-google:hover { background: #f1f3f4; }

    .bbm-btn-apple {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: #000;
      color: #fff;
      font-weight: 600;
    }
    .bbm-btn-apple:hover { background: #1a1a1a; }

    .bbm-auth-divider {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 6px 0;
      font-size: 9px;
      color: #5A6E8A;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .bbm-auth-divider::before,
    .bbm-auth-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #243A5C;
    }

    .bbm-auth-user {
      font-size: 11px;
      color: #C0CCE0;
      margin-bottom: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-auth-tier {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 6px;
      background: #1C3A5E;
      color: #8A9BB5;
    }
    .bbm-auth-tier.pro { background: #2A3A10; color: #A3C447; }

    .bbm-auth-error {
      font-size: 10px;
      color: #EF4444;
      margin-top: 2px;
    }
    .bbm-sync-result {
      font-size: 10px;
      color: #10B981;
      margin-bottom: 4px;
    }
    .bbm-sync-result.error { color: #EF4444; }

    .bbm-sync-progress { margin-bottom: 6px; }
    .bbm-progress-label {
      font-size: 10px;
      color: #8A9BB5;
      margin-bottom: 3px;
    }
    .bbm-progress-bar-wrap {
      width: 100%;
      height: 4px;
      background: #1a2d50;
      border-radius: 2px;
      overflow: hidden;
    }
    .bbm-progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #D4A843, #F0CC5B);
      border-radius: 2px;
      transition: width 0.2s ease;
    }
    @keyframes bbm-shimmer {
      0%   { transform: translateX(-100%); }
      100% { transform: translateX(400%); }
    }
    .bbm-progress-indeterminate .bbm-progress-bar-fill {
      width: 25%;
      animation: bbm-shimmer 1.4s ease-in-out infinite;
    }

    /* FAB — brand logo button, bottom-left. Whispers at rest, speaks on hover. */
    #bbm-fab {
      position: fixed;
      bottom: 14px;
      left: 14px;
      z-index: 10000;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      opacity: 0.3;
      transition: opacity 120ms ease, filter 120ms ease;
    }
    #bbm-fab:hover {
      opacity: 1;
      filter: drop-shadow(0 0 8px rgba(232, 191, 74, 0.5));
    }

    /* Configuration panel — compact, only visible on demand */
    #bbm-panel {
      display: none;
      position: fixed;
      bottom: 50px;
      left: 14px;
      z-index: 10000;
      background: #0C1A30;
      border: 1px solid #243A5C;
      border-radius: 8px;
      padding: 10px 14px;
      min-width: 210px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
      font-size: 12px;
      color: #E8E8E8;
    }
    #bbm-panel.open {
      display: block;
    }
    .bbm-panel-title {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8A9BB5;
      margin-bottom: 8px;
    }
    .bbm-panel-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .bbm-panel-label {
      font-size: 12px;
      font-weight: 600;
      color: #E8E8E8;
    }
    #bbm-overlay-toggle {
      cursor: pointer;
      width: 14px;
      height: 14px;
      accent-color: #E8BF4A;
    }

    /* TASK-231: locked overlay row (non-Pro) */
    .bbm-lock-icon {
      display: none;
      margin-left: 5px;
      font-size: 11px;
      vertical-align: -1px;
      filter: grayscale(1) brightness(1.3);
      opacity: 0.7;
    }
    #bbm-overlay-row.bbm-locked {
      opacity: 0.5;
      cursor: not-allowed;
    }
    #bbm-overlay-row.bbm-locked .bbm-panel-label {
      pointer-events: none;
    }
    #bbm-overlay-row.bbm-locked .bbm-lock-icon {
      display: inline;
    }
    #bbm-overlay-row.bbm-locked #bbm-overlay-toggle {
      pointer-events: none;
      cursor: not-allowed;
    }

    /* TASK-231: Upgrade-to-Pro CTA */
    #bbm-upgrade-cta {
      margin: 8px 0 4px;
    }
    .bbm-upgrade-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      padding: 7px 10px;
      border-radius: 6px;
      background: linear-gradient(135deg, #D4A843 0%, #F0CC5B 50%, #E8BF4A 100%);
      color: #0C1A30;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      text-decoration: none;
      border: 1px solid #B8911E;
      box-shadow: 0 1px 4px rgba(232, 191, 74, 0.25);
      box-sizing: border-box;
      transition: filter 120ms ease, transform 120ms ease;
    }
    .bbm-upgrade-btn:hover {
      filter: brightness(1.08);
      transform: translateY(-1px);
    }
    .bbm-upgrade-icon {
      font-size: 13px;
      line-height: 1;
    }
    .bbm-upgrade-sub {
      font-size: 10px;
      color: #8A9BB5;
      text-align: center;
      margin-top: 4px;
    }

    /* Confidence panel — status and sync lines (TASK-106) */
    .bbm-panel-divider {
      border: none;
      border-top: 1px solid #243A5C;
      margin: 8px 0;
    }
    .bbm-panel-status {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
    }
    .bbm-status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #6B7280;
    }
    .bbm-status-label {
      font-size: 11px;
      color: #C0CCE0;
    }
    .bbm-panel-sync-line {
      font-size: 10px;
      color: #8A9BB5;
      margin-top: 3px;
      padding-left: 12px;
    }

    /* Tournament filter (TASK-107) — hierarchical: slate → tournament */
    .bbm-filter-title {
      margin-top: 6px;
      margin-bottom: 4px;
    }
    #bbm-tournament-filter {
      max-height: 140px;
      overflow-y: auto;
    }
    .bbm-filter-check {
      cursor: pointer;
      accent-color: #E8BF4A;
      flex-shrink: 0;
      width: 12px;
      height: 12px;
    }
    .bbm-filter-slate-group {
      border-bottom: 1px solid #1E3054;
    }
    .bbm-filter-slate-group:last-child {
      border-bottom: none;
    }
    .bbm-filter-slate-row {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 3px 0;
    }
    .bbm-filter-slate-label-wrap {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 1;
      cursor: pointer;
      min-width: 0;
    }
    .bbm-filter-slate-label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #8A9BB5;
    }
    .bbm-filter-expand {
      background: none;
      border: none;
      color: #8A9BB5;
      font-size: 7px;
      padding: 0 2px;
      cursor: pointer;
      flex-shrink: 0;
      line-height: 1;
    }
    .bbm-filter-tournaments {
      display: none;
    }
    .bbm-filter-slate-group.bbm-expanded .bbm-filter-tournaments {
      display: block;
    }
    .bbm-filter-tournament-row {
      display: flex;
      align-items: center;
      gap: 5px;
      padding: 2px 0 2px 14px;
      cursor: pointer;
    }
    .bbm-filter-tournament-label {
      font-size: 11px;
      color: #C0CCE0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* ---- Eliminator Mode (TASK-270) ---- */
    #bbm-eliminator-toggle {
      cursor: pointer;
      width: 14px;
      height: 14px;
      accent-color: #E8BF4A;
    }
    #bbm-eliminator-row.bbm-locked {
      opacity: 0.5;
      cursor: not-allowed;
    }
    #bbm-eliminator-row.bbm-locked .bbm-panel-label {
      pointer-events: none;
    }
    #bbm-eliminator-row.bbm-locked .bbm-lock-icon {
      display: inline;
    }
    #bbm-eliminator-row.bbm-locked #bbm-eliminator-toggle {
      pointer-events: none;
      cursor: not-allowed;
    }

    /* Per-candidate Eliminator badge — inline pill after player name (mirrors stack pill) */
    .bbm-eliminator-badge {
      display: inline-block;
      vertical-align: middle;
      margin-left: 6px;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid;
      line-height: 1.5;
      white-space: nowrap;
      pointer-events: auto;
      cursor: help;
      opacity: 0.9;
    }

    /* Floating Eliminator window — persistent draft companion, bottom-right.
       Below the FAB panel / popups (z 10000/10001) so it never occludes them. */
    #bbm-eliminator-window {
      position: fixed;
      bottom: 14px;
      right: 14px;
      z-index: 9998;
      width: 232px;
      max-height: 70vh;
      overflow-y: auto;
      background: #0C1A30;
      border: 1px solid #243A5C;
      border-radius: 8px;
      padding: 10px 12px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
      font-family: inherit;
      font-size: 12px;
      color: #E8E8E8;
    }
    .bbm-elim-header {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 8px;
      cursor: move;
      user-select: none;
    }
    .bbm-elim-grip {
      color: #5A6B85;
      font-size: 12px;
      line-height: 1;
    }
    .bbm-elim-title {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #E8BF4A;
    }
    #bbm-eliminator-window.bbm-elim-dragging {
      opacity: 0.92;
      box-shadow: 0 10px 28px rgba(0,0,0,0.6);
    }

    .bbm-elim-bye-row {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 3px;
    }
    .bbm-elim-bye-pos {
      width: 22px;
      font-weight: 700;
      color: #C0CCE0;
    }
    .bbm-elim-bye-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 3px;
    }
    .bbm-elim-bye-chip {
      font-size: 9px;
      font-weight: 700;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid #2c4366;
      color: #C0CCE0;
      background: rgba(44,67,102,0.3);
      white-space: nowrap;
      cursor: help;
    }
    .bbm-elim-bye-premium { border-color: #E8BF4A; color: #F0CC5B; background: rgba(232,191,74,0.12); }
    .bbm-elim-bye-strong  { border-color: #10B981; color: #34D399; background: rgba(16,185,129,0.12); }
    .bbm-elim-bye-shared  { border-color: #3B82F6; color: #60A5FA; background: rgba(59,130,246,0.12); }
    .bbm-elim-bye-early   { border-color: #EF4444; color: #F87171; background: rgba(239,68,68,0.12); }
    .bbm-elim-empty {
      font-size: 11px;
      color: #8A9BB5;
      font-style: italic;
    }
  `,document.head.appendChild(e)}function G(){if($||x!=="pro")return;z(),fn(),Fe(),$=Ae({targetSelector:b.selectors.gridSelector,onMutation:C,onReconnect:()=>{C()}});const e=document.querySelector(b.selectors.sortButtonsSelector);e&&(I=new MutationObserver(C),I.observe(e,{attributes:!0,subtree:!0})),C(),q()}function X(){$&&($.disconnect(),$=null),I&&(I.disconnect(),I=null),H&&(cancelAnimationFrame(H),H=null),E&&x==="pro"||qe(),Ge()}function Ye(){return N.map(e=>{const t=k(e.name);return{name:e.name,position:e.position,team:oe.get(t)||v.get(t)||null}})}async function Cn(){if(!(ce||!(b!=null&&b.getDraftPlayerTeams))){ce=!0;try{const e=await b.getDraftPlayerTeams(),t=new Map;(e??[]).forEach(({name:n,team:o})=>{const r=k(n);r&&o&&!t.has(r)&&t.set(r,String(o).toUpperCase())}),t.size>0&&(oe=t,E&&re())}catch{}}}function Tn(e){return e.summary.length?e.summary.map(t=>{const n=t.weeks.map(o=>{const r=o.players.length>1?`×${o.players.length}`:"",l=P(o.players.join("|"));return`<span class="bbm-elim-bye-chip bbm-elim-bye-${o.tier}" data-bye-players="${l}" data-bye-week="${o.week}" data-bye-pos="${P(t.position)}" title="${P(o.players.join(", "))}">W${o.week}${r}</span>`}).join("");return`<div class="bbm-elim-bye-row"><span class="bbm-elim-bye-pos">${t.position}</span><span class="bbm-elim-bye-chips">${n}</span></div>`}).join(""):'<div class="bbm-elim-empty">No byes tracked yet</div>'}function Je(e,t,n){e.addEventListener("mouseenter",()=>{ge();const o=n.map(l=>`<div class="bbm-corr-popup-row"><span class="bbm-corr-popup-name">${P(fe(l))}</span></div>`).join("");f.innerHTML=`<div class="bbm-corr-popup-title">${P(t)}</div>${o}`;const r=e.getBoundingClientRect();f.style.left=`${Math.max(8,Math.min(r.left,window.innerWidth-220))}px`,f.style.top=`${r.bottom+4}px`,f.style.display="block"}),e.addEventListener("mouseleave",()=>{f&&(f.style.display="none")})}function Ln(e){e.querySelectorAll(".bbm-elim-bye-chip").forEach(t=>{const n=t.getAttribute("data-bye-players");if(!n)return;const o=t.getAttribute("data-bye-week"),r=t.getAttribute("data-bye-pos");Je(t,`${r} · Week ${o} bye`,n.split("|"))})}function Mn(e,t){let n=0,o=0,r=0,l=0,c=!1;const a=s=>{if(!c)return;const d=Math.max(0,Math.min(r+(s.clientX-n),window.innerWidth-e.offsetWidth)),p=Math.max(0,Math.min(l+(s.clientY-o),window.innerHeight-e.offsetHeight));e.style.left=`${d}px`,e.style.top=`${p}px`},i=()=>{c&&(c=!1,e.classList.remove("bbm-elim-dragging"),document.removeEventListener("mousemove",a),document.removeEventListener("mouseup",i),chrome.storage.local.set({eliminatorWindowPos:{left:e.style.left,top:e.style.top}}))};t.addEventListener("mousedown",s=>{if(s.button!==0)return;const d=e.getBoundingClientRect();e.style.left=`${d.left}px`,e.style.top=`${d.top}px`,e.style.right="auto",e.style.bottom="auto",r=d.left,l=d.top,n=s.clientX,o=s.clientY,c=!0,e.classList.add("bbm-elim-dragging"),document.addEventListener("mousemove",a),document.addEventListener("mouseup",i),s.preventDefault()})}function In(){if(document.getElementById("bbm-eliminator-window"))return;const e=document.createElement("div");e.id="bbm-eliminator-window",e.innerHTML=`
    <div class="bbm-elim-header" id="bbm-elim-drag">
      <span class="bbm-elim-grip" aria-hidden="true">⠿</span>
      <span class="bbm-elim-title">Eliminator · Byes</span>
    </div>
    <div id="bbm-elim-bye"></div>
  `,document.body.appendChild(e),chrome.storage.local.get(["eliminatorWindowPos"],t=>{const n=t.eliminatorWindowPos;n&&n.left&&n.top&&document.body.contains(e)&&(e.style.left=n.left,e.style.top=n.top,e.style.right="auto",e.style.bottom="auto")}),Mn(e,e.querySelector("#bbm-elim-drag")),re()}function re(){const e=document.getElementById("bbm-eliminator-window");if(!e)return;const t=Zt(Ye()),n=e.querySelector("#bbm-elim-bye");n.innerHTML=Tn(t),Ln(n)}function ye(){var e;(e=document.getElementById("bbm-eliminator-window"))==null||e.remove()}function q(){var t;const e=!!((t=b==null?void 0:b.isDraftPage)!=null&&t.call(b));E&&e&&x==="pro"?(In(),Fe(),Cn(),re(),w&&C()):(ye(),document.querySelectorAll(".bbm-eliminator-badge").forEach(n=>n.remove()),w&&x==="pro"&&C())}function Qe(e,t){if(e.querySelectorAll(".bbm-eliminator-badge").forEach(i=>i.remove()),!E||!t)return;const n=_(t),o=k(t),r={name:t,position:n&&A.get(n)||null,team:oe.get(o)||n&&v.get(n)||null},l=en(r,Ye());if(!l)return;const c=[];if(l.byeClash&&c.push({text:`BYE×${l.byeClash.players.length+1}`,color:"#F59E0B",title:`Same-position bye collision (Week ${l.byeClash.week}) with ${l.byeClash.players.join(", ")} — breaks the rainbow`,popup:{title:`${r.position||""} · shares Week ${l.byeClash.week} bye`.trim(),players:l.byeClash.players}}),c.length===0)return;const a=e.querySelector(b.selectors.stackPillTargetSelector);a&&c.forEach(i=>{const s=document.createElement("span");s.className="bbm-eliminator-badge bbm-inline-overlay",s.textContent=i.text,s.style.color=i.color,s.style.borderColor=i.color,s.style.background=`${i.color}1A`,s.title=i.title,i.popup&&Je(s,i.popup.title,i.popup.players),a.appendChild(s)})}function _n(){if(document.getElementById("bbm-fab"))return;const e=document.createElement("button");e.id="bbm-fab",e.title="Best Ball Exposures",e.innerHTML=`<svg width="36" height="36" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Best Ball Exposures">
    <defs>
      <linearGradient id="bb-gold" x1="10" y1="10" x2="38" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%"   stop-color="#F0CC5B"/>
        <stop offset="50%"  stop-color="#D4A843"/>
        <stop offset="100%" stop-color="#E8BF4A"/>
      </linearGradient>
      <linearGradient id="bb-bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#0C1A30"/>
        <stop offset="100%" stop-color="#060E1F"/>
      </linearGradient>
    </defs>
    <circle cx="24" cy="24" r="24" fill="url(#bb-bg)"/>
    <circle cx="24" cy="24" r="22.5" fill="none" stroke="url(#bb-gold)" stroke-width="2"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="#E8BF4A" stroke-width="0.5" opacity="0.18"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="url(#bb-gold)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="18 7 10 7 23 7 8 7.96" transform="rotate(-90 24 24)"/>
    <circle cx="24" cy="24" r="2.5" fill="url(#bb-gold)"/>
  </svg>`;const t=document.createElement("div");t.id="bbm-panel",t.innerHTML=`
    <div class="bbm-panel-title">Best Ball Exposures</div>
    <div id="bbm-auth-section"></div>
    <div id="bbm-upgrade-cta" style="display:none"></div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-row" id="bbm-overlay-row">
      <label class="bbm-panel-label" for="bbm-overlay-toggle">
        Overlay
        <span class="bbm-lock-icon" aria-hidden="true">🔒</span>
      </label>
      <input type="checkbox" id="bbm-overlay-toggle" />
    </div>
    <div class="bbm-panel-row" id="bbm-eliminator-row">
      <label class="bbm-panel-label" for="bbm-eliminator-toggle">
        Eliminator Mode
        <span class="bbm-lock-icon" aria-hidden="true">🔒</span>
      </label>
      <input type="checkbox" id="bbm-eliminator-toggle" />
    </div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-status">
      <span class="bbm-status-dot"></span>
      <span class="bbm-status-label">—</span>
    </div>
    <div class="bbm-panel-sync-line">—</div>
    <div id="bbm-filter-wrap">
      <hr class="bbm-panel-divider" />
      <div class="bbm-panel-title bbm-filter-title">Tournament Filter</div>
      <div id="bbm-tournament-filter" style="display:none"></div>
    </div>
  `;const n=t.querySelector("#bbm-overlay-toggle");n.checked=w;const o=t.querySelector("#bbm-eliminator-toggle");o.checked=E,t.querySelector(".bbm-panel-status").addEventListener("click",()=>{R==="error"&&z()}),t.addEventListener("click",l=>l.stopPropagation()),e.addEventListener("click",l=>{l.stopPropagation(),t.classList.toggle("open"),t.classList.contains("open")&&(V(),ne(),F())}),n.addEventListener("change",()=>{if(x!=="pro"){n.checked=!1;return}w=n.checked,chrome.storage.local.set({overlayEnabled:w}),w?G():X()}),o.addEventListener("change",()=>{if(x!=="pro"){o.checked=!1;return}E=o.checked,chrome.storage.local.set({eliminatorEnabled:E}),q()}),document.body.appendChild(e),document.body.appendChild(t)}function Be(){const e=window.location.href;if(e===le)return;const t=Q;le=e,Q=b.isDraftPage();const n=Q;!t&&n?F().then(()=>{w&&x==="pro"&&G(),q()}):t&&!n?(X(),ye(),qe()):t&&n&&(X(),F().then(()=>{w&&x==="pro"&&G(),q()}))}function Rn(){setInterval(()=>{window.location.href!==le&&Be()},300),window.addEventListener("popstate",Be)}function Pn(e,t=null){b=e,ue=t,chrome.storage.local.get(["overlayEnabled","tournamentFilter","eliminatorEnabled"],n=>{w=n.overlayEnabled!==!1,E=n.eliminatorEnabled===!0,y=new Set(n.tournamentFilter??[]),Q=b.isDraftPage(),An(),_n(),Rn(),F().then(()=>{Q&&w&&x==="pro"?G():z(),q()}),document.addEventListener("click",()=>{var o;(o=document.getElementById("bbm-panel"))==null||o.classList.remove("open")}),document.addEventListener("keydown",o=>{var r;o.key==="Escape"&&((r=document.getElementById("bbm-panel"))==null||r.classList.remove("open"))})}),chrome.runtime.onMessage.addListener(n=>{if(n.type!=="TOGGLE_OVERLAY"||x!=="pro"&&n.enabled)return;w=n.enabled;const o=document.getElementById("bbm-overlay-toggle");o&&(o.checked=w),w?b.isDraftPage()&&G():X(),q()})}const O=Ve(window.location.href);if(O){document.querySelector("#root, #app, [data-reactroot]")&&Ae({targetSelector:"#root, #app, [data-reactroot]",onMutation:()=>{},onReconnect:()=>{}});async function t(){var a,i;const n=await ot(),o=await O.getEntries(n),r=await lt(o,{platform:O.platform});if((a=o==null?void 0:o.boards)!=null&&a.length)try{await xe(o.boards)}catch(s){console.warn("[BBM] writeBoards failed (entries synced OK):",s.message)}const l=100;let c=0;if(typeof O.getBoards=="function"&&((i=o==null?void 0:o.currentDraftIds)!=null&&i.length))try{const s=new Set((o.boards??[]).map(m=>String(m.draftId))),d=await rt(o.currentDraftIds),p=o.currentDraftIds.map(String).filter(m=>!d.has(m)&&!s.has(m)),g=p.slice(0,l);if(g.length){const m=await O.getBoards(g);await xe(m)}c=Math.max(0,p.length-g.length)}catch(s){console.warn("[BBM] board backfill failed (sync OK):",s.message)}return{...r,boardsRemaining:c}}Pn(O,t),chrome.runtime.onMessage.addListener((n,o,r)=>n.type!=="SYNC_ENTRIES"?!1:(t().then(({count:l})=>r({ok:!0,count:l})).catch(l=>r({ok:!1,error:l.message})),!0))}
