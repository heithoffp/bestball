import{s as b,g as ke}from"./supabase-Pq7oSeey.js";function ue({targetSelector:e,onMutation:t,onReconnect:n,pollInterval:r=500,maxRetries:o=20}){let s=null,l=null,i=null,a=!1;const d={childList:!0,subtree:!0};function c(y){s&&s.disconnect(),s=new MutationObserver(t),s.observe(y,d),l=y}function p(){i&&clearInterval(i);let y=0;i=setInterval(()=>{if(a){clearInterval(i);return}const I=document.querySelector(e);I?(clearInterval(i),i=null,c(I),n==null||n()):++y>=o&&(clearInterval(i),i=null)},r)}const x=new MutationObserver(()=>{if(a)return;const y=document.querySelector(e);!y&&s?(s.disconnect(),s=null,l=null,p()):y&&s&&y!==l&&(c(y),n==null||n())}),g=document.querySelector(e);return g?c(g):p(),x.observe(document.body,{childList:!0,subtree:!0}),{disconnect(){a=!0,i&&clearInterval(i),s&&s.disconnect(),x.disconnect()}}}async function be(){if(!b)return null;const{data:{session:e}}=await b.auth.getSession();return e}async function Ce(e,t){if(!b)throw new Error("[BBM] Supabase not configured");const{data:n,error:r}=await b.auth.signInWithPassword({email:e,password:t});if(r)throw r;return n.session}async function Be(){if(!b)throw new Error("[BBM] Supabase not configured");const e=await chrome.runtime.sendMessage({type:"GOOGLE_OAUTH"});if(e.error)throw new Error(e.error);const{data:t,error:n}=await b.auth.setSession({access_token:e.access_token,refresh_token:e.refresh_token});if(n)throw n;return t.session}async function Ae(){b&&await b.auth.signOut()}async function _e(){var e,t,n;try{if(!b)return null;const{data:{session:r}}=await b.auth.getSession();if(!r)return null;const o=r.user.id,[s,l]=await Promise.all([b.from("subscriptions").select("status").eq("user_id",o).in("status",["active","trialing"]).limit(1).maybeSingle(),b.from("profiles").select("beta_expires_at").eq("id",o).maybeSingle()]),i=((e=s.data)==null?void 0:e.status)==="active"||((t=s.data)==null?void 0:t.status)==="trialing",a=(n=l.data)==null?void 0:n.beta_expires_at,d=a?new Date(a)>new Date:!1;return i||d?"pro":"free"}catch{return null}}async function Me(){if(!b)return[];const{data:{session:e}}=await b.auth.getSession();if(!e)return[];const{data:t,error:n}=await b.from("extension_entries").select("entry_id").eq("user_id",e.user.id);return n?[]:(t??[]).map(r=>r.entry_id)}async function Ie(){if(!b)throw new Error("[BBM] Supabase not configured");const{data:{session:e}}=await b.auth.getSession();if(!e)throw new Error("[BBM] Not authenticated");const{data:t,error:n}=await b.from("extension_entries").select("entry_id, tournament, slate_title, draft_date, players").eq("user_id",e.user.id);if(n)throw n;return(t??[]).map(r=>({entryId:r.entry_id,tournamentTitle:r.tournament,slateTitle:Te(r.slate_title??"",r.tournament),draftDate:r.draft_date,players:r.players??[]}))}function Te(e,t){return!e||!e.startsWith("DK")?e:(t||"").toLowerCase().includes("early bird")?"DK Pre-Draft":"DK Post-Draft"}async function qe(){if(!b)return null;const{data:{session:e}}=await b.auth.getSession();if(!e)return null;const{data:t,error:n}=await b.from("user_rankings").select("rankings").eq("user_id",e.user.id).maybeSingle();return n||!t?null:t.rankings??null}function ie(e,t){return{user_id:e,entry_id:t.entryId,tournament:t.tournamentTitle??null,slate_title:t.slateTitle??null,draft_date:t.draftDate??null,players:t.players??[],synced_at:new Date().toISOString()}}async function Le(e,{platform:t}={}){if(!b)throw new Error("[BBM] Supabase not configured");const{data:{session:n}}=await b.auth.getSession();if(!n)throw new Error("[BBM] Not authenticated");const r=n.user.id;if(!Array.isArray(e)){if(!t)throw new Error("[BBM] Incremental writeEntries requires platform");const{newEntries:c=[],currentDraftIds:p=[]}=e,x=`${t}_entry_ids`,y=(await new Promise(w=>chrome.storage.local.get([x],w)))[x]??[],I=new Set(p.map(String)),oe=y.filter(w=>!I.has(String(w)));if(oe.length>0){const{error:w}=await b.from("extension_entries").delete().eq("user_id",r).in("entry_id",oe);if(w)throw w}if(c.length>0){const w=c.map(Se=>ie(r,Se)),{error:se}=await b.from("extension_entries").upsert(w,{onConflict:"user_id,entry_id"});if(se)throw se}const Y=p.length;return await new Promise(w=>chrome.storage.local.set({lastSync:Date.now(),entryCount:Y,[`${t}_entry_ids`]:p.map(String),[`${t}_lastSync`]:Date.now(),[`${t}_entryCount`]:Y},()=>w())),{count:Y}}const s=e;if(t){const c=`${t}_entry_ids`,x=(await new Promise(g=>chrome.storage.local.get([c],g)))[c]??[];if(x.length>0){const{error:g}=await b.from("extension_entries").delete().eq("user_id",r).in("entry_id",x);if(g)throw g}else if(t==="underdog"){const{error:g}=await b.from("extension_entries").delete().eq("user_id",r);if(g)throw g}}else{const{error:c}=await b.from("extension_entries").delete().eq("user_id",r);if(c)throw c}if(s.length===0){const c={lastSync:Date.now(),entryCount:0};return t&&(c[`${t}_lastSync`]=Date.now(),c[`${t}_entryCount`]=0),await new Promise(p=>chrome.storage.local.set(c,()=>p())),{count:0}}const l=s.map(c=>ie(r,c)),{error:i,count:a}=await b.from("extension_entries").upsert(l,{onConflict:"user_id,entry_id",count:"exact"});if(i)throw i;const d={lastSync:Date.now(),entryCount:s.length};return t&&(d[`${t}_entry_ids`]=s.map(c=>c.entryId),d[`${t}_lastSync`]=Date.now(),d[`${t}_entryCount`]=s.length),await new Promise(c=>chrome.storage.local.set(d,()=>c())),{count:a??s.length}}const Re=/\s+(jr\.?|sr\.?|ii|iii|iv|v)\s*$/i;function N(e=""){return String(e).trim().replace(/^"|"$/g,"").replace(Re,"").replace(/\./g,"").replace(/\s+/g," ").trim().toLowerCase()}const K="data-bbm-injected",pe="data-bbm-player-id",z="data-bbm-headers-injected";let u=null,f=null,D=null,h=!0,q=null,V=window.location.href,F=!1,v=new Map,k=new Map,A=new Map,T=new Map,$=0,_=[],L=null,R=null,X=new Map,Z=new Set,B=null,C="idle",ee=null,te=null,E=[],O=[],m=new Set,j=new Set;const ae=["S","A+","A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"],$e={S:"#ffd700","A+":"#ef4444",A:"#f87171","A-":"#fb923c","B+":"#f59e0b",B:"#eab308","B-":"#a3e635","C+":"#10b981",C:"#06b6d4","C-":"#3b82f6","D+":"#6366f1",D:"#8b5cf6","D-":"#a855f7",F:"#6b7280"};function me(e){const t=Math.max(0,Math.min(e-1,ae.length-1));return ae[t]}function Pe(e){return $e[me(e)]||"#555"}function ze(e){const t=(e==null?void 0:e.message)??"";return t.includes("Not authenticated")||t.includes("JWT")?"Session expired — sign in again":t.includes("fetch")||t.includes("network")||t.includes("NetworkError")?"Connection lost — tap to retry":"Load failed — tap to retry"}function J(e){const t=Math.floor((Date.now()-e)/1e3);return t<60?"just now":t<3600?`${Math.floor(t/60)}m ago`:t<86400?`${Math.floor(t/3600)}h ago`:`${Math.floor(t/86400)}d ago`}async function G(){const e=document.querySelector(".bbm-status-dot"),t=document.querySelector(".bbm-status-label"),n=document.querySelector(".bbm-panel-sync-line");if(!e||!t||!n)return;const r=await be();let o,s;r?C==="loading"?(o="#6B7280",s="Loading portfolio…"):C==="error"?(o="#EF4444",s=ee??"Load failed — tap to retry"):(o="#10B981",s="Connected"):(o="#F59E0B",s="Not signed in"),e.style.background=o,t.textContent=s;const l=document.querySelector(".bbm-panel-status");if(l&&(l.style.cursor=C==="error"?"pointer":"default"),C==="loading"){n.textContent="Fetching entries…";return}if(!r){n.textContent="—";return}chrome.storage.local.get(["lastSync","entryCount","underdog_lastSync","underdog_entryCount","draftkings_lastSync","draftkings_entryCount"],i=>{const a=[];i.underdog_lastSync&&a.push(`UD: ${i.underdog_entryCount??0} · ${J(i.underdog_lastSync)}`),i.draftkings_lastSync&&a.push(`DK: ${i.draftkings_entryCount??0} · ${J(i.draftkings_lastSync)}`),a.length>0?n.textContent=a.join("  |  "):i.lastSync?n.textContent=`${i.entryCount??0} entries · synced ${J(i.lastSync)}`:n.textContent="Not yet synced"})}function ne(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function De(e){return String(e??"").replace(/\b\w/g,t=>t.toUpperCase())}function fe(){const e=document.getElementById("bbm-tournament-filter");if(e){if(E.length===0){e.style.display="none";return}e.style.display="block",e.innerHTML=E.map((t,n)=>{const r=j.has(t.slate);return`
      <div class="bbm-filter-slate-group${r?" bbm-expanded":""}" data-si="${n}">
        <div class="bbm-filter-slate-row">
          <label class="bbm-filter-slate-label-wrap">
            <input type="checkbox" class="bbm-filter-check bbm-filter-slate-check" data-si="${n}" />
            <span class="bbm-filter-slate-label">${ne(t.slate)}</span>
          </label>
          <button type="button" class="bbm-filter-expand" data-si="${n}">${r?"▼":"▶"}</button>
        </div>
        <div class="bbm-filter-tournaments">
          ${t.tournaments.map((o,s)=>`
            <label class="bbm-filter-tournament-row">
              <input type="checkbox" class="bbm-filter-check bbm-filter-tournament-check"
                data-si="${n}" data-ti="${s}"
                ${m.has(o)?"checked":""} />
              <span class="bbm-filter-tournament-label">${ne(o)}</span>
            </label>
          `).join("")}
        </div>
      </div>
    `}).join(""),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{const{tournaments:n}=E[parseInt(t.dataset.si)],r=n.filter(o=>m.has(o)).length;t.checked=r===n.length,t.indeterminate=r>0&&r<n.length}),e.querySelectorAll(".bbm-filter-expand").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const r=E[parseInt(t.dataset.si)];j.has(r.slate)?j.delete(r.slate):j.add(r.slate),fe()})}),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{t.addEventListener("change",()=>{const{tournaments:n}=E[parseInt(t.dataset.si)];n.every(o=>m.has(o))?n.forEach(o=>m.delete(o)):n.forEach(o=>m.add(o)),chrome.storage.local.set({tournamentFilter:[...m]}),re()})}),e.querySelectorAll(".bbm-filter-tournament-check").forEach(t=>{t.addEventListener("change",()=>{const n=E[parseInt(t.dataset.si)].tournaments[parseInt(t.dataset.ti)];t.checked?m.add(n):m.delete(n),chrome.storage.local.set({tournamentFilter:[...m]}),re()})})}}function re(){var t,n,r,o;const e=m.size===0?O:O.filter(s=>m.has(s.tournamentTitle));$=e.length,v=new Map,k=new Map,A=new Map,T=new Map,e.forEach((s,l)=>{(s.players??[]).forEach(i=>{if(!i.name)return;const a=N(i.name);a&&(v.has(a)||v.set(a,new Set),v.get(a).add(l),i.team&&!k.has(a)&&k.set(a,i.team),i.position&&!A.has(a)&&A.set(a,i.position))})});for(const s of v.keys()){const l=s.split(/\s+/);if(l.length<2)continue;const i=l[0][0],a=l.slice(1).join(" "),d=`${i} ${a}`;if(T.has(d)){const c=T.get(d),p={fullName:s,position:((t=A.get(s))==null?void 0:t.toUpperCase())??null,team:((n=k.get(s))==null?void 0:n.toUpperCase())??null};typeof c=="string"?T.set(d,[{fullName:c,position:((r=A.get(c))==null?void 0:r.toUpperCase())??null,team:((o=k.get(c))==null?void 0:o.toUpperCase())??null},p]):Array.isArray(c)&&c.push(p)}else T.set(d,s)}fe(),S()}async function Q(){const e=document.getElementById("bbm-auth-section");if(!e)return;const t=await be();if(t){const n=await _e(),r=n?`<span class="bbm-auth-tier ${n}">${n==="pro"?"Pro":"Free"}</span>`:"";e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <div class="bbm-auth-user">${ne(t.user.email)}</div>
        ${r}
        <button id="bbm-sign-out-btn" class="bbm-btn bbm-btn-secondary">Sign Out</button>
      </div>
      <button id="bbm-sync-btn" class="bbm-btn" style="margin-top:6px">Sync Now</button>
      <div id="bbm-sync-progress" class="bbm-sync-progress bbm-progress-indeterminate" style="display:none">
        <div class="bbm-progress-label">Discovering entries…</div>
        <div class="bbm-progress-bar-wrap"><div class="bbm-progress-bar-fill"></div></div>
      </div>
      <div id="bbm-sync-result" class="bbm-sync-result" style="display:none"></div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",le),e.querySelector("#bbm-sync-btn").addEventListener("click",Oe),e.querySelector("#bbm-sign-out-btn").addEventListener("click",Ne)}else{e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <button id="bbm-google-btn" class="bbm-btn bbm-btn-google">
          <svg width="16" height="16" viewBox="0 0 48 48" style="flex-shrink:0"><path fill="#4285F4" d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z"/><path fill="#34A853" d="M6.3 14.7l7 5.1C15 15.6 19.1 12 24 12c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 16.3 2 9.7 7.3 6.3 14.7z"/><path fill="#FBBC05" d="M24 46c5.4 0 10.3-1.8 14.1-5l-6.9-5.7C29.1 37 26.7 38 24 38c-6 0-10.6-3.9-12.3-9.2l-7 5.4C8.1 41 15.4 46 24 46z"/><path fill="#EA4335" d="M46 24c0-1.3-.2-2.7-.5-4H24v8.5h11.8c-1 3-3 5.4-5.8 7l6.9 5.7C41 37.5 46 31.5 46 24z"/></svg>
          Sign in with Google
        </button>
        <div class="bbm-auth-divider"><span>or</span></div>
        <input type="email" id="bbm-auth-email" class="bbm-auth-input" placeholder="Email" autocomplete="email" />
        <input type="password" id="bbm-auth-password" class="bbm-auth-input" placeholder="Password" autocomplete="current-password" />
        <button id="bbm-sign-in-btn" class="bbm-btn">Sign In</button>
        <div id="bbm-auth-error" class="bbm-auth-error" style="display:none"></div>
      </div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",le),e.querySelector("#bbm-google-btn").addEventListener("click",Fe),e.querySelector("#bbm-sign-in-btn").addEventListener("click",ce);for(const n of e.querySelectorAll(".bbm-auth-input"))for(const r of["keydown","keypress","keyup"])n.addEventListener(r,o=>o.stopPropagation());e.querySelector("#bbm-auth-password").addEventListener("keydown",n=>{n.key==="Enter"&&ce()})}}function le(){const e=document.getElementById("bbm-account-body"),t=document.querySelector(".bbm-account-chevron");if(!e)return;const n=e.style.display!=="none";e.style.display=n?"none":"block",t&&(t.style.transform=n?"":"rotate(180deg)")}async function Fe(){const e=document.getElementById("bbm-google-btn"),t=document.getElementById("bbm-auth-error");if(e){e.disabled=!0,t&&(t.style.display="none");try{await Be(),await Q(),P()}catch(n){t&&(t.textContent=n.message??"Google sign-in failed",t.style.display="block"),e&&(e.disabled=!1)}}}async function ce(){var o,s;const e=(o=document.getElementById("bbm-auth-email"))==null?void 0:o.value.trim(),t=(s=document.getElementById("bbm-auth-password"))==null?void 0:s.value,n=document.getElementById("bbm-sign-in-btn"),r=document.getElementById("bbm-auth-error");if(!(!e||!t||!n)){n.disabled=!0,r&&(r.style.display="none");try{await Ce(e,t),await Q(),P()}catch(l){r&&(r.textContent=l.message??"Sign in failed",r.style.display="block"),n&&(n.disabled=!1)}}}async function Ne(){await Ae(),v=new Map,k=new Map,A=new Map,$=0,O=[],E=[],S(),await Q(),G()}async function Oe(){const e=document.getElementById("bbm-sync-btn"),t=document.getElementById("bbm-sync-result"),n=document.getElementById("bbm-sync-progress");if(!e)return;if(e.disabled=!0,t&&(t.style.display="none",t.className="bbm-sync-result"),n&&(n.style.display="none"),!te){t&&(t.textContent=u.syncPageErrorMessage,t.classList.add("error"),t.style.display="block"),e.disabled=!1;return}const r=n==null?void 0:n.querySelector(".bbm-progress-label"),o=n==null?void 0:n.querySelector(".bbm-progress-bar-fill");function s(l){var c;if(l.source!==window||((c=l.data)==null?void 0:c.type)!=="BBM_SYNC_PROGRESS")return;const{phase:i,done:a,total:d}=l.data;if(n){if(n.style.display="block",i==="discovery")n.classList.add("bbm-progress-indeterminate"),r&&(r.textContent="Discovering entries…"),o&&(o.style.width="0%");else if(i==="fetching"){n.classList.remove("bbm-progress-indeterminate");const p=d>0?Math.round(a/d*100):0;r&&(r.textContent=`Processing ${a} / ${d} entries…`),o&&(o.style.width=p+"%")}}}window.addEventListener("message",s);try{const{count:l}=await te();t&&(t.textContent=`Synced ${l} entries`,t.style.display="block"),P()}catch(l){if(t){const i=l.message??"Sync failed";t.textContent=i.includes("Could not establish connection")?u.syncPageErrorMessage:i,t.classList.add("error"),t.style.display="block"}}finally{window.removeEventListener("message",s),n&&(n.style.display="none"),e&&(e.disabled=!1)}}async function P(){C="loading",G();try{O=await Ie();const e=new Map;O.forEach(r=>{if(!r.tournamentTitle)return;const o=r.slateTitle||"Other";e.has(o)||e.set(o,new Set),e.get(o).add(r.tournamentTitle)}),E=[...e.entries()].sort(([r],[o])=>r.localeCompare(o)).map(([r,o])=>({slate:r,tournaments:[...o].sort()}));const t=new Set(E.flatMap(r=>r.tournaments)),n=m.size;m=new Set([...m].filter(r=>t.has(r))),m.size===0&&t.forEach(r=>m.add(r)),m.size!==n&&chrome.storage.local.set({tournamentFilter:[...m]}),re(),C="ready",ee=null}catch(e){C="error",ee=ze(e),console.warn("[BBM] Could not load portfolio data:",e.message)}finally{G()}}async function He(){try{const e=await qe();if(!e)return;X=new Map(e.map(t=>[t.name,{rank:t.rank,tierNum:t.tierNum}])),Z=new Set;for(let t=1;t<e.length;t++)e[t].tierNum!==e[t-1].tierNum&&Z.add(e[t].rank);S()}catch(e){console.warn("[BBM] Could not load rankings data:",e.message)}}function ge(){let e;if(u.getCurrentPicks){const n=u.getCurrentPicks();if(!n)return;e=n.map(r=>({name:M(r.name,{position:r.position,team:r.team})??r.name,position:r.position,round:r.round}))}else e=[],document.querySelectorAll(u.selectors.myPicksSelector).forEach((r,o)=>{var d,c,p;const s=r.querySelector(u.selectors.playerNameInRowSelector),l=r.closest(u.selectors.positionSectionSelector),i=((c=(d=l==null?void 0:l.querySelector(u.selectors.positionHeaderSelector))==null?void 0:d.textContent)==null?void 0:c.trim())??"",a=(p=s==null?void 0:s.textContent)==null?void 0:p.trim();a&&e.push({name:a,position:i,round:o+1})});(e.length!==_.length||e.some((n,r)=>{var o;return n.name!==((o=_[r])==null?void 0:o.name)}))&&(_=e,S())}function je(){R||(R=requestAnimationFrame(()=>{R=null,ge()}))}function Ue(){L||(L=new MutationObserver(je),L.observe(document.body,{childList:!0,subtree:!0}),ge())}function Ke(){R&&(cancelAnimationFrame(R),R=null),L&&(L.disconnect(),L=null),_=[]}function ye(e){var n;const t=e.querySelector(u.selectors.playerNameInRowSelector);return((n=t==null?void 0:t.textContent)==null?void 0:n.trim())??null}function M(e,t){if(!e)return null;const n=N(e);if(v.has(n))return n;const r=N(e),o=T.get(r);if(typeof o=="string")return o;if(Array.isArray(o)&&t){const s=t instanceof Element&&u.getPlayerContext?u.getPlayerContext(t):t;let l=o;if(s.position){const i=s.position.toUpperCase(),a=l.filter(d=>d.position===i);if(a.length===1)return a[0].fullName;a.length>1&&(l=a)}if(s.team){const i=s.team.toUpperCase(),a=l.filter(d=>d.team===i);if(a.length===1)return a[0].fullName}}return null}function he(e){if($===0)return 0;const t=M(e);if(!t)return 0;const n=v.get(t);return n?n.size/$*100:0}function xe(e){const t=M(e),n=(t&&v.get(t))??new Set,r=[];let o=0,s=0;return _.forEach(l=>{const i=v.get(N(l.name))??new Set;if(i.size===0)return;let a=0;i.size<n.size?i.forEach(c=>{n.has(c)&&a++}):n.forEach(c=>{i.has(c)&&a++});const d=a/i.size;o+=d,s++,r.push({name:l.name,position:l.position,round:l.round,pct:Math.round(d*100)})}),{score:s>0?Math.round(o/s*100):0,breakdown:r}}function Ge(e){const t=e.querySelector(".bbm-stat-cell:not(.bbm-corr-trigger)"),n=e.querySelector(".bbm-corr-trigger");if(!t||!n)return;const r=ye(e);if(!r||$===0)return;const o=M(r,e)??r,s=he(o);t.textContent=`${Math.round(s)}%`;const l=n.querySelector(".bbm-corr-value"),i=n.querySelector(".bbm-corr-popup");if(!l||!i)return;const{score:a,breakdown:d}=xe(o);l.textContent=`${a}%`,we(i,d),ve(e,o),Ee(e,o)}function we(e,t){if(t.length===0){e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No picks yet</div>';return}e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div>'+t.map(n=>`<div class="bbm-corr-popup-row">
          <span class="bbm-corr-popup-pos">${n.position}</span>
          <span class="bbm-corr-popup-name">${De(n.name)}</span>
          <div class="bbm-corr-popup-bar">
            <div class="bbm-corr-popup-bar-fill" style="width:${n.pct}%;background:#3b82f6"></div>
          </div>
          <span class="bbm-corr-popup-pct">${n.pct}%</span>
        </div>`).join("")}function ve(e,t){e.querySelectorAll(".bbm-stack-pill").forEach(s=>s.remove());const n=We(t);if(!n)return;const r=e.querySelector(u.selectors.stackPillTargetSelector);if(!r)return;const o=document.createElement("span");o.className="bbm-stack-pill bbm-inline-overlay",o.textContent=n.type,o.style.color=n.color,o.style.borderColor=n.color,o.style.background=`${n.color}1A`,r.appendChild(o)}function We(e){const t=M(e);if(!t)return null;const n=k.get(t),r=A.get(t);if(!n||!r||_.length===0)return null;const o=_.filter(d=>{const c=k.get(N(d.name));return c&&c===n});if(o.length===0)return null;const s=o.filter(d=>d.position==="QB"),l=o.filter(d=>d.position==="WR"),i=o.filter(d=>d.position==="TE"),a=o.filter(d=>d.position==="RB");return r==="QB"&&(l.length>0||i.length>0||a.length>0)?{type:l.length+i.length+a.length>=2?"QB MULTI":"QB STACK",color:"#BF44EF"}:(r==="WR"||r==="TE"||r==="RB")&&s.length>0?{type:l.length+i.length+a.length>=1?"QB MULTI":"QB STACK",color:"#BF44EF"}:r==="WR"&&l.length>=1?{type:`WR ×${l.length+1}`,color:"#F59E0B"}:r==="TE"&&i.length>=1?{type:`TE ×${i.length+1}`,color:"#3B82F6"}:r==="RB"&&a.length>=1?{type:`RB ×${a.length+1}`,color:"#10B981"}:r==="RB"&&(l.length>0||i.length>0)?{type:"TEAM",color:"#8A9BB5"}:(r==="WR"||r==="TE")&&a.length>0?{type:"TEAM",color:"#8A9BB5"}:null}function Qe(){const e=document.createElement("div");e.className="bbm-inline-overlay bbm-stat-cell",e.textContent="--%";const t=document.createElement("div");t.className="bbm-inline-overlay bbm-stat-cell bbm-corr-trigger";const n=document.createElement("span");n.className="bbm-corr-value",n.textContent="--";const r=document.createElement("div");return r.className="bbm-corr-popup",r.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No draft data yet</div>',t.appendChild(n),t.appendChild(r),t.addEventListener("mouseenter",()=>{Ye(),f.innerHTML=r.innerHTML;const o=t.getBoundingClientRect();f.style.left=`${Math.max(8,o.right-280)}px`,f.style.top=`${o.bottom+4}px`,f.style.display="block"}),t.addEventListener("mouseleave",()=>{f&&(f.style.display="none")}),[e,t]}function Ye(){f&&document.body.contains(f)||(f=document.createElement("div"),f.className="bbm-corr-popup",f.id="bbm-corr-popup-portal",f.style.cssText="display: none; position: fixed; z-index: 10001;",document.body.appendChild(f))}function Je(e){var d,c;const t=((d=u.getRowId)==null?void 0:d.call(u,e))??e.getAttribute("data-id");if(!t)return;if(e.getAttribute(K)===t){Ge(e);return}e.querySelectorAll(".bbm-inline-overlay").forEach(p=>p.remove()),e.querySelectorAll(".bbm-tier-badge").forEach(p=>p.remove()),e.removeAttribute("data-bbm-tier");const{parent:r,before:o}=((c=u.getInjectionPoint)==null?void 0:c.call(u,e))??{};if(!r)return;const[s,l]=Qe();o?(r.insertBefore(s,o),r.insertBefore(l,o)):r.append(s,l),u.postInjectRow&&u.postInjectRow(e,s,l),e.setAttribute(K,t),e.setAttribute(pe,t);const i=ye(e),a=M(i,e)??i;if($>0&&a){const p=he(a);s.textContent=`${Math.round(p)}%`;const{score:x,breakdown:g}=xe(a),y=l.querySelector(".bbm-corr-value"),I=l.querySelector(".bbm-corr-popup");y.textContent=`${x}%`,we(I,g)}a&&ve(e,a),Ee(e,a)}function Ee(e,t){if(e.querySelectorAll(".bbm-tier-badge").forEach(d=>d.remove()),e.removeAttribute("data-bbm-tier"),!u.isMyRankSort()||X.size===0||!t)return;const n=M(t),r=X.get(n??t.trim().toLowerCase());if(!r)return;const{tierNum:o,rank:s}=r;if(e.setAttribute("data-bbm-tier",String(o)),!Z.has(s))return;const l=Pe(o),i=me(o),a=document.createElement("div");a.className="bbm-tier-badge",a.style.color=l,a.innerHTML=`<span class="bbm-tier-pill">${i}</span>`,e.prepend(a)}function Ve(){const e=document.querySelector(u.selectors.sortButtonsSelector);if(!e||(B||(B=new MutationObserver(S),B.observe(e,{attributes:!0,subtree:!0})),e.hasAttribute(z)))return;if(u.injectHeaderCells){u.injectHeaderCells(e),e.setAttribute(z,"true");return}const t=document.querySelector(u.selectors.rowSelector);if(!t)return;const n=e.getBoundingClientRect(),r=t.querySelectorAll(".bbm-stat-cell");if(r.length<2)return;const o=r[0].getBoundingClientRect(),s=r[1].getBoundingClientRect(),l=n.right,i=l-o.right,a=l-s.right;e.style.position="relative";const d=document.createElement("span");d.className="bbm-header-label",d.textContent="Exp",d.style.right=`${i}px`,d.style.width=`${o.width}px`;const c=document.createElement("span");c.className="bbm-header-label",c.textContent="Corr",c.style.right=`${a}px`,c.style.width=`${s.width}px`,e.appendChild(d),e.appendChild(c),e.setAttribute(z,"true")}function Xe(){document.querySelectorAll(".bbm-header-label").forEach(e=>e.remove()),document.querySelectorAll(`[${z}]`).forEach(e=>{e.removeAttribute(z)})}function S(){q||(q=requestAnimationFrame(()=>{var t;if(q=null,!h)return;(((t=u.getPlayerRows)==null?void 0:t.call(u))??document.querySelectorAll(u.selectors.rowSelector)).forEach(Je),Ve()}))}function Ze(){document.querySelectorAll(".bbm-inline-overlay").forEach(e=>e.remove()),document.querySelectorAll(".bbm-tier-badge").forEach(e=>e.remove()),document.querySelectorAll("[data-bbm-tier]").forEach(e=>e.removeAttribute("data-bbm-tier")),document.querySelectorAll(`[${K}]`).forEach(e=>{e.removeAttribute(K),e.removeAttribute(pe)}),Xe(),f&&(f.remove(),f=null)}function et(){if(document.getElementById("bbm-overlay-styles"))return;const e=document.createElement("style");e.id="bbm-overlay-styles",e.textContent=`
    /* DK: allow overlay cells to overflow fixed-width rows (scoped to rows, not scroll container) */
    .BaseTable__row {
      overflow: visible !important;
    }

    .bbm-stat-cell {
      color: inherit;
      opacity: 0.6;
      font-family: inherit;
      font-size: 11px;
      white-space: nowrap;
      flex-shrink: 0;
      width: 40px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }
    .bbm-stat-cell + .bbm-stat-cell {
      margin-left: 12px;
    }

    /* Corr cell is hoverable */
    .bbm-corr-trigger {
      pointer-events: auto;
      cursor: default;
      position: relative;
    }
    .bbm-corr-trigger:hover {
      opacity: 1;
    }

    /* Correlation popup — hidden by default, shown via JS mouseenter/mouseleave */
    .bbm-corr-popup {
      display: none;
      background: var(--bg-primary, #1a1a2e);
      color: #E8E8E8;
      border: 1px solid var(--border-color, #333);
      border-radius: 8px;
      padding: 8px 0;
      z-index: 10001;
      min-width: 220px;
      max-width: 300px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      white-space: normal;
      text-align: left;
      opacity: 1;
    }
    .bbm-corr-popup-title {
      padding: 0 12px 6px;
      font-size: 10px;
      color: #E8E8E8;
      opacity: 0.5;
      text-transform: uppercase;
      font-weight: 700;
      letter-spacing: 0.05em;
    }
    .bbm-corr-popup-empty {
      padding: 4px 12px;
      font-size: 12px;
      color: #E8E8E8;
      opacity: 0.4;
      font-style: italic;
    }

    /* Rows for when real data is wired in */
    .bbm-corr-popup-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 12px;
    }
    .bbm-corr-popup-pos {
      font-size: 10px;
      font-weight: 900;
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 22px;
      text-align: center;
    }
    .bbm-corr-popup-name {
      font-size: 12px;
      font-weight: 600;
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-corr-popup-bar {
      width: 40px;
      height: 5px;
      background: rgba(128, 128, 128, 0.3);
      border-radius: 3px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .bbm-corr-popup-bar-fill {
      height: 100%;
      border-radius: 3px;
    }
    .bbm-corr-popup-pct {
      font-size: 11px;
      font-weight: 700;
      font-family: monospace;
      min-width: 28px;
      text-align: right;
    }

    /* Stack pill — inline after player name, only visible when stacking */
    .bbm-stack-pill {
      display: inline-block;
      vertical-align: middle;
      margin-left: 6px;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid;
      line-height: 1.5;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0.85;
    }

    /* Tier break — full-width divider with centered pill label */
    .bbm-tier-badge {
      position: absolute;
      left: 0;
      right: 0;
      top: -7px;
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: none;
      z-index: 0;
      padding: 0 10px;
    }
    .bbm-tier-badge::before,
    .bbm-tier-badge::after {
      content: '';
      flex: 1;
      height: 1px;
      background: currentColor;
      opacity: 0.35;
    }
    .bbm-tier-pill {
      font-size: 8px;
      font-weight: 800;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      padding: 2px 6px;
      border-radius: 3px;
      background: #0C1A30;
      border: 1px solid currentColor;
      color: inherit;
      white-space: nowrap;
      line-height: 1.5;
      flex-shrink: 0;
    }

    .bbm-header-label {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      color: inherit;
      opacity: 0.5;
      font-family: inherit;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }

    /* Auth section (TASK-129) */
    #bbm-auth-section { margin: 6px 0; }

    .bbm-account-toggle {
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 3px 0;
      user-select: none;
    }
    .bbm-account-toggle-label {
      font-size: 10px;
      color: #8A9BB5;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .bbm-account-chevron {
      font-size: 9px;
      color: #5a6a80;
      transition: transform 0.15s;
      line-height: 1;
    }
    .bbm-account-body { padding-top: 6px; }

    .bbm-auth-input {
      width: 100%;
      background: #0F2040;
      border: 1px solid #243A5C;
      border-radius: 4px;
      color: #E8E8E8;
      font-size: 11px;
      padding: 5px 7px;
      margin-bottom: 4px;
      box-sizing: border-box;
      outline: none;
    }
    .bbm-auth-input:focus { border-color: #E8BF4A; }

    .bbm-btn {
      width: 100%;
      background: #E8BF4A;
      color: #0C1A30;
      border: none;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      padding: 5px 0;
      cursor: pointer;
      margin-bottom: 4px;
    }
    .bbm-btn:hover { background: #F0CC5B; }
    .bbm-btn:disabled { opacity: 0.5; cursor: default; }

    .bbm-btn-secondary {
      background: transparent;
      color: #8A9BB5;
      border: 1px solid #243A5C;
    }
    .bbm-btn-secondary:hover { color: #E8E8E8; border-color: #8A9BB5; }

    .bbm-btn-google {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: #fff;
      color: #3c4043;
      font-weight: 600;
    }
    .bbm-btn-google:hover { background: #f1f3f4; }

    .bbm-auth-divider {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 6px 0;
      font-size: 9px;
      color: #5A6E8A;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .bbm-auth-divider::before,
    .bbm-auth-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #243A5C;
    }

    .bbm-auth-user {
      font-size: 11px;
      color: #C0CCE0;
      margin-bottom: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-auth-tier {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 6px;
      background: #1C3A5E;
      color: #8A9BB5;
    }
    .bbm-auth-tier.pro { background: #2A3A10; color: #A3C447; }

    .bbm-auth-error {
      font-size: 10px;
      color: #EF4444;
      margin-top: 2px;
    }
    .bbm-sync-result {
      font-size: 10px;
      color: #10B981;
      margin-bottom: 4px;
    }
    .bbm-sync-result.error { color: #EF4444; }

    .bbm-sync-progress { margin-bottom: 6px; }
    .bbm-progress-label {
      font-size: 10px;
      color: #8A9BB5;
      margin-bottom: 3px;
    }
    .bbm-progress-bar-wrap {
      width: 100%;
      height: 4px;
      background: #1a2d50;
      border-radius: 2px;
      overflow: hidden;
    }
    .bbm-progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #D4A843, #F0CC5B);
      border-radius: 2px;
      transition: width 0.2s ease;
    }
    @keyframes bbm-shimmer {
      0%   { transform: translateX(-100%); }
      100% { transform: translateX(400%); }
    }
    .bbm-progress-indeterminate .bbm-progress-bar-fill {
      width: 25%;
      animation: bbm-shimmer 1.4s ease-in-out infinite;
    }

    /* FAB — brand logo button, bottom-left. Whispers at rest, speaks on hover. */
    #bbm-fab {
      position: fixed;
      bottom: 14px;
      left: 14px;
      z-index: 10000;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      opacity: 0.3;
      transition: opacity 120ms ease, filter 120ms ease;
    }
    #bbm-fab:hover {
      opacity: 1;
      filter: drop-shadow(0 0 8px rgba(232, 191, 74, 0.5));
    }

    /* Configuration panel — compact, only visible on demand */
    #bbm-panel {
      display: none;
      position: fixed;
      bottom: 50px;
      left: 14px;
      z-index: 10000;
      background: #0C1A30;
      border: 1px solid #243A5C;
      border-radius: 8px;
      padding: 10px 14px;
      min-width: 210px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
      font-size: 12px;
      color: #E8E8E8;
    }
    #bbm-panel.open {
      display: block;
    }
    .bbm-panel-title {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8A9BB5;
      margin-bottom: 8px;
    }
    .bbm-panel-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .bbm-panel-label {
      font-size: 12px;
      font-weight: 600;
      color: #E8E8E8;
    }
    #bbm-overlay-toggle {
      cursor: pointer;
      width: 14px;
      height: 14px;
      accent-color: #E8BF4A;
    }

    /* Confidence panel — status and sync lines (TASK-106) */
    .bbm-panel-divider {
      border: none;
      border-top: 1px solid #243A5C;
      margin: 8px 0;
    }
    .bbm-panel-status {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
    }
    .bbm-status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #6B7280;
    }
    .bbm-status-label {
      font-size: 11px;
      color: #C0CCE0;
    }
    .bbm-panel-sync-line {
      font-size: 10px;
      color: #8A9BB5;
      margin-top: 3px;
      padding-left: 12px;
    }

    /* Tournament filter (TASK-107) — hierarchical: slate → tournament */
    .bbm-filter-title {
      margin-top: 6px;
      margin-bottom: 4px;
    }
    #bbm-tournament-filter {
      max-height: 140px;
      overflow-y: auto;
    }
    .bbm-filter-check {
      cursor: pointer;
      accent-color: #E8BF4A;
      flex-shrink: 0;
      width: 12px;
      height: 12px;
    }
    .bbm-filter-slate-group {
      border-bottom: 1px solid #1E3054;
    }
    .bbm-filter-slate-group:last-child {
      border-bottom: none;
    }
    .bbm-filter-slate-row {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 3px 0;
    }
    .bbm-filter-slate-label-wrap {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 1;
      cursor: pointer;
      min-width: 0;
    }
    .bbm-filter-slate-label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #8A9BB5;
    }
    .bbm-filter-expand {
      background: none;
      border: none;
      color: #8A9BB5;
      font-size: 7px;
      padding: 0 2px;
      cursor: pointer;
      flex-shrink: 0;
      line-height: 1;
    }
    .bbm-filter-tournaments {
      display: none;
    }
    .bbm-filter-slate-group.bbm-expanded .bbm-filter-tournaments {
      display: block;
    }
    .bbm-filter-tournament-row {
      display: flex;
      align-items: center;
      gap: 5px;
      padding: 2px 0 2px 14px;
      cursor: pointer;
    }
    .bbm-filter-tournament-label {
      font-size: 11px;
      color: #C0CCE0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `,document.head.appendChild(e)}function H(){if(D)return;P(),He(),Ue(),D=ue({targetSelector:u.selectors.gridSelector,onMutation:S,onReconnect:()=>{S()}});const e=document.querySelector(u.selectors.sortButtonsSelector);e&&(B=new MutationObserver(S),B.observe(e,{attributes:!0,subtree:!0})),S()}function W(){D&&(D.disconnect(),D=null),B&&(B.disconnect(),B=null),q&&(cancelAnimationFrame(q),q=null),Ke(),Ze()}function tt(){if(document.getElementById("bbm-fab"))return;const e=document.createElement("button");e.id="bbm-fab",e.title="Best Ball Exposures",e.innerHTML=`<svg width="36" height="36" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Best Ball Exposures">
    <defs>
      <linearGradient id="bb-gold" x1="10" y1="10" x2="38" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%"   stop-color="#F0CC5B"/>
        <stop offset="50%"  stop-color="#D4A843"/>
        <stop offset="100%" stop-color="#E8BF4A"/>
      </linearGradient>
      <linearGradient id="bb-bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#0C1A30"/>
        <stop offset="100%" stop-color="#060E1F"/>
      </linearGradient>
    </defs>
    <circle cx="24" cy="24" r="24" fill="url(#bb-bg)"/>
    <circle cx="24" cy="24" r="22.5" fill="none" stroke="url(#bb-gold)" stroke-width="2"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="#E8BF4A" stroke-width="0.5" opacity="0.18"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="url(#bb-gold)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="18 7 10 7 23 7 8 7.96" transform="rotate(-90 24 24)"/>
    <circle cx="24" cy="24" r="2.5" fill="url(#bb-gold)"/>
  </svg>`;const t=document.createElement("div");t.id="bbm-panel",t.innerHTML=`
    <div class="bbm-panel-title">Best Ball Exposures</div>
    <div id="bbm-auth-section"></div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-row">
      <label class="bbm-panel-label" for="bbm-overlay-toggle">Overlay</label>
      <input type="checkbox" id="bbm-overlay-toggle" />
    </div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-status">
      <span class="bbm-status-dot"></span>
      <span class="bbm-status-label">—</span>
    </div>
    <div class="bbm-panel-sync-line">—</div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-title bbm-filter-title">Tournament Filter</div>
    <div id="bbm-tournament-filter" style="display:none"></div>
  `;const n=t.querySelector("#bbm-overlay-toggle");n.checked=h,t.querySelector(".bbm-panel-status").addEventListener("click",()=>{C==="error"&&P()}),t.addEventListener("click",o=>o.stopPropagation()),e.addEventListener("click",o=>{o.stopPropagation(),t.classList.toggle("open"),t.classList.contains("open")&&(Q(),G())}),n.addEventListener("change",()=>{h=n.checked,chrome.storage.local.set({overlayEnabled:h}),h?H():W()}),document.body.appendChild(e),document.body.appendChild(t)}function de(){const e=window.location.href;if(e===V)return;const t=F;V=e,F=u.isDraftPage();const n=F;!t&&n?h&&H():t&&!n?W():t&&n&&(W(),h&&H())}function nt(){setInterval(()=>{window.location.href!==V&&de()},300),window.addEventListener("popstate",de)}function rt(e,t=null){u=e,te=t,chrome.storage.local.get(["overlayEnabled","tournamentFilter"],n=>{h=n.overlayEnabled!==!1,m=new Set(n.tournamentFilter??[]),F=u.isDraftPage(),et(),tt(),nt(),F&&h?H():P(),document.addEventListener("click",()=>{var r;(r=document.getElementById("bbm-panel"))==null||r.classList.remove("open")}),document.addEventListener("keydown",r=>{var o;r.key==="Escape"&&((o=document.getElementById("bbm-panel"))==null||o.classList.remove("open"))})}),chrome.runtime.onMessage.addListener(n=>{if(n.type!=="TOGGLE_OVERLAY")return;h=n.enabled;const r=document.getElementById("bbm-overlay-toggle");r&&(r.checked=h),h?u.isDraftPage()&&H():W()})}const U=ke(window.location.href);if(U){document.querySelector("#root, #app, [data-reactroot]")&&ue({targetSelector:"#root, #app, [data-reactroot]",onMutation:()=>{},onReconnect:()=>{}});async function t(){const n=await Me(),r=await U.getEntries(n);return Le(r,{platform:U.platform})}rt(U,t),chrome.runtime.onMessage.addListener((n,r,o)=>n.type!=="SYNC_ENTRIES"?!1:(t().then(({count:s})=>o({ok:!0,count:s})).catch(s=>o({ok:!1,error:s.message})),!0))}
