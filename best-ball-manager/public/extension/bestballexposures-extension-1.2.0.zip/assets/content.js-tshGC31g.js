import{s as b,g as Ne}from"./supabase-DUw217z8.js";function ge({targetSelector:e,onMutation:t,onReconnect:n,pollInterval:r=500,maxRetries:o=20}){let i=null,l=null,s=null,a=!1;const c={childList:!0,subtree:!0};function d(h){i&&i.disconnect(),i=new MutationObserver(t),i.observe(h,c),l=h}function p(){s&&clearInterval(s);let h=0;s=setInterval(()=>{if(a){clearInterval(s);return}const S=document.querySelector(e);S?(clearInterval(s),s=null,d(S),n==null||n()):++h>=o&&(clearInterval(s),s=null)},r)}const m=new MutationObserver(()=>{if(a)return;const h=document.querySelector(e);!h&&i?(i.disconnect(),i=null,l=null,p()):h&&i&&h!==l&&(d(h),n==null||n())}),f=document.querySelector(e);return f?d(f):p(),m.observe(document.body,{childList:!0,subtree:!0}),{disconnect(){a=!0,s&&clearInterval(s),i&&i.disconnect(),m.disconnect()}}}async function ye(){if(!b)return null;const{data:{session:e}}=await b.auth.getSession();return e}async function De(e,t){if(!b)throw new Error("[BBM] Supabase not configured");const{data:n,error:r}=await b.auth.signInWithPassword({email:e,password:t});if(r)throw r;return n.session}async function $e(){if(!b)throw new Error("[BBM] Supabase not configured");const e=await new Promise(r=>{chrome.runtime.sendMessage({type:"GOOGLE_OAUTH"},r)});if(e.error)throw new Error(e.error);const{data:t,error:n}=await b.auth.setSession({access_token:e.access_token,refresh_token:e.refresh_token});if(n)throw n;return t.session}async function Fe(){b&&await b.auth.signOut()}async function he(){var e,t,n,r;try{if(!b)return null;const{data:{session:o}}=await b.auth.getSession();if(!o)return null;const i=o.user.id,[l,s]=await Promise.all([b.from("subscriptions").select("status").eq("user_id",i).in("status",["active","trialing"]).limit(1).maybeSingle(),b.from("profiles").select("beta_expires_at, comp_expires_at").eq("id",i).maybeSingle()]),a=((e=l.data)==null?void 0:e.status)==="active"||((t=l.data)==null?void 0:t.status)==="trialing",c=new Date,d=(n=s.data)==null?void 0:n.beta_expires_at,p=(r=s.data)==null?void 0:r.comp_expires_at,m=d?new Date(d)>c:!1,f=p?new Date(p)>c:!1;return a||m||f?"pro":"free"}catch{return null}}async function qe(){if(!b)return[];const{data:{session:e}}=await b.auth.getSession();if(!e)return[];const{data:t,error:n}=await b.from("extension_entries").select("entry_id").eq("user_id",e.user.id);return n?[]:(t??[]).map(r=>r.entry_id)}async function ze(e){if(!b||!Array.isArray(e)||e.length===0)return new Set;const{data:{session:t}}=await b.auth.getSession();if(!t)return new Set;const{data:n,error:r}=await b.from("draft_boards_admin").select("draft_id, first_pick_name:picks->0->>name").in("draft_id",e.map(String));return r?new Set:new Set((n??[]).filter(o=>o.first_pick_name!=null).map(o=>String(o.draft_id)))}async function Oe(){if(!b)throw new Error("[BBM] Supabase not configured");const{data:{session:e}}=await b.auth.getSession();if(!e)throw new Error("[BBM] Not authenticated");const{data:t,error:n}=await b.from("extension_entries").select("entry_id, tournament, slate_title, draft_date, players").eq("user_id",e.user.id);if(n)throw n;return(t??[]).map(r=>({entryId:r.entry_id,tournamentTitle:r.tournament,slateTitle:He(r.slate_title??"",r.tournament),draftDate:r.draft_date,players:r.players??[]}))}function He(e,t){return!e||!e.startsWith("DK")?e:(t||"").toLowerCase().includes("early bird")?"DK Pre-Draft":"DK Post-Draft"}async function Ue(){if(!b)return null;const{data:{session:e}}=await b.auth.getSession();if(!e)return null;const{data:t,error:n}=await b.from("user_rankings").select("rankings").eq("user_id",e.user.id).maybeSingle();return n||!t?null:t.rankings??null}function ce(e,t){return{user_id:e,entry_id:t.entryId,tournament:t.tournamentTitle??null,slate_title:t.slateTitle??null,draft_date:t.draftDate??null,players:t.players??[],synced_at:new Date().toISOString()}}async function We(e,{platform:t}={}){if(!b)throw new Error("[BBM] Supabase not configured");const{data:{session:n}}=await b.auth.getSession();if(!n)throw new Error("[BBM] Not authenticated");const r=n.user.id;if(!Array.isArray(e)){if(!t)throw new Error("[BBM] Incremental writeEntries requires platform");const{newEntries:d=[],currentDraftIds:p=[]}=e,m=`${t}_entry_ids`,h=(await new Promise(v=>chrome.storage.local.get([m],v)))[m]??[],S=new Set(p.map(String)),U=h.filter(v=>!S.has(String(v)));if(U.length>0){const{error:v}=await b.from("extension_entries").delete().eq("user_id",r).in("entry_id",U);if(v)throw v}if(d.length>0){const v=d.map(Pe=>ce(r,Pe)),{error:le}=await b.from("extension_entries").upsert(v,{onConflict:"user_id,entry_id"});if(le)throw le}const Z=p.length;return await new Promise(v=>chrome.storage.local.set({lastSync:Date.now(),entryCount:Z,[`${t}_entry_ids`]:p.map(String),[`${t}_lastSync`]:Date.now(),[`${t}_entryCount`]:Z},()=>v())),{count:Z}}const i=e;if(t){const d=`${t}_entry_ids`,m=(await new Promise(f=>chrome.storage.local.get([d],f)))[d]??[];if(m.length>0){const{error:f}=await b.from("extension_entries").delete().eq("user_id",r).in("entry_id",m);if(f)throw f}else if(t==="underdog"){const{error:f}=await b.from("extension_entries").delete().eq("user_id",r);if(f)throw f}}else{const{error:d}=await b.from("extension_entries").delete().eq("user_id",r);if(d)throw d}if(i.length===0){const d={lastSync:Date.now(),entryCount:0};return t&&(d[`${t}_lastSync`]=Date.now(),d[`${t}_entryCount`]=0),await new Promise(p=>chrome.storage.local.set(d,()=>p())),{count:0}}const l=i.map(d=>ce(r,d)),{error:s,count:a}=await b.from("extension_entries").upsert(l,{onConflict:"user_id,entry_id",count:"exact"});if(s)throw s;const c={lastSync:Date.now(),entryCount:i.length};return t&&(c[`${t}_entry_ids`]=i.map(d=>d.entryId),c[`${t}_lastSync`]=Date.now(),c[`${t}_entryCount`]=i.length),await new Promise(d=>chrome.storage.local.set(c,()=>d())),{count:a??i.length}}async function de(e){if(!b||!Array.isArray(e)||e.length===0)return{count:0};const{data:{session:t}}=await b.auth.getSession();if(!t)return{count:0};const n=e.map(o=>({draft_id:String(o.draftId),slate_title:o.slateTitle??null,entry_count:o.entryCount??null,rounds:o.rounds??null,picks:o.picks??[],fetched_at:new Date().toISOString(),source:"extension"})),{error:r}=await b.from("draft_boards_admin").upsert(n,{onConflict:"draft_id"});if(r)throw r;return{count:n.length}}const Ge=/\s+(jr\.?|sr\.?|ii|iii|iv|v)\s*$/i;function R(e=""){return String(e).trim().replace(/^"|"$/g,"").replace(Ge,"").replace(/\./g,"").replace(/\s+/g," ").trim().toLowerCase()}const Ke="Real NFL 2026 W15/16/17 schedule (released 2026-05-14). Source: 2026 SCHEDULE RELEASE GRID (@OzzyNFL).",je={15:"NYJ",16:"NO",17:"LV"},Qe={15:"WAS",16:"TB",17:"NO"},Ye={15:"PIT",16:"CLE",17:"CIN"},Je={15:"CHI",16:"DEN",17:"MIA"},Ve={15:"CIN",16:"PIT",17:"SEA"},Xe={15:"BUF",16:"GB",17:"DET"},Ze={15:"CAR",16:"IND",17:"BAL"},et={15:"NYG",16:"BAL",17:"IND"},tt={15:"LAR",16:"JAX",17:"NYG"},nt={15:"LV",16:"BUF",17:"NE"},rt={15:"MIN",16:"NYG",17:"CHI"},ot={15:"MIA",16:"CHI",17:"HOU"},st={15:"JAX",16:"PHI",17:"GB"},at={15:"TEN",16:"CIN",17:"CLE"},it={15:"HOU",16:"DAL",17:"WAS"},lt={15:"NE",16:"SF",17:"LAC"},ct={15:"DEN",16:"TEN",17:"ARI"},dt={15:"SF",16:"MIA",17:"KC"},pt={15:"DAL",16:"SEA",17:"TB"},ut={15:"GB",16:"LAC",17:"BUF"},bt={15:"DET",16:"WAS",17:"NYJ"},ft={15:"KC",16:"NYJ",17:"DEN"},mt={15:"TB",16:"ARI",17:"ATL"},gt={15:"CLE",16:"DET",17:"DAL"},yt={15:"ARI",16:"NE",17:"MIN"},ht={15:"SEA",16:"HOU",17:"SF"},wt={15:"BAL",16:"CAR",17:"TEN"},xt={15:"LAC",16:"KC",17:"PHI"},vt={15:"PHI",16:"LAR",17:"CAR"},Et={15:"NO",16:"ATL",17:"LAR"},kt={15:"IND",16:"LV",17:"PIT"},St={15:"ATL",16:"MIN",17:"JAX"},pe={_README:Ke,ARI:je,ATL:Qe,BAL:Ye,BUF:Je,CAR:Ve,CHI:Xe,CIN:Ze,CLE:et,DAL:tt,DEN:nt,DET:rt,GB:ot,HOU:st,IND:at,JAX:it,KC:lt,LV:ct,LAC:dt,LAR:pt,MIA:ut,MIN:bt,NE:ft,NO:mt,NYG:gt,NYJ:yt,PHI:ht,PIT:wt,SF:xt,SEA:vt,TB:Et,TEN:kt,WAS:St},At=["15","16","17"],Bt=Object.freeze({QB:new Set(["QB","WR","TE"]),WR:new Set(["QB","WR","TE"]),TE:new Set(["QB","WR"])}),Ct=Object.freeze({QB:new Set(["QB","WR","TE","RB"]),WR:new Set(["QB","WR","TE","RB"]),TE:new Set(["QB","WR","RB"]),RB:new Set(["QB","WR","TE","RB"])});function _t(e){return e==="17"?Ct:Bt}const J="data-bbm-injected",we="data-bbm-player-id",W="data-bbm-headers-injected";let u=null,g=null,T=null,w=!0,$=null,te=window.location.href,G=!1,E=new Map,k=new Map,B=new Map,D=new Map,q=0,P=[],Y=new Map,M=null,F=null,ne=new Map,re=new Set,C=null,_="idle",oe=null,se=null,x=null;const It="https://bestballexposures.com/?upgrade=1";let A=[],K=[],y=new Set,Q=new Set;const ue=["S","A+","A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"],Lt={S:"#ffd700","A+":"#ef4444",A:"#f87171","A-":"#fb923c","B+":"#f59e0b",B:"#eab308","B-":"#a3e635","C+":"#10b981",C:"#06b6d4","C-":"#3b82f6","D+":"#6366f1",D:"#8b5cf6","D-":"#a855f7",F:"#6b7280"};function xe(e){const t=Math.max(0,Math.min(e-1,ue.length-1));return ue[t]}function Tt(e){return Lt[xe(e)]||"#555"}function Mt(e){const t=(e==null?void 0:e.message)??"";return t.includes("Not authenticated")||t.includes("JWT")?"Session expired — sign in again":t.includes("fetch")||t.includes("network")||t.includes("NetworkError")?"Connection lost — tap to retry":"Load failed — tap to retry"}function ee(e){const t=Math.floor((Date.now()-e)/1e3);return t<60?"just now":t<3600?`${Math.floor(t/60)}m ago`:t<86400?`${Math.floor(t/3600)}h ago`:`${Math.floor(t/86400)}d ago`}async function V(){const e=document.querySelector(".bbm-status-dot"),t=document.querySelector(".bbm-status-label"),n=document.querySelector(".bbm-panel-sync-line");if(!e||!t||!n)return;const r=await ye();let o,i;r?_==="loading"?(o="#6B7280",i="Loading portfolio…"):_==="error"?(o="#EF4444",i=oe??"Load failed — tap to retry"):(o="#10B981",i="Connected"):(o="#F59E0B",i="Not signed in"),e.style.background=o,t.textContent=i;const l=document.querySelector(".bbm-panel-status");if(l&&(l.style.cursor=_==="error"?"pointer":"default"),_==="loading"){n.textContent="Fetching entries…";return}if(!r){n.textContent="—";return}chrome.storage.local.get(["lastSync","entryCount","underdog_lastSync","underdog_entryCount","draftkings_lastSync","draftkings_entryCount"],s=>{const a=[];s.underdog_lastSync&&a.push(`UD: ${s.underdog_entryCount??0} · ${ee(s.underdog_lastSync)}`),s.draftkings_lastSync&&a.push(`DK: ${s.draftkings_entryCount??0} · ${ee(s.draftkings_lastSync)}`),a.length>0?n.textContent=a.join("  |  "):s.lastSync?n.textContent=`${s.entryCount??0} entries · synced ${ee(s.lastSync)}`:n.textContent="Not yet synced"})}function ae(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ve(e){return String(e??"").replace(/\b\w/g,t=>t.toUpperCase())}function Ee(){const e=document.getElementById("bbm-tournament-filter");if(e){if(A.length===0){e.style.display="none";return}e.style.display="block",e.innerHTML=A.map((t,n)=>{const r=Q.has(t.slate);return`
      <div class="bbm-filter-slate-group${r?" bbm-expanded":""}" data-si="${n}">
        <div class="bbm-filter-slate-row">
          <label class="bbm-filter-slate-label-wrap">
            <input type="checkbox" class="bbm-filter-check bbm-filter-slate-check" data-si="${n}" />
            <span class="bbm-filter-slate-label">${ae(t.slate)}</span>
          </label>
          <button type="button" class="bbm-filter-expand" data-si="${n}">${r?"▼":"▶"}</button>
        </div>
        <div class="bbm-filter-tournaments">
          ${t.tournaments.map((o,i)=>`
            <label class="bbm-filter-tournament-row">
              <input type="checkbox" class="bbm-filter-check bbm-filter-tournament-check"
                data-si="${n}" data-ti="${i}"
                ${y.has(o)?"checked":""} />
              <span class="bbm-filter-tournament-label">${ae(o)}</span>
            </label>
          `).join("")}
        </div>
      </div>
    `}).join(""),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{const{tournaments:n}=A[parseInt(t.dataset.si)],r=n.filter(o=>y.has(o)).length;t.checked=r===n.length,t.indeterminate=r>0&&r<n.length}),e.querySelectorAll(".bbm-filter-expand").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const r=A[parseInt(t.dataset.si)];Q.has(r.slate)?Q.delete(r.slate):Q.add(r.slate),Ee()})}),e.querySelectorAll(".bbm-filter-slate-check").forEach(t=>{t.addEventListener("change",()=>{const{tournaments:n}=A[parseInt(t.dataset.si)];n.every(o=>y.has(o))?n.forEach(o=>y.delete(o)):n.forEach(o=>y.add(o)),chrome.storage.local.set({tournamentFilter:[...y]}),ie()})}),e.querySelectorAll(".bbm-filter-tournament-check").forEach(t=>{t.addEventListener("change",()=>{const n=A[parseInt(t.dataset.si)].tournaments[parseInt(t.dataset.ti)];t.checked?y.add(n):y.delete(n),chrome.storage.local.set({tournamentFilter:[...y]}),ie()})})}}function ie(){var r,o,i,l;const e=y.size===0?K:K.filter(s=>y.has(s.tournamentTitle));q=e.length,E=new Map,k=new Map,B=new Map,D=new Map;const t=new Map;e.forEach((s,a)=>{(s.players??[]).forEach(c=>{if(!c.name)return;const d=R(c.name);if(!d)return;E.has(d)||E.set(d,new Set),E.get(d).add(a),c.team&&!k.has(d)&&k.set(d,c.team),c.position&&!B.has(d)&&B.set(d,c.position);const p=Number(c.pick);Number.isFinite(p)&&p>0&&(t.has(d)||t.set(d,[]),t.get(d).push(p))})});function n(s){const a=t.get(s);if(!a||a.length===0)return null;const c=[...a].sort((p,m)=>p-m),d=Math.floor(c.length/2);return c.length%2?c[d]:(c[d-1]+c[d])/2}for(const s of E.keys()){const a=s.split(/\s+/);if(a.length<2)continue;const c=a[0][0],d=a.slice(1).join(" "),p=`${c} ${d}`;if(D.has(p)){const m=D.get(p),f={fullName:s,position:((r=B.get(s))==null?void 0:r.toUpperCase())??null,team:((o=k.get(s))==null?void 0:o.toUpperCase())??null,medianPick:n(s)};typeof m=="string"?D.set(p,[{fullName:m,position:((i=B.get(m))==null?void 0:i.toUpperCase())??null,team:((l=k.get(m))==null?void 0:l.toUpperCase())??null,medianPick:n(m)},f]):Array.isArray(m)&&m.push(f)}else D.set(p,s)}Ee(),I()}async function z(){x=await he(),ke()}function ke(){var o;const e=x==="pro",t=document.getElementById("bbm-overlay-row"),n=document.getElementById("bbm-overlay-toggle");t&&n&&(e?(t.classList.remove("bbm-locked"),t.removeAttribute("title"),n.disabled=!1,n.checked=w):(t.classList.add("bbm-locked"),t.setAttribute("title","Pro feature — upgrade to use the overlay"),n.disabled=!0,n.checked=!1));const r=document.getElementById("bbm-filter-wrap");r&&(r.style.display=e?"":"none"),Rt(),e?(o=u==null?void 0:u.isDraftPage)!=null&&o.call(u)&&w&&!T&&O():T||C||M?j():Re()}function Rt(){const e=document.getElementById("bbm-upgrade-cta");if(e){if(x==="pro"){e.innerHTML="",e.style.display="none";return}e.style.display="block",e.innerHTML=`
    <a href="${It}" target="_blank" rel="noopener noreferrer" class="bbm-upgrade-btn">
      <span class="bbm-upgrade-icon" aria-hidden="true">★</span>
      Upgrade to Pro
    </a>
    <div class="bbm-upgrade-sub">Unlock the in-draft overlay</div>
  `}}async function X(){const e=document.getElementById("bbm-auth-section");if(!e)return;const t=await ye();if(t){const n=await he(),r=n?`<span class="bbm-auth-tier ${n}">${n==="pro"?"Pro":"Free"}</span>`:"";e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:none">
        <div class="bbm-auth-user">${ae(t.user.email)}</div>
        ${r}
        <button id="bbm-sign-out-btn" class="bbm-btn bbm-btn-secondary">Sign Out</button>
      </div>
      <button id="bbm-sync-btn" class="bbm-btn" style="margin-top:6px">Sync Now</button>
      <div id="bbm-sync-progress" class="bbm-sync-progress bbm-progress-indeterminate" style="display:none">
        <div class="bbm-progress-label">Discovering entries…</div>
        <div class="bbm-progress-bar-wrap"><div class="bbm-progress-bar-fill"></div></div>
      </div>
      <div id="bbm-sync-result" class="bbm-sync-result" style="display:none"></div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",be),e.querySelector("#bbm-sync-btn").addEventListener("click",Dt),e.querySelector("#bbm-sign-out-btn").addEventListener("click",Nt)}else{e.innerHTML=`
      <div class="bbm-account-toggle" id="bbm-account-toggle">
        <span class="bbm-account-toggle-label">Account</span>
        <span class="bbm-account-chevron" style="transform:rotate(180deg)">&#9660;</span>
      </div>
      <div class="bbm-account-body" id="bbm-account-body" style="display:block">
        <button id="bbm-google-btn" class="bbm-btn bbm-btn-google">
          <svg width="16" height="16" viewBox="0 0 48 48" style="flex-shrink:0"><path fill="#4285F4" d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z"/><path fill="#34A853" d="M6.3 14.7l7 5.1C15 15.6 19.1 12 24 12c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 16.3 2 9.7 7.3 6.3 14.7z"/><path fill="#FBBC05" d="M24 46c5.4 0 10.3-1.8 14.1-5l-6.9-5.7C29.1 37 26.7 38 24 38c-6 0-10.6-3.9-12.3-9.2l-7 5.4C8.1 41 15.4 46 24 46z"/><path fill="#EA4335" d="M46 24c0-1.3-.2-2.7-.5-4H24v8.5h11.8c-1 3-3 5.4-5.8 7l6.9 5.7C41 37.5 46 31.5 46 24z"/></svg>
          Sign in with Google
        </button>
        <div class="bbm-auth-divider"><span>or</span></div>
        <input type="email" id="bbm-auth-email" class="bbm-auth-input" placeholder="Email" autocomplete="email" />
        <input type="password" id="bbm-auth-password" class="bbm-auth-input" placeholder="Password" autocomplete="current-password" />
        <button id="bbm-sign-in-btn" class="bbm-btn">Sign In</button>
        <div id="bbm-auth-error" class="bbm-auth-error" style="display:none"></div>
      </div>
    `,e.querySelector("#bbm-account-toggle").addEventListener("click",be),e.querySelector("#bbm-google-btn").addEventListener("click",Pt),e.querySelector("#bbm-sign-in-btn").addEventListener("click",fe);for(const n of e.querySelectorAll(".bbm-auth-input"))for(const r of["keydown","keypress","keyup"])n.addEventListener(r,o=>o.stopPropagation());e.querySelector("#bbm-auth-password").addEventListener("keydown",n=>{n.key==="Enter"&&fe()})}}function be(){const e=document.getElementById("bbm-account-body"),t=document.querySelector(".bbm-account-chevron");if(!e)return;const n=e.style.display!=="none";e.style.display=n?"none":"block",t&&(t.style.transform=n?"":"rotate(180deg)")}async function Pt(){const e=document.getElementById("bbm-google-btn"),t=document.getElementById("bbm-auth-error");if(e){e.disabled=!0,t&&(t.style.display="none");try{await $e(),await z(),await X(),H()}catch(n){t&&(t.textContent=n.message??"Google sign-in failed",t.style.display="block"),e&&(e.disabled=!1)}}}async function fe(){var o,i;const e=(o=document.getElementById("bbm-auth-email"))==null?void 0:o.value.trim(),t=(i=document.getElementById("bbm-auth-password"))==null?void 0:i.value,n=document.getElementById("bbm-sign-in-btn"),r=document.getElementById("bbm-auth-error");if(!(!e||!t||!n)){n.disabled=!0,r&&(r.style.display="none");try{await De(e,t),await z(),await X(),H()}catch(l){r&&(r.textContent=l.message??"Sign in failed",r.style.display="block"),n&&(n.disabled=!1)}}}async function Nt(){await Fe(),E=new Map,k=new Map,B=new Map,q=0,K=[],A=[],x=null,await X(),ke(),V()}async function Dt(){const e=document.getElementById("bbm-sync-btn"),t=document.getElementById("bbm-sync-result"),n=document.getElementById("bbm-sync-progress");if(!e)return;if(e.disabled=!0,t&&(t.style.display="none",t.className="bbm-sync-result"),n&&(n.style.display="none"),!se){t&&(t.textContent=u.syncPageErrorMessage,t.classList.add("error"),t.style.display="block"),e.disabled=!1;return}const r=n==null?void 0:n.querySelector(".bbm-progress-label"),o=n==null?void 0:n.querySelector(".bbm-progress-bar-fill");function i(l){var d;if(l.source!==window||((d=l.data)==null?void 0:d.type)!=="BBM_SYNC_PROGRESS")return;const{phase:s,done:a,total:c}=l.data;if(n){if(n.style.display="block",s==="discovery")n.classList.add("bbm-progress-indeterminate"),r&&(r.textContent="Discovering entries…"),o&&(o.style.width="0%");else if(s==="fetching"){n.classList.remove("bbm-progress-indeterminate");const p=c>0?Math.round(a/c*100):0;r&&(r.textContent=`Processing ${a} / ${c} entries…`),o&&(o.style.width=p+"%")}else if(s==="boards"){n.classList.remove("bbm-progress-indeterminate");const p=c>0?Math.round(a/c*100):0;r&&(r.textContent=`Backfilling boards ${a} / ${c}…`),o&&(o.style.width=p+"%")}}}window.addEventListener("message",i);try{const{count:l,boardsRemaining:s=0}=await se();if(t){let a=`Synced ${l} entries`;s>0&&(a+=` — ${s} draft board${s===1?"":"s"} left to fill. Reload the page and press Sync again to continue.`),t.textContent=a,t.style.display="block"}H()}catch(l){if(t){const s=l.message??"Sync failed";t.textContent=s.includes("Could not establish connection")?u.syncPageErrorMessage:s,t.classList.add("error"),t.style.display="block"}}finally{window.removeEventListener("message",i),n&&(n.style.display="none"),e&&(e.disabled=!1)}}async function H(){_="loading",V();try{K=await Oe();const e=new Map;K.forEach(r=>{if(!r.tournamentTitle)return;const o=r.slateTitle||"Other";e.has(o)||e.set(o,new Set),e.get(o).add(r.tournamentTitle)}),A=[...e.entries()].sort(([r],[o])=>r.localeCompare(o)).map(([r,o])=>({slate:r,tournaments:[...o].sort()}));const t=new Set(A.flatMap(r=>r.tournaments)),n=y.size;y=new Set([...y].filter(r=>t.has(r))),y.size===0&&t.forEach(r=>y.add(r)),y.size!==n&&chrome.storage.local.set({tournamentFilter:[...y]}),ie(),_="ready",oe=null}catch(e){_="error",oe=Mt(e),console.warn("[BBM] Could not load portfolio data:",e.message)}finally{V()}}async function $t(){try{const e=await Ue();if(!e)return;ne=new Map(e.map(t=>[t.name,{rank:t.rank,tierNum:t.tierNum}])),re=new Set;for(let t=1;t<e.length;t++)e[t].tierNum!==e[t-1].tierNum&&re.add(e[t].rank);I()}catch(e){console.warn("[BBM] Could not load rankings data:",e.message)}}function Se(){let e;if(u.getCurrentPicks){const n=u.getCurrentPicks();if(!n)return;e=n.map(r=>({name:L(r.name,{position:r.position,team:r.team})??r.name,position:r.position,round:r.round}))}else e=[],document.querySelectorAll(u.selectors.myPicksSelector).forEach((r,o)=>{var c,d,p;const i=r.querySelector(u.selectors.playerNameInRowSelector),l=r.closest(u.selectors.positionSectionSelector),s=((d=(c=l==null?void 0:l.querySelector(u.selectors.positionHeaderSelector))==null?void 0:c.textContent)==null?void 0:d.trim())??"",a=(p=i==null?void 0:i.textContent)==null?void 0:p.trim();a&&e.push({name:a,position:s,round:o+1})});let t=!1;e.forEach(n=>{const r=R(n.name);if(!r)return;const o=Y.get(r);if(!o){Y.set(r,{name:n.name,position:n.position,round:n.round??null}),t=!0;return}(o.round==null||o.round===0)&&n.round!=null&&n.round>0&&(o.round=n.round,t=!0)}),t&&(P=[...Y.values()],I())}function Ft(){F||(F=requestAnimationFrame(()=>{F=null,Se()}))}function qt(){M||(M=new MutationObserver(Ft),M.observe(document.body,{childList:!0,subtree:!0}),Se())}function zt(){F&&(cancelAnimationFrame(F),F=null),M&&(M.disconnect(),M=null),P=[],Y.clear()}function Ae(e){var n;const t=e.querySelector(u.selectors.playerNameInRowSelector);return((n=t==null?void 0:t.textContent)==null?void 0:n.trim())??null}function L(e,t){if(!e)return null;const n=R(e);if(E.has(n))return n;const r=R(e),o=D.get(r);if(typeof o=="string")return o;if(Array.isArray(o)&&t){const i=t instanceof Element&&u.getPlayerContext?u.getPlayerContext(t):t;let l=o;if(i.position){const s=i.position.toUpperCase(),a=l.filter(c=>c.position===s);if(a.length===1)return a[0].fullName;a.length>1&&(l=a)}if(i.team){const s=i.team.toUpperCase(),a=l.filter(c=>c.team===s);if(a.length===1)return a[0].fullName;a.length>1&&(l=a)}if(l.length>1&&Number.isFinite(i.adp)){const s=l.filter(a=>Number.isFinite(a.medianPick));if(s.length>=1){let a=s[0],c=Math.abs(a.medianPick-i.adp);for(let d=1;d<s.length;d++){const p=Math.abs(s[d].medianPick-i.adp);p<c&&(a=s[d],c=p)}return console.debug(`[BBM] ambig "${e}" rowADP=${i.adp} → ${a.fullName} (medianPick=${a.medianPick})`),a.fullName}}l.length>1&&console.debug(`[BBM] ambig "${e}" unresolved`,{ctx:i,candidates:l.map(s=>({full:s.fullName,pos:s.position,team:s.team,med:s.medianPick}))})}return null}function Be(e){if(q===0)return 0;const t=L(e);if(!t)return 0;const n=E.get(t);return n?n.size/q*100:0}function Ce(e){const t=L(e),n=(t&&E.get(t))??new Set,r=[];let o=0,i=0;return P.forEach(l=>{const s=E.get(R(l.name))??new Set;if(s.size===0)return;let a=0;s.size<n.size?s.forEach(d=>{n.has(d)&&a++}):n.forEach(d=>{s.has(d)&&a++});const c=a/s.size;o+=c,i++,r.push({name:l.name,position:l.position,round:l.round,pct:Math.round(c*100)})}),{score:i>0?Math.round(o/i*100):0,breakdown:r}}function Ot(e){const t=e.querySelector(".bbm-stat-cell:not(.bbm-corr-trigger)"),n=e.querySelector(".bbm-corr-trigger");if(!t||!n)return;const r=Ae(e);if(!r||q===0)return;const o=L(r,e)??r,i=Be(o);t.textContent=`${Math.round(i)}%`;const l=n.querySelector(".bbm-corr-value"),s=n.querySelector(".bbm-corr-popup");if(!l||!s)return;const{score:a,breakdown:c}=Ce(o);l.textContent=`${a}%`,_e(s,c),Ie(e,o),Le(e,o),Me(e,o)}function _e(e,t){if(t.length===0){e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No picks yet</div>';return}e.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div>'+t.map(n=>`<div class="bbm-corr-popup-row">
          <span class="bbm-corr-popup-pos">${n.position}</span>
          <span class="bbm-corr-popup-name">${ve(n.name)}</span>
          <div class="bbm-corr-popup-bar">
            <div class="bbm-corr-popup-bar-fill" style="width:${n.pct}%;background:#3b82f6"></div>
          </div>
          <span class="bbm-corr-popup-pct">${n.pct}%</span>
        </div>`).join("")}function Ie(e,t){e.querySelectorAll(".bbm-stack-pill").forEach(i=>i.remove());const n=Ht(t);if(!n)return;const r=e.querySelector(u.selectors.stackPillTargetSelector);if(!r)return;const o=document.createElement("span");o.className="bbm-stack-pill bbm-inline-overlay",o.textContent=n.type,o.style.color=n.color,o.style.borderColor=n.color,o.style.background=`${n.color}1A`,r.appendChild(o)}function Ht(e){const t=L(e);if(!t)return null;const n=k.get(t),r=B.get(t);if(!n||!r||P.length===0)return null;const o=P.filter(c=>{const d=k.get(R(c.name));return d&&d===n});if(o.length===0)return null;const i=o.filter(c=>c.position==="QB"),l=o.filter(c=>c.position==="WR"),s=o.filter(c=>c.position==="TE"),a=o.filter(c=>c.position==="RB");return r==="QB"&&(l.length>0||s.length>0||a.length>0)?{type:l.length+s.length+a.length>=2?"QB MULTI":"QB STACK",color:"#BF44EF"}:(r==="WR"||r==="TE"||r==="RB")&&i.length>0?{type:l.length+s.length+a.length>=1?"QB MULTI":"QB STACK",color:"#BF44EF"}:r==="WR"&&l.length>=1?{type:`WR ×${l.length+1}`,color:"#F59E0B"}:r==="TE"&&s.length>=1?{type:`TE ×${s.length+1}`,color:"#3B82F6"}:r==="RB"&&a.length>=1?{type:`RB ×${a.length+1}`,color:"#10B981"}:r==="RB"&&(l.length>0||s.length>0)?{type:"TEAM",color:"#8A9BB5"}:(r==="WR"||r==="TE")&&a.length>0?{type:"TEAM",color:"#8A9BB5"}:null}function Ut(e){const t=L(e);if(!t)return null;const n=k.get(t),r=B.get(t);if(!n||!r||P.length===0)return null;const o=[];let i=0;return At.forEach(l=>{var d;const s=_t(l)[r];if(!s)return;const a=(d=pe[n])==null?void 0:d[l];if(!a)return;const c=[];P.forEach(p=>{var U;const m=R(p.name),f=k.get(m),h=B.get(m);if(!f||!h||f===n||f!==a)return;const S=(U=pe[f])==null?void 0:U[l];S&&S!==n||s.has(h)&&c.push({name:p.name,position:h,team:f,opp:n})}),c.length>0&&(o.push({week:l,entries:c}),i+=c.length)}),i===0?null:{count:i,weeks:o}}function Le(e,t){const n=x==="pro"?Ut(t):null,r=n?JSON.stringify(n):"",o=e.querySelector(".bbm-playoff-pill");if(o&&o._playoffSig===r||(o&&(g&&o._ownsPortal&&(g.style.display="none"),o.remove()),!n))return;const i=e.querySelector(u.selectors.stackPillTargetSelector);if(!i)return;const l=document.createElement("span");if(l.className="bbm-playoff-pill bbm-inline-overlay",n.weeks.length===1){const s=n.weeks[0];l.innerHTML=`<span class="bbm-playoff-chip bbm-playoff-w${s.week}">W${s.week}<span class="bbm-playoff-chip-count">${s.entries.length}</span></span>`}else{const s=n.weeks.map(a=>a.week).join("/");l.innerHTML=`<span class="bbm-playoff-chip bbm-playoff-multi">W${s}<span class="bbm-playoff-chip-count">${n.count}</span></span>`}l._playoffPayload=n,l._playoffSig=r,i.appendChild(l),Gt(l)}function Wt(e){return`<div class="bbm-corr-popup-title">Playoff Game Stacks</div>${e.weeks.map(n=>{const r=n.entries.map(o=>`
      <div class="bbm-corr-popup-row">
        <span class="bbm-corr-popup-pos">${o.position}</span>
        <span class="bbm-corr-popup-name">${ve(o.name)}</span>
        <span class="bbm-playoff-popup-matchup">${o.team} @ ${o.opp}</span>
      </div>`).join("");return`<div class="bbm-playoff-popup-week bbm-playoff-w${n.week}">Week ${n.week}</div>${r}`}).join("")}`}function Gt(e){e.addEventListener("mouseenter",()=>{if(!e._playoffPayload)return;Te(),g.innerHTML=Wt(e._playoffPayload);const t=e.getBoundingClientRect();g.style.left=`${Math.max(8,t.right-280)}px`,g.style.top=`${t.bottom+4}px`,g.style.display="block",e._ownsPortal=!0}),e.addEventListener("mouseleave",()=>{e._ownsPortal=!1,g&&(g.style.display="none")})}function Kt(){const e=document.createElement("div");e.className="bbm-inline-overlay bbm-stat-cell",e.textContent="--%";const t=document.createElement("div");t.className="bbm-inline-overlay bbm-stat-cell bbm-corr-trigger";const n=document.createElement("span");n.className="bbm-corr-value",n.textContent="--";const r=document.createElement("div");return r.className="bbm-corr-popup",r.innerHTML='<div class="bbm-corr-popup-title">Roster Overlap</div><div class="bbm-corr-popup-empty">No draft data yet</div>',t.appendChild(n),t.appendChild(r),t.addEventListener("mouseenter",()=>{Te(),g.innerHTML=r.innerHTML;const o=t.getBoundingClientRect();g.style.left=`${Math.max(8,o.right-280)}px`,g.style.top=`${o.bottom+4}px`,g.style.display="block"}),t.addEventListener("mouseleave",()=>{g&&(g.style.display="none")}),[e,t]}function Te(){g&&document.body.contains(g)||(g=document.createElement("div"),g.className="bbm-corr-popup",g.id="bbm-corr-popup-portal",g.style.cssText="display: none; position: fixed; z-index: 10001;",document.body.appendChild(g))}function jt(e){var c,d;const t=((c=u.getRowId)==null?void 0:c.call(u,e))??e.getAttribute("data-id");if(!t)return;if(e.getAttribute(J)===t){Ot(e);return}e.querySelectorAll(".bbm-inline-overlay").forEach(p=>p.remove()),e.querySelectorAll(".bbm-tier-badge").forEach(p=>p.remove()),e.removeAttribute("data-bbm-tier");const{parent:r,before:o}=((d=u.getInjectionPoint)==null?void 0:d.call(u,e))??{};if(!r)return;const[i,l]=Kt();o?(r.insertBefore(i,o),r.insertBefore(l,o)):r.append(i,l),u.postInjectRow&&u.postInjectRow(e,i,l),e.setAttribute(J,t),e.setAttribute(we,t);const s=Ae(e),a=L(s,e)??s;if(q>0&&a){const p=Be(a);i.textContent=`${Math.round(p)}%`;const{score:m,breakdown:f}=Ce(a),h=l.querySelector(".bbm-corr-value"),S=l.querySelector(".bbm-corr-popup");h.textContent=`${m}%`,_e(S,f)}a&&(Ie(e,a),Le(e,a)),Me(e,a)}function Me(e,t){if(e.querySelectorAll(".bbm-tier-badge").forEach(c=>c.remove()),e.removeAttribute("data-bbm-tier"),!u.isMyRankSort()||ne.size===0||!t)return;const n=L(t),r=ne.get(n??t.trim().toLowerCase());if(!r)return;const{tierNum:o,rank:i}=r;if(e.setAttribute("data-bbm-tier",String(o)),!re.has(i))return;const l=Tt(o),s=xe(o),a=document.createElement("div");a.className="bbm-tier-badge",a.style.color=l,a.innerHTML=`<span class="bbm-tier-pill">${s}</span>`,e.prepend(a)}function Qt(){const e=document.querySelector(u.selectors.sortButtonsSelector);if(!e||(C||(C=new MutationObserver(I),C.observe(e,{attributes:!0,subtree:!0})),e.hasAttribute(W)))return;if(u.injectHeaderCells){u.injectHeaderCells(e),e.setAttribute(W,"true");return}const t=document.querySelector(u.selectors.rowSelector);if(!t)return;const n=e.getBoundingClientRect(),r=t.querySelectorAll(".bbm-stat-cell");if(r.length<2)return;const o=r[0].getBoundingClientRect(),i=r[1].getBoundingClientRect(),l=n.right,s=l-o.right,a=l-i.right;e.style.position="relative";const c=document.createElement("span");c.className="bbm-header-label",c.textContent="Exp",c.style.right=`${s}px`,c.style.width=`${o.width}px`;const d=document.createElement("span");d.className="bbm-header-label",d.textContent="Corr",d.style.right=`${a}px`,d.style.width=`${i.width}px`,e.appendChild(c),e.appendChild(d),e.setAttribute(W,"true")}function Yt(){document.querySelectorAll(".bbm-header-label").forEach(e=>e.remove()),document.querySelectorAll(`[${W}]`).forEach(e=>{e.removeAttribute(W)})}function I(){$||($=requestAnimationFrame(()=>{var t;if($=null,!w||x!=="pro")return;(((t=u.getPlayerRows)==null?void 0:t.call(u))??document.querySelectorAll(u.selectors.rowSelector)).forEach(jt),Qt()}))}function Re(){document.querySelectorAll(".bbm-inline-overlay").forEach(e=>e.remove()),document.querySelectorAll(".bbm-tier-badge").forEach(e=>e.remove()),document.querySelectorAll("[data-bbm-tier]").forEach(e=>e.removeAttribute("data-bbm-tier")),document.querySelectorAll(`[${J}]`).forEach(e=>{e.removeAttribute(J),e.removeAttribute(we)}),Yt(),g&&(g.remove(),g=null)}function Jt(){if(document.getElementById("bbm-overlay-styles"))return;const e=document.createElement("style");e.id="bbm-overlay-styles",e.textContent=`
    /* DK: allow overlay cells to overflow fixed-width rows (scoped to rows, not scroll container) */
    .BaseTable__row {
      overflow: visible !important;
    }

    .bbm-stat-cell {
      color: inherit;
      opacity: 0.6;
      font-family: inherit;
      font-size: 11px;
      white-space: nowrap;
      flex-shrink: 0;
      width: 40px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }
    .bbm-stat-cell + .bbm-stat-cell {
      margin-left: 12px;
    }

    /* Corr cell is hoverable */
    .bbm-corr-trigger {
      pointer-events: auto;
      cursor: default;
      position: relative;
    }
    .bbm-corr-trigger:hover {
      opacity: 1;
    }

    /* Correlation popup — hidden by default, shown via JS mouseenter/mouseleave */
    .bbm-corr-popup {
      display: none;
      background: var(--bg-primary, #1a1a2e);
      color: #E8E8E8;
      border: 1px solid var(--border-color, #333);
      border-radius: 8px;
      padding: 8px 0;
      z-index: 10001;
      min-width: 220px;
      max-width: 300px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      white-space: normal;
      text-align: left;
      opacity: 1;
    }
    .bbm-corr-popup-title {
      padding: 0 12px 6px;
      font-size: 10px;
      color: #E8E8E8;
      opacity: 0.5;
      text-transform: uppercase;
      font-weight: 700;
      letter-spacing: 0.05em;
    }
    .bbm-corr-popup-empty {
      padding: 4px 12px;
      font-size: 12px;
      color: #E8E8E8;
      opacity: 0.4;
      font-style: italic;
    }

    /* Rows for when real data is wired in */
    .bbm-corr-popup-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 12px;
    }
    .bbm-corr-popup-pos {
      font-size: 10px;
      font-weight: 900;
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 22px;
      text-align: center;
    }
    .bbm-corr-popup-name {
      font-size: 12px;
      font-weight: 600;
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-corr-popup-bar {
      width: 40px;
      height: 5px;
      background: rgba(128, 128, 128, 0.3);
      border-radius: 3px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .bbm-corr-popup-bar-fill {
      height: 100%;
      border-radius: 3px;
    }
    .bbm-corr-popup-pct {
      font-size: 11px;
      font-weight: 700;
      font-family: monospace;
      min-width: 28px;
      text-align: right;
    }

    /* Stack pill — inline after player name, only visible when stacking */
    .bbm-stack-pill {
      display: inline-block;
      vertical-align: middle;
      margin-left: 6px;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid;
      line-height: 1.5;
      white-space: nowrap;
      pointer-events: none;
      opacity: 0.85;
    }

    /* Playoff game-stack pill (TASK-232) — container for per-week chips colored
       bronze/silver/gold (W15/W16/W17) to differentiate weeks at a glance.
       Interactive (hover opens the shared correlation popup with playoff-grouped
       contents). */
    .bbm-playoff-pill {
      display: inline-flex;
      vertical-align: middle;
      align-items: center;
      gap: 3px;
      margin-left: 4px;
      line-height: 1.5;
      white-space: nowrap;
      cursor: default;
    }
    .bbm-playoff-chip {
      display: inline-flex;
      align-items: center;
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      padding: 1px 5px;
      border-radius: 20px;
      border: 1px solid currentColor;
      background: rgba(255, 255, 255, 0.04);
      opacity: 0.95;
    }
    .bbm-playoff-chip-count {
      display: inline-block;
      margin-left: 4px;
      color: currentColor;
      font-weight: 800;
      text-align: center;
    }
    /* W15 bronze, W16 silver, W17 gold for single-week chips and popup
       section headers. Multi-week collapses to a single red pill (so the
       red signals "spans multiple playoff weeks" at a glance). */
    .bbm-playoff-w15 { color: #CD7F32; }
    .bbm-playoff-w16 { color: #C9CED6; }
    .bbm-playoff-w17 { color: #FFD700; }
    .bbm-playoff-multi { color: #EF4444; }

    .bbm-playoff-popup-week {
      margin-top: 8px;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      opacity: 0.95;
    }
    .bbm-playoff-popup-week:first-child {
      margin-top: 4px;
    }
    .bbm-playoff-popup-matchup {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.04em;
      color: inherit;
      opacity: 0.65;
      margin-left: auto;
      white-space: nowrap;
    }

    /* Tier break — full-width divider with centered pill label */
    .bbm-tier-badge {
      position: absolute;
      left: 0;
      right: 0;
      top: -7px;
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: none;
      z-index: 0;
      padding: 0 10px;
    }
    .bbm-tier-badge::before,
    .bbm-tier-badge::after {
      content: '';
      flex: 1;
      height: 1px;
      background: currentColor;
      opacity: 0.35;
    }
    .bbm-tier-pill {
      font-size: 8px;
      font-weight: 800;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      padding: 2px 6px;
      border-radius: 3px;
      background: #0C1A30;
      border: 1px solid currentColor;
      color: inherit;
      white-space: nowrap;
      line-height: 1.5;
      flex-shrink: 0;
    }

    .bbm-header-label {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      color: inherit;
      opacity: 0.5;
      font-family: inherit;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      text-align: center;
      padding: 0 2px;
      pointer-events: none;
    }

    /* Auth section (TASK-129) */
    #bbm-auth-section { margin: 6px 0; }

    .bbm-account-toggle {
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: pointer;
      padding: 3px 0;
      user-select: none;
    }
    .bbm-account-toggle-label {
      font-size: 10px;
      color: #8A9BB5;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .bbm-account-chevron {
      font-size: 9px;
      color: #5a6a80;
      transition: transform 0.15s;
      line-height: 1;
    }
    .bbm-account-body { padding-top: 6px; }

    .bbm-auth-input {
      width: 100%;
      background: #0F2040;
      border: 1px solid #243A5C;
      border-radius: 4px;
      color: #E8E8E8;
      font-size: 11px;
      padding: 5px 7px;
      margin-bottom: 4px;
      box-sizing: border-box;
      outline: none;
    }
    .bbm-auth-input:focus { border-color: #E8BF4A; }

    .bbm-btn {
      width: 100%;
      background: #E8BF4A;
      color: #0C1A30;
      border: none;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      padding: 5px 0;
      cursor: pointer;
      margin-bottom: 4px;
    }
    .bbm-btn:hover { background: #F0CC5B; }
    .bbm-btn:disabled { opacity: 0.5; cursor: default; }

    .bbm-btn-secondary {
      background: transparent;
      color: #8A9BB5;
      border: 1px solid #243A5C;
    }
    .bbm-btn-secondary:hover { color: #E8E8E8; border-color: #8A9BB5; }

    .bbm-btn-google {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      background: #fff;
      color: #3c4043;
      font-weight: 600;
    }
    .bbm-btn-google:hover { background: #f1f3f4; }

    .bbm-auth-divider {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 6px 0;
      font-size: 9px;
      color: #5A6E8A;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .bbm-auth-divider::before,
    .bbm-auth-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #243A5C;
    }

    .bbm-auth-user {
      font-size: 11px;
      color: #C0CCE0;
      margin-bottom: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .bbm-auth-tier {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 6px;
      background: #1C3A5E;
      color: #8A9BB5;
    }
    .bbm-auth-tier.pro { background: #2A3A10; color: #A3C447; }

    .bbm-auth-error {
      font-size: 10px;
      color: #EF4444;
      margin-top: 2px;
    }
    .bbm-sync-result {
      font-size: 10px;
      color: #10B981;
      margin-bottom: 4px;
    }
    .bbm-sync-result.error { color: #EF4444; }

    .bbm-sync-progress { margin-bottom: 6px; }
    .bbm-progress-label {
      font-size: 10px;
      color: #8A9BB5;
      margin-bottom: 3px;
    }
    .bbm-progress-bar-wrap {
      width: 100%;
      height: 4px;
      background: #1a2d50;
      border-radius: 2px;
      overflow: hidden;
    }
    .bbm-progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #D4A843, #F0CC5B);
      border-radius: 2px;
      transition: width 0.2s ease;
    }
    @keyframes bbm-shimmer {
      0%   { transform: translateX(-100%); }
      100% { transform: translateX(400%); }
    }
    .bbm-progress-indeterminate .bbm-progress-bar-fill {
      width: 25%;
      animation: bbm-shimmer 1.4s ease-in-out infinite;
    }

    /* FAB — brand logo button, bottom-left. Whispers at rest, speaks on hover. */
    #bbm-fab {
      position: fixed;
      bottom: 14px;
      left: 14px;
      z-index: 10000;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      opacity: 0.3;
      transition: opacity 120ms ease, filter 120ms ease;
    }
    #bbm-fab:hover {
      opacity: 1;
      filter: drop-shadow(0 0 8px rgba(232, 191, 74, 0.5));
    }

    /* Configuration panel — compact, only visible on demand */
    #bbm-panel {
      display: none;
      position: fixed;
      bottom: 50px;
      left: 14px;
      z-index: 10000;
      background: #0C1A30;
      border: 1px solid #243A5C;
      border-radius: 8px;
      padding: 10px 14px;
      min-width: 210px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
      font-size: 12px;
      color: #E8E8E8;
    }
    #bbm-panel.open {
      display: block;
    }
    .bbm-panel-title {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8A9BB5;
      margin-bottom: 8px;
    }
    .bbm-panel-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .bbm-panel-label {
      font-size: 12px;
      font-weight: 600;
      color: #E8E8E8;
    }
    #bbm-overlay-toggle {
      cursor: pointer;
      width: 14px;
      height: 14px;
      accent-color: #E8BF4A;
    }

    /* TASK-231: locked overlay row (non-Pro) */
    .bbm-lock-icon {
      display: none;
      margin-left: 5px;
      font-size: 11px;
      vertical-align: -1px;
      filter: grayscale(1) brightness(1.3);
      opacity: 0.7;
    }
    #bbm-overlay-row.bbm-locked {
      opacity: 0.5;
      cursor: not-allowed;
    }
    #bbm-overlay-row.bbm-locked .bbm-panel-label {
      pointer-events: none;
    }
    #bbm-overlay-row.bbm-locked .bbm-lock-icon {
      display: inline;
    }
    #bbm-overlay-row.bbm-locked #bbm-overlay-toggle {
      pointer-events: none;
      cursor: not-allowed;
    }

    /* TASK-231: Upgrade-to-Pro CTA */
    #bbm-upgrade-cta {
      margin: 8px 0 4px;
    }
    .bbm-upgrade-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      padding: 7px 10px;
      border-radius: 6px;
      background: linear-gradient(135deg, #D4A843 0%, #F0CC5B 50%, #E8BF4A 100%);
      color: #0C1A30;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      text-decoration: none;
      border: 1px solid #B8911E;
      box-shadow: 0 1px 4px rgba(232, 191, 74, 0.25);
      box-sizing: border-box;
      transition: filter 120ms ease, transform 120ms ease;
    }
    .bbm-upgrade-btn:hover {
      filter: brightness(1.08);
      transform: translateY(-1px);
    }
    .bbm-upgrade-icon {
      font-size: 13px;
      line-height: 1;
    }
    .bbm-upgrade-sub {
      font-size: 10px;
      color: #8A9BB5;
      text-align: center;
      margin-top: 4px;
    }

    /* Confidence panel — status and sync lines (TASK-106) */
    .bbm-panel-divider {
      border: none;
      border-top: 1px solid #243A5C;
      margin: 8px 0;
    }
    .bbm-panel-status {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
    }
    .bbm-status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #6B7280;
    }
    .bbm-status-label {
      font-size: 11px;
      color: #C0CCE0;
    }
    .bbm-panel-sync-line {
      font-size: 10px;
      color: #8A9BB5;
      margin-top: 3px;
      padding-left: 12px;
    }

    /* Tournament filter (TASK-107) — hierarchical: slate → tournament */
    .bbm-filter-title {
      margin-top: 6px;
      margin-bottom: 4px;
    }
    #bbm-tournament-filter {
      max-height: 140px;
      overflow-y: auto;
    }
    .bbm-filter-check {
      cursor: pointer;
      accent-color: #E8BF4A;
      flex-shrink: 0;
      width: 12px;
      height: 12px;
    }
    .bbm-filter-slate-group {
      border-bottom: 1px solid #1E3054;
    }
    .bbm-filter-slate-group:last-child {
      border-bottom: none;
    }
    .bbm-filter-slate-row {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 3px 0;
    }
    .bbm-filter-slate-label-wrap {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 1;
      cursor: pointer;
      min-width: 0;
    }
    .bbm-filter-slate-label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #8A9BB5;
    }
    .bbm-filter-expand {
      background: none;
      border: none;
      color: #8A9BB5;
      font-size: 7px;
      padding: 0 2px;
      cursor: pointer;
      flex-shrink: 0;
      line-height: 1;
    }
    .bbm-filter-tournaments {
      display: none;
    }
    .bbm-filter-slate-group.bbm-expanded .bbm-filter-tournaments {
      display: block;
    }
    .bbm-filter-tournament-row {
      display: flex;
      align-items: center;
      gap: 5px;
      padding: 2px 0 2px 14px;
      cursor: pointer;
    }
    .bbm-filter-tournament-label {
      font-size: 11px;
      color: #C0CCE0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `,document.head.appendChild(e)}function O(){if(T||x!=="pro")return;H(),$t(),qt(),T=ge({targetSelector:u.selectors.gridSelector,onMutation:I,onReconnect:()=>{I()}});const e=document.querySelector(u.selectors.sortButtonsSelector);e&&(C=new MutationObserver(I),C.observe(e,{attributes:!0,subtree:!0})),I()}function j(){T&&(T.disconnect(),T=null),C&&(C.disconnect(),C=null),$&&(cancelAnimationFrame($),$=null),zt(),Re()}function Vt(){if(document.getElementById("bbm-fab"))return;const e=document.createElement("button");e.id="bbm-fab",e.title="Best Ball Exposures",e.innerHTML=`<svg width="36" height="36" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Best Ball Exposures">
    <defs>
      <linearGradient id="bb-gold" x1="10" y1="10" x2="38" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%"   stop-color="#F0CC5B"/>
        <stop offset="50%"  stop-color="#D4A843"/>
        <stop offset="100%" stop-color="#E8BF4A"/>
      </linearGradient>
      <linearGradient id="bb-bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#0C1A30"/>
        <stop offset="100%" stop-color="#060E1F"/>
      </linearGradient>
    </defs>
    <circle cx="24" cy="24" r="24" fill="url(#bb-bg)"/>
    <circle cx="24" cy="24" r="22.5" fill="none" stroke="url(#bb-gold)" stroke-width="2"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="#E8BF4A" stroke-width="0.5" opacity="0.18"/>
    <circle cx="24" cy="24" r="14" fill="none" stroke="url(#bb-gold)" stroke-width="3.5" stroke-linecap="round" stroke-dasharray="18 7 10 7 23 7 8 7.96" transform="rotate(-90 24 24)"/>
    <circle cx="24" cy="24" r="2.5" fill="url(#bb-gold)"/>
  </svg>`;const t=document.createElement("div");t.id="bbm-panel",t.innerHTML=`
    <div class="bbm-panel-title">Best Ball Exposures</div>
    <div id="bbm-auth-section"></div>
    <div id="bbm-upgrade-cta" style="display:none"></div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-row" id="bbm-overlay-row">
      <label class="bbm-panel-label" for="bbm-overlay-toggle">
        Overlay
        <span class="bbm-lock-icon" aria-hidden="true">🔒</span>
      </label>
      <input type="checkbox" id="bbm-overlay-toggle" />
    </div>
    <hr class="bbm-panel-divider" />
    <div class="bbm-panel-status">
      <span class="bbm-status-dot"></span>
      <span class="bbm-status-label">—</span>
    </div>
    <div class="bbm-panel-sync-line">—</div>
    <div id="bbm-filter-wrap">
      <hr class="bbm-panel-divider" />
      <div class="bbm-panel-title bbm-filter-title">Tournament Filter</div>
      <div id="bbm-tournament-filter" style="display:none"></div>
    </div>
  `;const n=t.querySelector("#bbm-overlay-toggle");n.checked=w,t.querySelector(".bbm-panel-status").addEventListener("click",()=>{_==="error"&&H()}),t.addEventListener("click",o=>o.stopPropagation()),e.addEventListener("click",o=>{o.stopPropagation(),t.classList.toggle("open"),t.classList.contains("open")&&(X(),V(),z())}),n.addEventListener("change",()=>{if(x!=="pro"){n.checked=!1;return}w=n.checked,chrome.storage.local.set({overlayEnabled:w}),w?O():j()}),document.body.appendChild(e),document.body.appendChild(t)}function me(){const e=window.location.href;if(e===te)return;const t=G;te=e,G=u.isDraftPage();const n=G;!t&&n?z().then(()=>{w&&x==="pro"&&O()}):t&&!n?j():t&&n&&(j(),z().then(()=>{w&&x==="pro"&&O()}))}function Xt(){setInterval(()=>{window.location.href!==te&&me()},300),window.addEventListener("popstate",me)}function Zt(e,t=null){u=e,se=t,chrome.storage.local.get(["overlayEnabled","tournamentFilter"],n=>{w=n.overlayEnabled!==!1,y=new Set(n.tournamentFilter??[]),G=u.isDraftPage(),Jt(),Vt(),Xt(),z().then(()=>{G&&w&&x==="pro"?O():H()}),document.addEventListener("click",()=>{var r;(r=document.getElementById("bbm-panel"))==null||r.classList.remove("open")}),document.addEventListener("keydown",r=>{var o;r.key==="Escape"&&((o=document.getElementById("bbm-panel"))==null||o.classList.remove("open"))})}),chrome.runtime.onMessage.addListener(n=>{if(n.type!=="TOGGLE_OVERLAY"||x!=="pro"&&n.enabled)return;w=n.enabled;const r=document.getElementById("bbm-overlay-toggle");r&&(r.checked=w),w?u.isDraftPage()&&O():j()})}const N=Ne(window.location.href);if(N){document.querySelector("#root, #app, [data-reactroot]")&&ge({targetSelector:"#root, #app, [data-reactroot]",onMutation:()=>{},onReconnect:()=>{}});async function t(){var s,a;const n=await qe(),r=await N.getEntries(n),o=await We(r,{platform:N.platform});if((s=r==null?void 0:r.boards)!=null&&s.length)try{await de(r.boards)}catch(c){console.warn("[BBM] writeBoards failed (entries synced OK):",c.message)}const i=100;let l=0;if(typeof N.getBoards=="function"&&((a=r==null?void 0:r.currentDraftIds)!=null&&a.length))try{const c=new Set((r.boards??[]).map(f=>String(f.draftId))),d=await ze(r.currentDraftIds),p=r.currentDraftIds.map(String).filter(f=>!d.has(f)&&!c.has(f)),m=p.slice(0,i);if(m.length){const f=await N.getBoards(m);await de(f)}l=Math.max(0,p.length-m.length)}catch(c){console.warn("[BBM] board backfill failed (sync OK):",c.message)}return{...o,boardsRemaining:l}}Zt(N,t),chrome.runtime.onMessage.addListener((n,r,o)=>n.type!=="SYNC_ENTRIES"?!1:(t().then(({count:i})=>o({ok:!0,count:i})).catch(i=>o({ok:!1,error:i.message})),!0))}
